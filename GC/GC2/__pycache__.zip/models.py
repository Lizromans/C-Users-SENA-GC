from django.db import models
from django.utils import timezone
import secrets, datetime
from django.urls import reverse
from django.core.mail import send_mail, EmailMultiAlternatives
from django.template.loader import render_to_string
from django.utils.html import strip_tags
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager, Group, Permission
from django.conf import settings
import datetime


class UsuarioManager(BaseUserManager):
    def create_user(self, cedula, password=None, **extra_fields):
        if not cedula:
            raise ValueError("El usuario debe tener una cédula")
        user = self.model(cedula=cedula, **extra_fields)
        user.set_password(password)  # Hashea correctamente la contraseña
        user.save(using=self._db)
        return user

    def create_superuser(self, cedula, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError("El superusuario debe tener is_staff=True.")
        if extra_fields.get('is_superuser') is not True:
            raise ValueError("El superusuario debe tener is_superuser=True.")

        return self.create_user(cedula, password, **extra_fields)

class Usuario(AbstractBaseUser, PermissionsMixin):
    cedula = models.IntegerField(primary_key=True)
    nom_usu = models.CharField(max_length=250)
    ape_usu = models.CharField(max_length=250)
    fecha_nacimiento = models.DateField(null=True, blank=True)
    telefono = models.CharField(max_length=250, null=True, blank=True)
    correo_per = models.CharField(max_length=250)
    correo_ins = models.CharField(max_length=250, null=True, blank=True)
    rol = models.CharField(max_length=250)
    vinculacion_laboral = models.CharField(max_length=250, null=True, blank=True)
    dependencia = models.CharField(max_length=250, null=True, blank=True)
    estado = models.CharField(max_length=250, null=True, blank=True, default='Activo')
    password = models.CharField(max_length=128)
    token_verificacion = models.CharField(max_length=250, null=True, blank=True)
    token_expira = models.DateTimeField(null=True, blank=True)
    email_verificado = models.BooleanField(default=False)
    last_login = models.DateTimeField(null=True, blank=True)
    imagen_perfil = models.ImageField(upload_to='fotos_perfil/', null=True, blank=True)
    rol_original = models.CharField(max_length=250, null=True, blank=True)
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    is_superuser = models.BooleanField(default=False)
    fecha_registro = models.DateTimeField(auto_now_add=True, null=True)
    codigo_verificacion = models.CharField(max_length=6, null=True, blank=True)
    codigo_expiracion = models.DateTimeField(null=True, blank=True)
    intentos_codigo_fallidos = models.IntegerField(default=0)
    bloqueado_hasta = models.DateTimeField(null=True, blank=True)
    ultimo_codigo_enviado = models.DateTimeField(null=True, blank=True)
    codigos_enviados_hoy = models.IntegerField(default=0)
    fecha_ultimo_reset_codigos = models.DateField(null=True, blank=True)
    notificaciones_habilitadas = models.BooleanField(default=True)
    notif_eventos              = models.BooleanField(default=True)
    notif_entregables          = models.BooleanField(default=True)
    notif_proyectos            = models.BooleanField(default=True)
    notif_miembros             = models.BooleanField(default=True)

    groups = models.ManyToManyField(
        Group,
        through='UsuarioGrupos', 
        related_name='custom_usuarios',
        blank=True
    )

    user_permissions = models.ManyToManyField(
        Permission,
        through='UsuarioUserPermissions',
        related_name='custom_usuarios_perms',
        blank=True
    )

    semilleros = models.ManyToManyField(
        'Semillero',
        through='SemilleroUsuario',
        related_name='usuarios'
    )

    proyectos = models.ManyToManyField(
        'Proyecto',
        through='UsuarioProyecto',
        related_name='usuarios'
    )

    USERNAME_FIELD = 'cedula'
    REQUIRED_FIELDS = ['correo_per']

    objects = UsuarioManager()

    class Meta:
        managed = True
        db_table = 'usuario'

    def __str__(self):
        return f"{self.nom_usu} {self.ape_usu}"

    def generar_token_verificacion(self):
        self.token_verificacion = secrets.token_urlsafe(32)
        self.token_expira = timezone.now() + datetime.timedelta(hours=24)
        self.save()

    def enviar_email_verificacion(self, request):
        """Envía el correo de verificación con HTML"""
        try:
            verificacion_url = request.build_absolute_uri(
                reverse('verificar_email', kwargs={'token': self.token_verificacion})
            )
            
            context = {
                'usuario': self,
                'verification_link': verificacion_url,
            }
            
            html_content = render_to_string('paginas/email_verification.html', context)
            text_content = strip_tags(html_content)
            
            subject = '✅ Verifica tu correo electrónico - InnHub'
            from_email = settings.DEFAULT_FROM_EMAIL
            to_email = self.correo_per
            
            email = EmailMultiAlternatives(
                subject=subject,
                body=text_content,
                from_email=from_email,
                to=[to_email]
            )
            email.attach_alternative(html_content, "text/html")
            email.send(fail_silently=False)
            
            return True
            
        except Exception as e:
            print(f"❌ Error al enviar email: {str(e)}")
            import traceback
            traceback.print_exc()
            raise

    @property
    def get_iniciales(self):
        return f"{self.nom_usu[0]}{self.ape_usu[0]}".upper()
    
    def generar_codigo_verificacion(self):
        import random
        codigo = ''.join([str(random.randint(0, 9)) for _ in range(6)])
        self.codigo_verificacion = codigo
        self.codigo_expiracion = timezone.now() + timezone.timedelta(seconds=60)
        self.save()
        return codigo
    
    def verificar_codigo(self, codigo):
        if not self.codigo_verificacion or not self.codigo_expiracion:
            return False
        
        if timezone.now() > self.codigo_expiracion:
            return False
        
        return self.codigo_verificacion == codigo
    
    def limpiar_codigo(self):
        self.codigo_verificacion = None
        self.codigo_expiracion = None
        self.save()
    
    def incrementar_intentos_fallidos(self):
        self.intentos_codigo_fallidos += 1
        
        if self.intentos_codigo_fallidos >= 7:
            self.bloqueado_hasta = timezone.now() + datetime.timedelta(hours=24)
        elif self.intentos_codigo_fallidos >= 5:
            self.bloqueado_hasta = timezone.now() + datetime.timedelta(hours=1)
        elif self.intentos_codigo_fallidos >= 3:
            self.bloqueado_hasta = timezone.now() + datetime.timedelta(minutes=15)
        
        self.save()

    def puede_solicitar_codigo(self):
        """Verifica si puede solicitar un nuevo código"""
        ahora = timezone.now()
        
        if self.bloqueado_hasta and ahora < self.bloqueado_hasta:
            tiempo_restante = self.bloqueado_hasta - ahora
            minutos = int(tiempo_restante.total_seconds() / 60)
            horas = minutos // 60
            mins = minutos % 60
            
            if horas > 0:
                mensaje = f"Bloqueado por {horas} hora(s) y {mins} minuto(s)"
            else:
                mensaje = f"Bloqueado por {mins} minuto(s)"
            
            return False, mensaje
        
        if self.bloqueado_hasta and ahora >= self.bloqueado_hasta:
            self.intentos_codigo_fallidos = 0
            self.bloqueado_hasta = None
            self.save()
        
        if self.fecha_ultimo_reset_codigos != ahora.date():
            self.codigos_enviados_hoy = 0
            self.fecha_ultimo_reset_codigos = ahora.date()
            self.save()
        
        if self.codigos_enviados_hoy >= 5:
            return False, "Has alcanzado el límite de códigos por hora. Intenta más tarde."
        
        if self.ultimo_codigo_enviado:
            tiempo_desde_ultimo = (ahora - self.ultimo_codigo_enviado).total_seconds()
            if tiempo_desde_ultimo < 30:
                return False, f"Espera {int(30 - tiempo_desde_ultimo)} segundos antes de solicitar otro código"
        
        return True, None

    def registrar_codigo_enviado(self):
        """Registra que se envió un código"""
        ahora = timezone.now()
        
        if self.fecha_ultimo_reset_codigos != ahora.date():
            self.codigos_enviados_hoy = 0
            self.fecha_ultimo_reset_codigos = ahora.date()
        
        self.ultimo_codigo_enviado = ahora
        self.codigos_enviados_hoy += 1
        self.save()

    def resetear_intentos_codigo(self):
        self.intentos_codigo_fallidos = 0
        self.bloqueado_hasta = None
        self.save()
    
    def clean_nombre(self):
        return self.cleaned_data['nombre'].title()

    def clean_apellido(self):
        return self.cleaned_data['apellido'].title()
        
class UsuarioGrupos(models.Model):
    id = models.AutoField(primary_key=True)
    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE, db_column='cedula')
    grupo = models.ForeignKey(Group, on_delete=models.CASCADE, db_column='group_id')

    class Meta:
        managed = True
        db_table = 'usuario_grupos'
        unique_together = ('usuario', 'grupo')

class UsuarioUserPermissions(models.Model):
    id = models.AutoField(primary_key=True)
    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE, db_column='usuario_id')
    permission = models.ForeignKey(Permission, on_delete=models.CASCADE, db_column='permission_id')

    class Meta:
        managed = True
        db_table = 'usuario_user_permissions'
        unique_together = ('usuario', 'permission')

class Semillero(models.Model):
    id_sem = models.AutoField(primary_key=True)
    cod_sem = models.CharField(max_length=20)
    sigla = models.CharField(max_length=250)
    nombre = models.CharField(max_length=250)
    desc_sem = models.TextField()
    objetivo = models.TextField()
    estado = models.CharField(max_length=250)
    fecha_creacion = models.DateTimeField(auto_now_add=True, null=True)
    progreso_sem = models.IntegerField(default=0)

    proyectos = models.ManyToManyField(
        'Proyecto',
        through='SemilleroProyecto',
        related_name='semilleros',
        blank=True
    )

    class Meta:
        db_table = 'semillero'

    def calcular_progreso(self):
        proyectos = Proyecto.objects.filter(semilleroproyecto__id_sem=self)
        total_proyectos = proyectos.count()
        
        if total_proyectos == 0:
            self.progreso = 0
        else:
            suma_progreso = sum(p.progreso for p in proyectos)
            self.progreso = round(suma_progreso / total_proyectos)
        
        self.save(update_fields=['progreso'])
        return self.progreso

class Aprendiz(models.Model):
    cedula_apre = models.IntegerField(primary_key=True)
    tipo_doc = models.CharField(max_length=60)
    nombre = models.CharField(max_length=60)
    apellido = models.CharField(max_length=60)
    fecha_nacimiento = models.DateField()
    ficha = models.IntegerField()
    programa = models.CharField(max_length=100)
    correo_per = models.CharField(max_length=250)
    correo_ins = models.CharField(max_length=250)
    medio_bancario = models.CharField(max_length=45)
    numero_cuenta = models.CharField(max_length=255)
    modalidad = models.CharField(max_length=45)
    telefono = models.CharField(max_length=45)
    estado_apre = models.CharField(max_length=45)
    id_sem = models.ForeignKey(Semillero, on_delete=models.CASCADE, db_column='id_sem',  null=True, blank=True)
    fecha_registro = models.DateTimeField(auto_now_add=True, null=True)
    # CAMPO DE CONSENTIMIENTO
    acepta_tratamiento_datos = models.BooleanField(default=False)
    fecha_aceptacion_datos = models.DateTimeField(null=True, blank=True)

    class Meta:
        managed = True
        db_table = 'aprendiz'

    @property
    def get_iniciales(self):
        return f"{self.nombre[0]}{self.apellido[0]}".upper()
    
    proyectos = models.ManyToManyField(
        'Proyecto',
        through='ProyectoAprendiz',
        related_name='aprendices'
    )
    
    def clean_nombre(self):
        return self.cleaned_data['nombre'].title()

    def clean_apellido(self):
        return self.cleaned_data['apellido'].title()

class Proyecto(models.Model):
    cod_pro = models.IntegerField(primary_key=True)
    nom_pro = models.CharField(max_length=250)
    tipo = models.CharField(max_length=250)
    desc_pro = models.TextField()
    linea_tec = models.CharField(max_length=250)
    linea_inv = models.CharField(max_length=250)
    linea_sem = models.CharField(max_length=250)
    estado_pro = models.CharField(max_length=50, default='pendiente')
    progreso = models.IntegerField(default=0)
    fecha_creacion = models.DateTimeField(auto_now_add=True, null=True)
    notas = models.TextField()
    programa_formacion = models.CharField(max_length=250, null=True, blank=True)
    estado_original = models.CharField(max_length=245, null=True, blank=True)
    fecha_completado = models.DateField(null=True, blank=True)


    class Meta:
        managed = True
        db_table = 'proyecto'

class Documento(models.Model):
    cod_doc = models.IntegerField(primary_key=True)
    nom_doc = models.CharField(max_length=250)
    fecha_doc = models.CharField(max_length=250)
    tipo = models.CharField(max_length=250)
    archivo = models.FileField(upload_to='documentos/', null=True, blank=True)

    class Meta:
        managed = True
        db_table = 'documento'

class Entregable(models.Model):
    cod_entre = models.IntegerField(primary_key=True)
    nom_entre = models.CharField(max_length=250)
    fecha_inicio = models.DateField()
    fecha_fin = models.DateField()
    desc_entre = models.CharField(max_length=250)
    estado = models.CharField(max_length=45)
    cod_pro = models.ForeignKey(Proyecto, on_delete=models.CASCADE,db_column='cod_pro')
    
    class Meta:
        managed = True
        db_table = 'entregable'

class Archivo(models.Model):
    entregable = models.ForeignKey(
        Entregable,
        related_name='archivos',
        on_delete=models.CASCADE,
        db_column='cod_entre'
    )
    archivo = models.FileField(upload_to='entregables/%Y/%m/%d/')
    nombre = models.CharField(max_length=255, blank=True, null=True)
    fecha_subida = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'archivo'
        managed = True

class Evento(models.Model):
    cod_eve = models.AutoField(primary_key=True, )
    nom_eve = models.CharField(max_length=250)
    fecha_eve = models.DateField(max_length=250)
    desc_eve = models.CharField(max_length=250)
    modalidad_eve = models.CharField(max_length=250)
    direccion_eve = models.CharField(max_length=250)
    estado_eve = models.CharField(max_length=50)
    hora_inicio = models.TimeField(max_length=45)
    hora_fin = models.TimeField(max_length=45)
    fecha_estado = models.DateTimeField(null=True, blank=True)
    link = models.CharField(max_length=250, null=True, blank=True)
    cedula = models.ForeignKey(Usuario, on_delete=models.CASCADE,db_column='cedula')

    def save(self, *args, **kwargs):
        if self.pk:  
            old = Evento.objects.get(pk=self.pk)
            if old.estado_eve != self.estado_eve and self.estado_eve in ['Cancelado', 'Finalizado']:
                self.fecha_estado = timezone.now()
        super().save(*args, **kwargs)

    class Meta:
        managed = True
        db_table = 'evento'

class SemilleroDocumento(models.Model):
    id_doc = models.AutoField(primary_key=True)
    id_sem = models.ForeignKey(Semillero, on_delete=models.CASCADE, db_column='id_sem')
    cod_doc = models.ForeignKey(Documento, on_delete=models.CASCADE, db_column='cod_doc')

    class Meta:
        managed = True
        db_table = 'semillero_documento'
        unique_together = ('id_sem', 'cod_doc') 
class SemilleroProyecto(models.Model):
    sempro_id = models.AutoField(primary_key=True)
    id_sem = models.ForeignKey(Semillero, on_delete=models.CASCADE, db_column='id_sem')
    cod_pro = models.ForeignKey(Proyecto, on_delete=models.CASCADE, db_column='cod_pro')
    
    class Meta:
        managed = True
        db_table = 'semillero_proyecto'
        unique_together = ('id_sem', 'cod_pro')

class SemilleroUsuario(models.Model):
    semusu_id = models.AutoField(primary_key=True)
    es_lider = models.BooleanField(default=False)

    id_sem = models.ForeignKey(
        'Semillero',
        on_delete=models.CASCADE,
        db_column='id_sem' 
    )
    cedula = models.ForeignKey(
        'Usuario',
        on_delete=models.CASCADE,
        db_column='cedula' 
    )

    class Meta:
        managed = True
        db_table = 'semillero_usuario'
        unique_together = (('id_sem', 'cedula'),)
        

    def __str__(self):
        return f"{self.cedula.nom_usu} en {self.id_sem.nom_sem}"

class UsuarioProyecto(models.Model):
    usupro_id = models.AutoField(primary_key=True)
    cedula = models.ForeignKey(Usuario, on_delete=models.CASCADE, db_column='cedula')
    cod_pro = models.ForeignKey(Proyecto, on_delete=models.CASCADE, db_column='cod_pro')
    es_lider_pro = models.BooleanField(default=False)
    estado = models.CharField(max_length=10, default="activo")

    class Meta:
        managed = True
        db_table = 'usuario_proyecto'
        unique_together = (('cedula', 'cod_pro'),)  

class ProyectoAprendiz(models.Model):
    proapre_id = models.AutoField(primary_key=True)
    cedula_apre = models.ForeignKey(Aprendiz, on_delete=models.CASCADE, db_column='cedula_apre')
    cod_pro = models.ForeignKey(Proyecto, on_delete=models.CASCADE, db_column='cod_pro')
    estado = models.CharField(max_length=10, default="activo")  

    class Meta:
        managed = True
        db_table = 'proyecto_aprendiz'
        unique_together = ('cedula_apre', 'cod_pro') 

