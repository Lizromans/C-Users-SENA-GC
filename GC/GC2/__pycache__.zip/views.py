from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import permission_required
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.contrib.auth.hashers import check_password, make_password
from django.utils import timezone
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from django.utils.encoding import force_str, force_bytes
from django.contrib.auth.tokens import default_token_generator
from django.core.mail import send_mail, EmailMessage
from django.conf import settings
from django.template.loader import render_to_string
from django.http import JsonResponse, HttpResponse
from django.db.models import Q, Avg, Case, When, Value, IntegerField, CharField, F, DateTimeField
from django.db.models.functions import Cast
from django.urls import reverse
from django.utils.dateparse import parse_date
from django.views.decorators.http import require_http_methods
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.views.decorators.csrf import csrf_exempt
from django.core import serializers
from django.apps import apps
from .forms import (
    UsuarioRegistroForm, 
    FormularioSoporte,
    AprendizForm,
    construir_descripcion_entregable, 
    limpiar_descripcion_anterior,
    CATEGORIAS_MAP,  
    PRODUCTOS_MAP,  
    CAMPOS_LEGIBLES
)
from .models import (
    Documento, Usuario, Semillero, SemilleroUsuario, Archivo, 
    Aprendiz, ProyectoAprendiz, Proyecto, UsuarioProyecto, 
    SemilleroProyecto, Entregable, SemilleroDocumento, Evento
)
from .notifications import (
    obtener_notificaciones_usuario, 
    obtener_notificaciones_con_resumen
)
from . import models
import os
import random
import json
import zipfile
from functools import wraps
from datetime import datetime, timedelta, date
from io import BytesIO
from itertools import chain
from operator import attrgetter
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.units import cm
from reportlab.lib.utils import ImageReader
import openpyxl
from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, PieChart, Reference, Series
from openpyxl.drawing.image import Image as XLImage
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from dateutil.relativedelta import relativedelta
from cryptography.fernet import Fernet
import base64
import hashlib
from datetime import datetime
from django.utils.timezone import now


# Funciones de cifrado/descifrado
def cifrar_numero(numero):
    if not numero:
        return numero
    try:
        key = hashlib.sha256(settings.SECRET_KEY.encode()).digest()
        cipher = Fernet(base64.urlsafe_b64encode(key))
        return cipher.encrypt(str(numero).encode()).decode()
    except:
        return numero

def descifrar_numero(numero_cifrado):
    if not numero_cifrado:
        return numero_cifrado
    try:
        key = hashlib.sha256(settings.SECRET_KEY.encode()).digest()
        cipher = Fernet(base64.urlsafe_b64encode(key))
        return cipher.decrypt(numero_cifrado.encode()).decode()
    except:
        return "****"  

@require_http_methods(["GET"])
def api_notificaciones(request):
    try:
        if not request.session.get('cedula'):
            return JsonResponse({
                'success': False,
                'error': 'No hay sesión activa',
                'notificaciones': [],
                'count': 0
            }, status=401)
    
        cedula = request.session.get('cedula')
        
        try:
            usuario = Usuario.objects.get(cedula=cedula)
        except Usuario.DoesNotExist:
            return JsonResponse({
                'success': False,
                'error': 'Usuario no encontrado',
                'notificaciones': [],
                'count': 0
            }, status=404)
        
        resultado = obtener_notificaciones_usuario(usuario, limite=18)
        
        return JsonResponse({
            'success': True,
            'notificaciones': resultado['notificaciones'],
            'count': resultado['total'],
            'resumen': resultado['resumen']
        })
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        
        return JsonResponse({
            'success': False,
            'error': str(e),
            'notificaciones': [],
            'count': 0
        }, status=500)

@require_http_methods(["GET"])
def api_todas_notificaciones(request):
    try:
        if not request.session.get('cedula'):
            return JsonResponse({
                'success': False,
                'error': 'No hay sesión activa',
                'notifications': []
            }, status=401)
        
        cedula = request.session.get('cedula')
        
        try:
            usuario = Usuario.objects.get(cedula=cedula)
        except Usuario.DoesNotExist:
            return JsonResponse({
                'success': False,
                'error': 'Usuario no encontrado',
                'notifications': []
            }, status=404)
        
        resultado = obtener_notificaciones_usuario(usuario, limite=50)
        
        return JsonResponse({
            'success': True,
            'notifications': resultado['notificaciones'],
            'count': resultado['total'],
            'resumen': resultado['resumen']
        })
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        
        return JsonResponse({
            'success': False,
            'error': str(e),
            'notifications': []
        }, status=500)

@require_http_methods(["POST"])
def api_marcar_leidas(request):
    try:
        if not request.session.get('cedula'):
            return JsonResponse({
                'success': False,
                'error': 'No hay sesión activa'
            }, status=401)
        
        return JsonResponse({
            'success': True,
            'message': 'Notificaciones marcadas como leídas'
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)

@require_http_methods(["POST"])
def api_limpiar_todas(request):
    try:
        if not request.session.get('cedula'):
            return JsonResponse({
                'success': False,
                'error': 'No hay sesión activa'
            }, status=401)
        
        return JsonResponse({
            'success': True,
            'message': 'Notificaciones eliminadas'
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)  


# VISTAS DE LOGIN Y REGISTRO
def registro(request):
    if request.method == 'POST':
        form = UsuarioRegistroForm(request.POST)

        if form.is_valid():
            try:
                usuario = form.save()

                try:
                    usuario.generar_token_verificacion()
                    usuario.enviar_email_verificacion(request)
                    messages.success(
                        request,
                        "¡Registro exitoso! Por favor, revisa tu correo y verifica tu email para poder iniciar sesión."
                    )

                except Exception as email_error:
                    print(f"❌ Error al enviar email de verificación: {email_error}")
                    messages.warning(
                        request,
                        "Usuario registrado correctamente, pero hubo un problema al enviar el correo de verificación. "
                        "Por favor contacta al administrador para que reenvíe el correo."
                    )

                return redirect('iniciarsesion')

            except Exception as e:
                messages.error(request, f"Error al registrar usuario: {str(e)}")

        else:
            errores_contexto = {}
            mapeo_errores = {
                'cedula': 'error_cedula_reg',
                'nom_usu': 'error_nom_usu',
                'ape_usu': 'error_ape_usu',
                'correo_per': 'error_correo_per',
                'rol': 'error_rol_reg',
                'contraseña': 'error_contrasena',
                'conf_contraseña': 'error_conf_contrasena',
            }

            for field, errors in form.errors.items():
                if field in mapeo_errores:
                    errores_contexto[mapeo_errores[field]] = errors[0]
                elif field == '__all__':
                    messages.error(request, errors[0])

            valores_preservados = {
                'cedula_reg': form.data.get('cedula', ''),
                'nom_usu': form.data.get('nom_usu', ''),
                'ape_usu': form.data.get('ape_usu', ''),
                'correo_per': form.data.get('correo_per'),
                'rol_reg': form.data.get('rol', ''),
            }

    else:
        form = UsuarioRegistroForm()
        errores_contexto = {}
        valores_preservados = {}

    return render(request, 'paginas/registro.html', {
        'form': form,
        'current_page_name': 'Registro',
        'mostrar_registro': True,
        **errores_contexto,
        **valores_preservados,
    })
def iniciarsesion(request):
    if request.method == 'POST':
        cedula = request.POST.get('cedula', '').strip()
        password = request.POST.get('password', '')
        rol = request.POST.get('rol', '').strip()

        # 1. Validaciones de campos vacíos
        errores = {}
        if not rol:
            errores['error_rol'] = "Debe seleccionar un rol."
        if not cedula:
            errores['error_user'] = "La cédula es obligatoria."
        if not password:
            errores['error_password'] = "La contraseña es obligatoria."

        if errores:
            return render(request, 'paginas/registro.html', {
                **errores,
                'cedula': cedula,
                'rol': rol,
                'mostrar_registro': False,
                'current_page_name': 'Iniciar Sesión'
            })

        # 2. Verificar que el usuario existe
        try:
            usuario = Usuario.objects.get(cedula=cedula)
        except Usuario.DoesNotExist:
            return render(request, 'paginas/registro.html', {
                'error_user': 'Usuario no registrado.',
                'cedula': cedula,
                'rol': rol,
                'mostrar_registro': False,
                'current_page_name': 'Iniciar Sesión'
            })

        # 3. Verificar contraseña
        if not usuario.check_password(password):
            return render(request, 'paginas/registro.html', {
                'error_password': 'Contraseña incorrecta.',
                'cedula': cedula,
                'rol': rol,
                'mostrar_registro': False,
                'current_page_name': 'Iniciar Sesión'
            })

        # 4. Verificar rol
        if usuario.rol != rol:
            return render(request, 'paginas/registro.html', {
                'error_rol': 'El rol seleccionado no coincide con tu usuario.',
                'cedula': cedula,
                'rol': rol,
                'mostrar_registro': False,
                'current_page_name': 'Iniciar Sesión'
            })

        # 5. Verificar cuenta activa
        if usuario.estado != 'Activo':
            return render(request, 'paginas/registro.html', {
                'error_user': 'Tu cuenta está desactivada. Contacta al administrador.',
                'cedula': cedula,
                'rol': rol,
                'mostrar_registro': False,
                'current_page_name': 'Iniciar Sesión'
            })

        # 6. Verificar email — SIEMPRE antes de crear sesión
        if not usuario.email_verificado:
            request.session.flush()  # Limpiar cualquier sesión residual
            return render(request, 'paginas/registro.html', {
                'error_user': 'Debes verificar tu correo electrónico antes de iniciar sesión. Revisa tu bandeja de entrada.',
                'cedula': cedula,
                'rol': rol,
                'mostrar_registro': False,
                'current_page_name': 'Iniciar Sesión'
            })

        # 7. Todo validado — crear sesión
        request.session.flush()  # Limpiar sesión anterior por seguridad
        request.session['cedula'] = usuario.cedula
        request.session['nom_usu'] = usuario.nom_usu
        request.session['ape_usu'] = usuario.ape_usu
        request.session['rol'] = usuario.rol
        request.session['correo_per'] = usuario.correo_per

        login(request, usuario)
        request.session.set_expiry(3600)

        usuario.last_login = timezone.now()
        usuario.save(update_fields=['last_login'])

        messages.success(request, f"¡Bienvenido, {usuario.nom_usu}!")

        # 8. Redirigir según perfil completo o no
        perfil_incompleto = (
            not usuario.correo_ins or
            not usuario.telefono or
            not usuario.fecha_nacimiento or
            not usuario.vinculacion_laboral or
            not usuario.dependencia
        )

        if perfil_incompleto:
            messages.info(request, "Por favor completa tu perfil con la información faltante.")
            return redirect('perfil')

        return redirect('home')

    # GET — mostrar formulario de login
    return render(request, 'paginas/registro.html', {
        'mostrar_registro': False,
        'current_page_name': 'Iniciar Sesión'
    })

# Vista para verificar el correo electrónico
def verificar_email(request, token):
    try:
        usuario = Usuario.objects.get(token_verificacion=token)
        
        if usuario.token_expira and usuario.token_expira < timezone.now():
            messages.error(request, "El enlace de verificación ha expirado. Por favor, solicita uno nuevo.")
            return redirect('iniciarsesion')
        
        usuario.email_verificado = True
        usuario.token_verificacion = None
        usuario.token_expira = None
        usuario.save()
        
        messages.success(
            request, 
            "¡Correo verificado exitosamente! Ahora puedes iniciar sesión con tus credenciales."
        )
        return redirect('iniciarsesion')
        
    except Usuario.DoesNotExist:
        messages.error(request, "El enlace de verificación no es válido.")
        return redirect('iniciarsesion')
    
# Vistas recuperar contraseña
def mostrar_recuperar_contrasena(request):

    return render(request, 'paginas/registro.html', {
        'mostrar_modal': True,
        'show_login': True,  
        'current_page_name': 'Recuperar Contraseña'
    })

def recuperar_contrasena(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        
        if not email:
            return render(request, 'iniciarsesion', {
                'mostrar_modal': True,
                'email_error': 'El correo electrónico es obligatorio',
                'current_page_name': 'Recuperar Contraseña'
            })
        
        try:
            admin = Usuario.objects.filter(correo_per=email).first()
            
            if admin:
                uid = urlsafe_base64_encode(force_bytes(admin.pk))
                token = default_token_generator.make_token(admin)

                reset_link = f"{request.scheme}://{request.get_host()}/reset-password/{uid}/{token}/"
                
                try:
                    subject = "Restablecimiento de contraseña - InnHub"
                    message = render_to_string('paginas/reset_password_email.html', {
                        'user': admin,
                        'reset_link': reset_link,
                        'site_name': 'InnHub'
                    })
                    
                    send_mail(
                        subject,
                        '',  # Mensaje de texto plano vacío
                        settings.DEFAULT_FROM_EMAIL,
                        [admin.correo_per],
                        html_message=message,
                        fail_silently=False
                    )
                    
                except Exception as email_error:
                    messages.error(request, f"Problema al enviar el correo: {email_error}")
                    return redirect('iniciarsesion')
                
            messages.success(request, "Si el correo está asociado a una cuenta, recibirás instrucciones para restablecer tu contraseña.")
            return redirect('iniciarsesion')
            
        except Exception as e:
            messages.error(request, "Error al procesar la solicitud. Intenta nuevamente.")
            return redirect('iniciarsesion')
    
    return redirect('iniciarsesion')

def reset_password(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        usuario = Usuario.objects.get(pk=uid)

        if default_token_generator.check_token(usuario, token):
            return render(request, 'paginas/reset_password.html', {
                'valid': True,
                'uidb64': uidb64,
                'token': token,
                'current_page_name': 'Restablecer Contraseña'
            })
        else:
            messages.error(request, "El enlace de restablecimiento no es válido o ha expirado.")
            return redirect('iniciarsesion')

    except Exception as e:
        messages.error(request, "Error al procesar el enlace de restablecimiento.")
        return redirect('iniciarsesion')

def reset_password_confirm(request):
    if request.method == 'POST':
        uidb64 = request.POST.get('uidb64')
        token = request.POST.get('token')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')

        if password1 != password2:
            return render(request, 'paginas/reset_password.html', {
                'valid': True,
                'uidb64': uidb64,
                'token': token,
                'error': 'Las contraseñas no coinciden.',
                'current_page_name': 'Restablecer Contraseña'
            })

        try:
            uid = force_str(urlsafe_base64_decode(uidb64))
            usuario = Usuario.objects.get(pk=uid)

            if default_token_generator.check_token(usuario, token):

                usuario.set_password(password1)
                usuario.save()

                messages.success(request, "Tu contraseña ha sido restablecida con éxito. Ahora puedes iniciar sesión.")
                return redirect('iniciarsesion')
            else:
                messages.error(request, "El enlace de restablecimiento no es válido o ha expirado.")
                return redirect('iniciarsesion')

        except (TypeError, ValueError, OverflowError, Usuario.DoesNotExist) as e:
            messages.error(request, "El enlace de restablecimiento no es válido.")
            return redirect('iniciarsesion')
    
    return redirect('iniciarsesion')

def login_required(view_func):
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        cedula = request.session.get('cedula')
        
        if not cedula:
            messages.error(request, "Debes iniciar sesión para acceder a esta página")
            return redirect('iniciarsesion')
        
        try:
            from .models import Usuario
            usuario = Usuario.objects.get(cedula=cedula)

            if not usuario.email_verificado:
                request.session.flush()
                messages.error(request, "Debes verificar tu correo electrónico antes de acceder.")
                return redirect('iniciarsesion')

            if usuario.estado and usuario.estado != 'Activo':
                request.session.flush() 
                messages.error(request, "Tu cuenta no está activa")
                return redirect('iniciarsesion')
                
        except Usuario.DoesNotExist:
            request.session.flush()
            messages.error(request, "Usuario no encontrado. Por favor inicia sesión nuevamente")
            return redirect('iniciarsesion')
        
        return view_func(request, *args, **kwargs)
    
    return _wrapped_view

# VISTA DE PRIVACIDAD
@login_required
def privacidad(request):
    usuario_id = request.session.get('cedula')
    
    try:
        usuario = Usuario.objects.get(pk=usuario_id)
        
        if request.method == 'POST':
            contraseña_actual = request.POST.get('contraseña_actual')
            nueva_contraseña = request.POST.get('nueva_contraseña')
            confirmar_contraseña = request.POST.get('confirmar_contraseña')
            
            if not check_password(contraseña_actual, usuario.password):
                messages.error(request, "La contraseña actual es incorrecta.")
                return redirect('privacidad')
        
            if nueva_contraseña != confirmar_contraseña:
                messages.error(request, "Las contraseñas nuevas no coinciden.")
                return redirect('privacidad')
            
            if len(nueva_contraseña) < 8:
                messages.error(request, "La contraseña debe tener al menos 8 caracteres.")
                return redirect('privacidad')
            
            usuario.set_password(nueva_contraseña)
            usuario.save()

            messages.success(request, "Contraseña actualizada correctamente.")
            return redirect('home')
            
    except Usuario.DoesNotExist:
        messages.error(request, "Usuario no encontrado. Por favor, inicie sesión nuevamente.")
        return redirect('iniciarsesion')
    except Exception as e:
        messages.error(request, f"Error al actualizar la contraseña: {str(e)}")
        return redirect('privacidad')
    
    return render(request, 'paginas/home.html', {
        'current_page': 'privacidad',
        'current_page_name': 'Privacidad'
    })

# VISTAS DE HOME 
@login_required
def home(request):
    cedula = request.session.get('cedula')

    try:
        usuario = Usuario.objects.get(cedula=cedula)
    except Usuario.DoesNotExist:
        messages.error(request, "Usuario no encontrado.")
        return redirect('iniciarsesion')

    total_semilleros = usuario.semilleros.count()
    total_proyectos = usuario.proyectos.count()
    total_aprendices = Aprendiz.objects.filter(
        proyectos__in=usuario.proyectos.all()
    ).distinct().count()

    mis_semilleros_ids = SemilleroUsuario.objects.filter(
        cedula=usuario
    ).values_list('id_sem', flat=True)
    
    mis_proyectos_ids = UsuarioProyecto.objects.filter(
        cedula=usuario
    ).values_list('cod_pro', flat=True)

    fecha_limite = timezone.now() - timedelta(days=7)
    
    semilleros_recientes = Semillero.objects.filter(
        id_sem__in=mis_semilleros_ids,
        fecha_creacion__gte=fecha_limite
    ).annotate(
        tipo_actividad=Value('semillero', output_field=CharField()),
        fecha_actividad=F('fecha_creacion')
    )
    

    proyectos_directos = Proyecto.objects.filter(
        cod_pro__in=mis_proyectos_ids,
        fecha_creacion__gte=fecha_limite
    )

    proyectos_semilleros = Proyecto.objects.filter(
        semilleroproyecto__id_sem__in=mis_semilleros_ids,
        fecha_creacion__gte=fecha_limite
    )
    
    proyectos_recientes = (proyectos_directos | proyectos_semilleros).distinct().annotate(
        tipo_actividad=Value('proyecto', output_field=CharField()),
        fecha_actividad=F('fecha_creacion')
    )

    todos_mis_proyectos = (
        Proyecto.objects.filter(cod_pro__in=mis_proyectos_ids) | 
        Proyecto.objects.filter(semilleroproyecto__id_sem__in=mis_semilleros_ids)
    ).distinct().values_list('cod_pro', flat=True)
    
    entregables_recientes = Entregable.objects.filter(
        cod_pro__in=todos_mis_proyectos,
        fecha_inicio__gte=fecha_limite.date()
    ).annotate(
        tipo_actividad=Value('entregable', output_field=CharField()),
        fecha_actividad=Cast(F('fecha_inicio'), output_field=DateTimeField())
    )

    eventos_recientes = Evento.objects.filter(
        fecha_eve__gte=fecha_limite.date()
    ).annotate(
        tipo_actividad=Value('evento', output_field=CharField()),
        
        fecha_actividad=Cast(F('fecha_eve'), output_field=DateTimeField())
    )

    actividades = sorted(
        chain(semilleros_recientes, proyectos_recientes, entregables_recientes, eventos_recientes),
        key=lambda x: x.fecha_actividad if hasattr(x, 'fecha_actividad') else timezone.now(),
        reverse=True
    )[:10]

    return render(request, 'paginas/home.html', {
        'current_page': 'home',
        'current_page_name': 'Inicio',
        'usuario': usuario,
        'total_semilleros': total_semilleros,
        'total_proyectos': total_proyectos,
        'total_aprendices': total_aprendices,
        'actividades': actividades,
    })

# VISTAS PERFIL
@login_required
def perfil(request):
    cedula = request.session.get('cedula')
    try:
        usuario = Usuario.objects.get(cedula=cedula)
    except Usuario.DoesNotExist:
        messages.error(request, "Usuario no encontrado.")
        return redirect('iniciarsesion')

    ultimo_acceso = "Sin registro"
    if usuario.last_login:
        tiempo = timezone.now() - usuario.last_login
        dias, segundos = tiempo.days, tiempo.seconds
        if dias == 0:
            if segundos < 60:
                ultimo_acceso = "Hace unos segundos"
            elif segundos < 3600:
                minutos = segundos // 60
                ultimo_acceso = f"Hace {minutos} minuto{'s' if minutos != 1 else ''}"
            else:
                horas = segundos // 3600
                ultimo_acceso = f"Hace {horas} hora{'s' if horas != 1 else ''}"
        elif dias == 1:
            ultimo_acceso = "Ayer"
        elif dias < 7:
            ultimo_acceso = f"Hace {dias} día{'s' if dias != 1 else ''}"
        elif dias < 30:
            semanas = dias // 7
            ultimo_acceso = f"Hace {semanas} semana{'s' if semanas != 1 else ''}"
        elif dias < 365:
            meses = dias // 30
            ultimo_acceso = f"Hace {meses} mes{'es' if meses != 1 else ''}"
        else:
            años = dias // 365
            ultimo_acceso = f"Hace {años} año{'s' if años != 1 else ''}"

    if request.method == 'POST':
        usuario.nom_usu = request.POST.get('nombre1')
        usuario.ape_usu = request.POST.get('nombre2')
        usuario.correo_per = request.POST.get('correo1')
        usuario.telefono = request.POST.get('celular')
        usuario.fecha_nacimiento = request.POST.get('fecha')
        usuario.correo_ins = request.POST.get('correo2')
        usuario.vinculacion_laboral = request.POST.get('vinculacion')
        usuario.dependencia = request.POST.get('dependencia')
        usuario.rol = request.POST.get('rol')
        usuario.save()

        request.session['nom_usu'] = usuario.nom_usu
        request.session['ape_usu'] = usuario.ape_usu
        request.session['rol'] = usuario.rol
        
        messages.success(request, "Cambios guardados correctamente.")
        return redirect('perfil')

    semilleros = usuario.semilleros.all()
    total_semilleros = semilleros.count()

    proyectos = SemilleroProyecto.objects.filter(
        cod_pro__usuarios=usuario
    ).select_related('id_sem', 'cod_pro')
    total_proyectos = proyectos.count()

    context = {
        'usuario': usuario,
        'ultimo_acceso': ultimo_acceso,
        'semilleros': semilleros,
        'total_semilleros': total_semilleros,
        'proyectos': proyectos,
        'total_proyectos': total_proyectos,
    }

    return render(request, 'paginas/perfil.html', context)

# VISTA ACTUALIZAR FOTO PERFIL
@login_required
def actualizar_foto(request):
    if request.method == 'POST':
        usuario_id = request.session.get('cedula')
        usuario = Usuario.objects.get(cedula=usuario_id)

        if 'imagen_perfil' in request.FILES:
            if usuario.imagen_perfil:
                usuario.imagen_perfil.delete(save=False)
        
            usuario.imagen_perfil = request.FILES['imagen_perfil']
            usuario.save()
            messages.success(request, "Imagen actualizada correctamente.")
        else:
            messages.error(request, "No se seleccionó ninguna imagen.")
        
        return redirect('perfil') 

# VISTAS SEMILLEROS
@login_required
def semilleros(request):
    cedula = request.session.get('cedula')  
    
    try:
        usuario = Usuario.objects.get(cedula=cedula)
    except Usuario.DoesNotExist:
        messages.error(request, "Usuario no encontrado.")
        return redirect('iniciarsesion')
    
    semilleros = usuario.semilleros.all()

    buscar = request.GET.get("buscar")
    if buscar:
        semilleros = semilleros.filter(
            Q(cod_sem__icontains=buscar) |
            Q(sigla__icontains=buscar) |
            Q(nombre__icontains=buscar)
        )

    fecha_inicio = request.GET.get('fecha_inicio')
    fecha_fin = request.GET.get('fecha_fin')
    
    if fecha_inicio:
        fecha_inicio_parsed = parse_date(fecha_inicio)
        if fecha_inicio_parsed:
            semilleros = semilleros.filter(fecha_creacion__gte=fecha_inicio_parsed)
    
    if fecha_fin:
        fecha_fin_parsed = parse_date(fecha_fin)
        if fecha_fin_parsed:
            semilleros = semilleros.filter(fecha_creacion__lte=fecha_fin_parsed)

    ordenar = request.GET.get("ordenar", "")
    if ordenar == "recientes":
        semilleros = semilleros.order_by("-fecha_creacion")
    elif ordenar == "antiguos":
        semilleros = semilleros.order_by("fecha_creacion")
    elif ordenar == "az":
        semilleros = semilleros.order_by("nombre")
    elif ordenar == "za":
        semilleros = semilleros.order_by("-nombre")

    for semillero in semilleros:
        actualizar_progreso_semillero(semillero)

        cedulas = SemilleroUsuario.objects.filter(
            id_sem=semillero
        ).values_list('cedula', flat=True)
        
        total_usuarios = Usuario.objects.filter(cedula__in=cedulas).count()
        total_aprendices = Aprendiz.objects.filter(id_sem=semillero).count()
        semillero.total_miembros = total_usuarios + total_aprendices

        proyectos = SemilleroProyecto.objects.filter(id_sem=semillero)
        total_proyectos = proyectos.count()
        semillero.total_proyectos = total_proyectos

        total_entregables = Entregable.objects.filter(
            cod_pro__in=proyectos.values('cod_pro')
        ).count()
        semillero.total_entregables = total_entregables
        
    return render(request, 'paginas/semilleros.html', {
        'semilleros': semilleros,
        'usuario': usuario
    })

@login_required
@permission_required('GC2.add_semillero')
def crear_semillero(request):
    cedula = request.session.get('cedula')
    try:
        usuario = Usuario.objects.get(cedula=cedula)
    except Usuario.DoesNotExist:
        messages.error(request, "Usuario no encontrado.")
        return redirect('iniciarsesion')

    if request.method == 'POST':
        cod_sem = request.POST.get('cod_sem')  
        sigla = request.POST.get('sigla')
        nombre = request.POST.get('nombre')
        desc_sem = request.POST.get('desc_sem')
        objetivo = request.POST.getlist('objetivo')

        objetivo_texto = "\n".join(objetivo)

        if not all([cod_sem, sigla, nombre, desc_sem, objetivo_texto]):
            messages.error(request, 'Todos los campos son obligatorios')
            return redirect('semilleros')

        try:
            semillero = Semillero(
                cod_sem=cod_sem,
                sigla=sigla,
                nombre=nombre,
                desc_sem=desc_sem,
                objetivo=objetivo_texto,
                estado='activo',
                progreso_sem=0
            )
            semillero.save()

            SemilleroUsuario.objects.create(
                id_sem=semillero,
                cedula=usuario,
                es_lider=True
            )

            messages.success(request, f'Semillero "{sigla}" creado exitosamente')
            return redirect('semilleros')

        except Exception as e:
            messages.error(request, f'Error al crear semillero: {str(e)}')
            return redirect('semilleros')

    return redirect('semilleros')

@login_required
@permission_required('GC2.change_semillero')
def editar_semillero(request, id_sem):
    cedula = request.session.get('cedula')
    try:
        usuario = Usuario.objects.get(cedula=cedula)
    except Usuario.DoesNotExist:
        messages.error(request, "Usuario no encontrado.")
        return redirect('iniciarsesion')

    semillero = get_object_or_404(Semillero, id_sem=id_sem)

    if request.method == 'POST':
        sigla = request.POST.get('sigla')
        cod_sem = request.POST.get('cod_sem')
        nombre = request.POST.get('nombre')
        desc_sem = request.POST.get('desc_sem')
        objetivos = request.POST.getlist('objetivo')

        if not all([sigla, cod_sem, nombre, desc_sem]):
            messages.error(request, 'Todos los campos son obligatorios.')
            return redirect('semilleros')

        objetivo_texto = "\n".join([o.strip() for o in objetivos if o.strip()])

        try:
            semillero.sigla = sigla
            semillero.cod_sem = cod_sem
            semillero.nombre = nombre
            semillero.desc_sem = desc_sem
            semillero.objetivo = objetivo_texto
            semillero.save()

            messages.success(request, f'Semillero "{nombre}" actualizado exitosamente.')
        except Exception as e:
            messages.error(request, f'Error al actualizar semillero: {str(e)}')

        return redirect('semilleros')

    return redirect('semilleros')

@login_required
@permission_required('GC2.delete_semillero')
def eliminar_semilleros(request):
    cedula = request.session.get('cedula')
    try:
        usuario = Usuario.objects.get(cedula=cedula)
    except Usuario.DoesNotExist:
        messages.error(request, "Usuario no encontrado.")
        return redirect('iniciarsesion')
    
    if request.method == 'POST':
        semilleros_ids = request.POST.getlist('semilleros_eliminar')
        
        if not semilleros_ids:
            messages.warning(request, 'No se seleccionó ningún semillero para eliminar')
            return redirect('semilleros')
        
        try:
            eliminados = 0
            errores = []
            
            for id_sem in semilleros_ids:
                try:
                    semillero = Semillero.objects.get(id_sem=id_sem)

                    lideres_sem = SemilleroUsuario.objects.filter(
                        id_sem=semillero, 
                        es_lider=True
                    ).select_related('cedula')
                    
                    for relacion_lider in lideres_sem:
                        usuario_lider = relacion_lider.cedula
                        if usuario_lider.rol == 'Líder de Semillero':
                            otros_semilleros_lider = SemilleroUsuario.objects.filter(
                                cedula=usuario_lider, 
                                es_lider=True
                            ).exclude(id_sem=semillero).exists()
                            
                            if not otros_semilleros_lider:
                                if hasattr(usuario_lider, 'rol_original') and usuario_lider.rol_original:
                                    usuario_lider.rol = usuario_lider.rol_original
                                elif usuario_lider.vinculacion_laboral and 'instructor' in usuario_lider.vinculacion_laboral.lower():
                                    usuario_lider.rol = 'Instructor'
                                else:
                                    usuario_lider.rol = 'Investigador'
                                usuario_lider.save()

                    proyectos = Proyecto.objects.filter(
                        semilleroproyecto__id_sem=semillero
                    )
                    
                    for proyecto in proyectos:
                        lideres_proyecto = UsuarioProyecto.objects.filter(
                            cod_pro=proyecto, 
                            es_lider_pro=True
                        ).select_related('cedula')
                        
                        for relacion_lider in lideres_proyecto:
                            usuario_lider = relacion_lider.cedula
                            if usuario_lider.rol == 'Líder de Proyecto':
                                otros_proyectos_lider = UsuarioProyecto.objects.filter(
                                    cedula=usuario_lider, 
                                    es_lider_pro=True
                                ).exclude(cod_pro=proyecto).exists()
                                
                                if not otros_proyectos_lider:
                                    if hasattr(usuario_lider, 'rol_original') and usuario_lider.rol_original:
                                        usuario_lider.rol = usuario_lider.rol_original
                                    else:
                                        es_lider_sem = SemilleroUsuario.objects.filter(
                                            cedula=usuario_lider, 
                                            es_lider=True
                                        ).exists()
                                        if es_lider_sem:
                                            usuario_lider.rol = 'Líder de Semillero'
                                        elif usuario_lider.vinculacion_laboral and 'instructor' in usuario_lider.vinculacion_laboral.lower():
                                            usuario_lider.rol = 'Instructor'
                                        else:
                                            usuario_lider.rol = 'Investigador'
                                    usuario_lider.save()
                        
                        entregables = Entregable.objects.filter(cod_pro=proyecto)
                        for entregable in entregables:
                            archivos = Archivo.objects.filter(entregable=entregable)
                            for archivo in archivos:
                                if archivo.archivo:
                                    archivo.archivo.delete(save=False)
                            archivos.delete()
                        entregables.delete()
                    
                        UsuarioProyecto.objects.filter(cod_pro=proyecto).delete()
                        ProyectoAprendiz.objects.filter(cod_pro=proyecto).delete()

                        SemilleroProyecto.objects.filter(cod_pro=proyecto).delete()

                        proyecto.delete()

                    documentos_semillero = SemilleroDocumento.objects.filter(id_sem=semillero)
                    for rel_doc in documentos_semillero:
                        documento = rel_doc.cod_doc
                        if documento.archivo:
                            documento.archivo.delete(save=False)
                        documento.delete()
                    documentos_semillero.delete()

                    SemilleroUsuario.objects.filter(id_sem=semillero).delete()

                    Aprendiz.objects.filter(id_sem=semillero).delete()

                    semillero.delete()
                    
                    eliminados += 1
                    
                except Semillero.DoesNotExist:
                    errores.append(f'Semillero con ID {id_sem} no encontrado')
                except Exception as e:
                    errores.append(f'Error al eliminar semillero {id_sem}: {str(e)}')

            if eliminados > 0:
                messages.success(
                    request, 
                    f'✅ {eliminados} semillero(s) eliminado(s) correctamente y roles restaurados.'
                )
            
            if errores:
                for error in errores:
                    messages.error(request, f'⚠️ {error}')
            
            return redirect('semilleros')
            
        except Exception as e:
            messages.error(request, f'⚠️ Error general al eliminar semilleros: {str(e)}')
            return redirect('semilleros')
    
    # Si no es POST, redirigir
    return redirect('semilleros')

@login_required
def cambiar_estado_semillero(request, id_sem):
    cedula = request.session.get('cedula')  
    
    try:
        usuario = Usuario.objects.get(cedula=cedula)
    except Usuario.DoesNotExist:
        messages.error(request, "Usuario no encontrado.")
        return redirect('iniciarsesion') 
    
    semillero = get_object_or_404(Semillero, id_sem=id_sem)

    if semillero.estado == 'desactivado':
        semillero.estado = 'activo'
        semillero.activo = True

        messages.success(
            request,
            f'El semillero "{semillero.nombre}" fue ACTIVADO'
        )
    else:
        semillero.estado = 'desactivado'
        semillero.activo = False

        messages.warning(
            request,
            f'El semillero "{semillero.nombre}" fue DESACTIVADO'
        )

    semillero.save()
    
    return redirect('semilleros')

def semillero_activo_requerido(view_func):
    @wraps(view_func)
    def wrapper(request, id_sem, *args, **kwargs):
        try:
            semillero = get_object_or_404(Semillero, id_sem=id_sem)
            
            if semillero.estado == 'desactivado' or not semillero.estado == 'activo':
                messages.error(
                    request,
                    f'⚠️ El semillero "{semillero.nombre}" está desactivado. '
                    f'Debes activarlo primero para realizar esta acción.'
                )
                return redirect('semilleros')
        
            return view_func(request, id_sem, *args, **kwargs)
            
        except Semillero.DoesNotExist:
            messages.error(request, "❌ Semillero no encontrado.")
            return redirect('semilleros')
    
    return wrapper

def actualizar_progreso_semillero(semillero):
    proyectos = Proyecto.objects.filter(semilleroproyecto__id_sem=semillero)
    total_proyectos = proyectos.count()

    if total_proyectos == 0:
        semillero.progreso_sem = 0
    else:
        promedio = proyectos.aggregate(Avg('progreso'))['progreso__avg']
        semillero.progreso_sem = round(promedio) if promedio else 0

    semillero.save(update_fields=['progreso_sem'])
    return semillero.progreso_sem

@login_required
def resumen(request, id_sem):
    usuario_id = request.session.get('cedula')
    if not usuario_id:
        messages.error(request, "Debes iniciar sesión.")
        return redirect('iniciarsesion')

    try:
        usuario = Usuario.objects.get(cedula=usuario_id)
    except Usuario.DoesNotExist:
        messages.error(request, "Usuario no encontrado.")
        return redirect('iniciarsesion')

    semillero = get_object_or_404(Semillero, id_sem=id_sem)

    objetivos_lista = []
    if semillero.objetivo:
        objetivos_lista = [o.strip() for o in semillero.objetivo.split("\n") if o.strip()]

    cedulas = SemilleroUsuario.objects.filter(id_sem=semillero).values_list('cedula', flat=True)
    total_usuarios = Usuario.objects.filter(cedula__in=cedulas).count()
    total_aprendices = Aprendiz.objects.filter(id_sem=semillero).count()
    total_miembros = total_usuarios + total_aprendices

    proyectos = SemilleroProyecto.objects.filter(id_sem=semillero)
    total_proyectos = proyectos.count()

    total_entregables = Entregable.objects.filter(
        cod_pro__in=proyectos.values('cod_pro')
    ).count()

    actualizar_progreso_semillero(semillero)

    return render(request, 'paginas/resumen.html', {
        'current_page': 'resumen',
        'current_page_name': 'Semilleros',
        'semillero': semillero,
        'objetivos_lista': objetivos_lista,
        'total_miembros': total_miembros,
        'total_proyectos': total_proyectos,
        'total_entregables': total_entregables,
        'usuario': usuario
    })

@login_required
def resu_miembros(request, id_sem):
    usuario_id = request.session.get('cedula')
    if not usuario_id:
        messages.error(request, "Debes iniciar sesión.")
        return redirect('iniciarsesion')

    try:
        usuario = Usuario.objects.get(cedula=usuario_id)
    except Usuario.DoesNotExist:
        messages.error(request, "Usuario no encontrado.")
        return redirect('iniciarsesion') 
    
    semillero = get_object_or_404(Semillero, id_sem=id_sem)

    cedulas_en_semillero = SemilleroUsuario.objects.filter(
        id_sem=semillero
    ).values_list('cedula', flat=True)

    usuarios = Usuario.objects.filter(cedula__in=cedulas_en_semillero)
    usuarios_disponibles = Usuario.objects.exclude(cedula__in=cedulas_en_semillero)

    aprendices = Aprendiz.objects.filter(id_sem=semillero)

    total_miembros = usuarios.count() + aprendices.count()

    miembros = SemilleroUsuario.objects.filter(
        id_sem=semillero
    ).select_related('cedula').order_by('-es_lider', 'cedula__nom_usu')

    proyectos = Proyecto.objects.filter(semilleroproyecto__id_sem=semillero)
    codigos_proyectos = proyectos.values_list('cod_pro', flat=True)

    for miembro in miembros:
        miembro.es_lider_proyecto = UsuarioProyecto.objects.filter(
            cedula=miembro.cedula,
            cod_pro__in=codigos_proyectos,
            es_lider_pro=True
        ).exists()

        if miembro.es_lider_proyecto:
            proyectos_liderados = UsuarioProyecto.objects.filter(
                cedula=miembro.cedula,
                cod_pro__in=codigos_proyectos,
                es_lider_pro=True
            ).select_related('cod_pro').values_list('cod_pro__nom_pro', flat=True)
            miembro.proyectos_liderados = list(proyectos_liderados)

    instructores = SemilleroUsuario.objects.filter(
        id_sem=semillero
    ).filter(
        Q(cedula__rol__icontains='instructor') |
        Q(cedula__rol__icontains='investigador') |
        Q(cedula__rol__icontains='líder') |
        Q(cedula__rol__icontains='lider')
    ).select_related('cedula').order_by('-es_lider', 'cedula__nom_usu')

    for instructor in instructores:
        instructor.es_lider_proyecto = UsuarioProyecto.objects.filter(
            cedula=instructor.cedula,
            cod_pro__in=codigos_proyectos,
            es_lider_pro=True
        ).exists()
        
        if instructor.es_lider_proyecto:
            proyectos_liderados = UsuarioProyecto.objects.filter(
                cedula=instructor.cedula,
                cod_pro__in=codigos_proyectos,
                es_lider_pro=True
            ).select_related('cod_pro').values_list('cod_pro__nom_pro', flat=True)
            instructor.proyectos_liderados = list(proyectos_liderados)

    tiene_instructores = any(
        m.cedula.rol.lower() in ['instructor', 'investigador', 'líder', 'lider'] 
        for m in miembros
    )

    total_proyectos = proyectos.count()

    total_entregables = Entregable.objects.filter(
        cod_pro__in=proyectos.values('cod_pro')
    ).count()

    context = {
        'current_page': 'resu_miembros',
        'current_page_name': 'Semilleros',
        'semillero': semillero,
        'usuarios': usuarios,
        'aprendices': aprendices,
        'miembros': miembros, 
        'Usuarios': usuarios_disponibles,
        'total_miembros': total_miembros,
        'proyectos': proyectos,
        'tiene_instructores': tiene_instructores,
        'total_proyectos': total_proyectos,
        'total_entregables': total_entregables,
        'instructores': instructores, 
        'usuario' : usuario,
    }

    return render(request, 'paginas/resu-miembros.html', context)

@login_required
@semillero_activo_requerido
@permission_required('GC2.add_usuario')
def agregar_miembros(request, id_sem):
    if request.method == 'POST':
        semillero = get_object_or_404(Semillero, id_sem=id_sem)
        miembros_seleccionados = request.POST.getlist('miembros_seleccionados')
        
        if not miembros_seleccionados:
            messages.warning(request, 'No se seleccionó ningún miembro')
            return redirect('resu-miembros', id_sem=id_sem)
        
        try:
            agregados = 0
            ya_existentes = 0
            
            for cedula in miembros_seleccionados:
                usuario = get_object_or_404(Usuario, cedula=cedula)
                
                existe = SemilleroUsuario.objects.filter(
                    id_sem=semillero, 
                    cedula=usuario
                ).exists()
                
                if not existe:
                    SemilleroUsuario.objects.create(
                        id_sem=semillero, 
                        cedula=usuario
                    )
                    agregados += 1
                else:
                    ya_existentes += 1
            
            if agregados > 0:
                messages.success(request, f'{agregados} miembro(s) agregado(s) exitosamente')
            if ya_existentes > 0:
                messages.info(request, f'{ya_existentes} miembro(s) ya estaban en el semillero')
            
            return redirect('resu-miembros', id_sem=id_sem)
            
        except Exception as e:
            messages.error(request, f'Error al agregar miembros: {str(e)}')
            return redirect('resu-miembros', id_sem=id_sem)
    
    return redirect('resu-miembros', id_sem=id_sem)

@login_required
@semillero_activo_requerido
@permission_required('GC2.change_usuario')
def asignar_lider_semillero(request, id_sem):
    if request.method == "POST":
        semillero = get_object_or_404(Semillero, id_sem=id_sem)
        id_relacion = request.POST.get("lider_semillero")

        try:
            nueva_relacion_lider = SemilleroUsuario.objects.get(semusu_id=id_relacion, id_sem=semillero)
        except SemilleroUsuario.DoesNotExist:
            messages.error(request, "El usuario seleccionado no pertenece a este semillero.")
            return redirect("resu-miembros", semillero.id_sem)

        try:
            relacion_lider_anterior = SemilleroUsuario.objects.get(id_sem=semillero, es_lider=True)
            usuario_anterior = relacion_lider_anterior.cedula

            if usuario_anterior.rol == 'Líder de Semillero':
                usuario_anterior.rol = 'Instructor'
                usuario_anterior.save()

            relacion_lider_anterior.es_lider = False
            relacion_lider_anterior.save()
            
        except SemilleroUsuario.DoesNotExist:
            pass

        nueva_relacion_lider.es_lider = True
        nueva_relacion_lider.save()

        nuevo_usuario_lider = nueva_relacion_lider.cedula
        nuevo_usuario_lider.rol = 'Líder de Semillero'
        nuevo_usuario_lider.save()

        messages.success(
            request, 
            f"{nuevo_usuario_lider.nom_usu} {nuevo_usuario_lider.ape_usu} ha sido asignado como líder del semillero."
        )
        return redirect("resu-miembros", semillero.id_sem)
    
    semillero = get_object_or_404(Semillero, id_sem=id_sem)
    
    if request.method == "POST":
        cedula_instructor = request.POST.get("instructor_seleccionado")
        cod_proyecto = request.POST.get("proyecto_seleccionado")

        if not cedula_instructor or not cod_proyecto:
            messages.error(request, "Debes seleccionar un instructor y un proyecto.")
            return redirect("resu-miembros", id_sem=id_sem)

        try:
            instructor = Usuario.objects.get(cedula=cedula_instructor)
            proyecto = Proyecto.objects.get(cod_pro=cod_proyecto)

            if not SemilleroProyecto.objects.filter(id_sem=semillero, cod_pro=proyecto).exists():
                messages.error(request, "El proyecto seleccionado no pertenece a este semillero.")
                return redirect("resu-miembros", id_sem=id_sem)

            if not SemilleroUsuario.objects.filter(id_sem=semillero, cedula=instructor).exists():
                messages.error(request, "El instructor seleccionado no pertenece a este semillero.")
                return redirect("resu-miembros", id_sem=id_sem)

            try:
                relacion_anterior = UsuarioProyecto.objects.get(cod_pro=proyecto, es_lider=True)
                usuario_anterior = relacion_anterior.cedula

                if usuario_anterior.rol == 'Líder de Proyecto':
                    usuario_anterior.rol = 'Instructor'  
                    usuario_anterior.save()

                relacion_anterior.es_lider_pro = False
                relacion_anterior.save()
                
            except UsuarioProyecto.DoesNotExist:
                pass

            try:
                relacion = UsuarioProyecto.objects.get(
                    cedula=instructor,
                    cod_pro=proyecto
                )
                relacion.es_lider_pro = True
                relacion.save()
                creada = False
            except UsuarioProyecto.DoesNotExist:
                relacion = UsuarioProyecto.objects.create(
                    cedula=instructor,
                    cod_pro=proyecto,
                    es_lider=True
                )
                creada = True

            instructor.rol = 'Líder de Proyecto'  
            instructor.save()

            mensaje = "asignado" if creada else "actualizado como"
            messages.success(
                request, 
                f"{instructor.nom_usu} {instructor.ape_usu} ha sido {mensaje} líder del proyecto '{proyecto.nom_pro}'."
            )
            return redirect("resu-miembros", id_sem=id_sem)

        except Usuario.DoesNotExist:
            messages.error(request, "El instructor seleccionado no existe.")
            return redirect("resu-miembros", id_sem=id_sem)
        
        except Proyecto.DoesNotExist:
            messages.error(request, "El proyecto seleccionado no existe.")
            return redirect("resu-miembros", id_sem=id_sem)
        
        except Exception as e:
            messages.error(request, f"Error al asignar líder: {e}")
            return redirect("resu-miembros", id_sem=id_sem)

    return redirect("resu-miembros", id_sem=id_sem)

@login_required
def resu_proyectos(request, id_sem, cod_pro=None):
    usuario_id = request.session.get('cedula')
    if not usuario_id:
        messages.error(request, "Debes iniciar sesión.")
        return redirect('iniciarsesion')

    try:
        usuario = Usuario.objects.get(cedula=usuario_id)
    except Usuario.DoesNotExist:
        messages.error(request, "Usuario no encontrado.")
        return redirect('iniciarsesion')
    
    semillero = get_object_or_404(Semillero, id_sem=id_sem)

    proyecto_editar = None
    mostrar_modal_editar = False
    mostrar_modal_gestionar = False
    lineas_tec_lista = []
    lineas_inv_lista = []
    lineas_sem_lista = []
    miembros_proyecto_actual = []

    mostrar_gestionar = request.GET.get('gestionar_equipo')

    if request.method == 'POST' and cod_pro:
        if semillero.estado == 'desactivado' or not semillero.activo:
            messages.error(
                request, 
                f'⚠️ El semillero "{semillero.nombre}" está desactivado. '
                f'No puedes gestionar el equipo. Actívalo primero.'
            )
            return redirect('resu-proyectos', id_sem=id_sem)
        proyecto_editar = get_object_or_404(Proyecto, cod_pro=cod_pro)

        try:
            proyecto_editar.nom_pro = request.POST.get('nom_pro', '').strip()
            proyecto_editar.tipo = request.POST.get('tipo', '').strip().lower()
            proyecto_editar.desc_pro = request.POST.get('desc_pro', '').strip()
            proyecto_editar.programa_formacion = request.POST.get('programa_formacion', '').strip() if proyecto_editar.tipo == 'formativo' else None

            lineas_tec = request.POST.getlist('lineastec[]')
            lineas_inv = request.POST.getlist('lineasinv[]')
            lineas_sem = request.POST.getlist('lineassem[]')

            if lineas_tec:
                proyecto_editar.linea_tec = "\n".join([l.strip() for l in lineas_tec if l.strip()])

            if lineas_inv:
                proyecto_editar.linea_inv = "\n".join([l.strip() for l in lineas_inv if l.strip()])

            if lineas_sem:
                proyecto_editar.linea_sem = "\n".join([l.strip() for l in lineas_sem if l.strip()])

            nueva_nota = request.POST.get('notas', '').strip()
            if nueva_nota:
                if proyecto_editar.notas:
                    proyecto_editar.notas += f"\n{nueva_nota}"
                else:
                    proyecto_editar.notas = nueva_nota

            proyecto_editar.save()

            miembros_seleccionados = request.POST.getlist('miembros_proyecto[]')

            for cedula in miembros_seleccionados:

                usuario = Usuario.objects.filter(cedula=cedula).first()
                if usuario:
                    ya_existe = UsuarioProyecto.objects.filter(
                        cedula=usuario, 
                        cod_pro=proyecto_editar
                    ).exists()
                    if not ya_existe:
                        UsuarioProyecto.objects.create(
                            cedula=usuario, 
                            cod_pro=proyecto_editar, 
                            estado="activo"
                        )
                    continue

                aprendiz = Aprendiz.objects.filter(cedula_apre=cedula).first()
                if aprendiz:
                    ya_existe = ProyectoAprendiz.objects.filter(
                        cedula_apre=aprendiz, 
                        cod_pro=proyecto_editar
                    ).exists()
                    if not ya_existe:
                        ProyectoAprendiz.objects.create(
                            cedula_apre=aprendiz, 
                            cod_pro=proyecto_editar, 
                            estado="activo"
                        )

            messages.success(request, f'Proyecto "{proyecto_editar.nom_pro}" actualizado correctamente.')
            return redirect('resu-proyectos', id_sem=id_sem)

        except Exception as e:
            messages.error(request, f'Error al actualizar proyecto: {str(e)}')
            return redirect('resu-proyectos', id_sem=id_sem, cod_pro=cod_pro)

    if mostrar_gestionar and cod_pro and request.method == 'GET':
        if semillero.estado == 'desactivado' or not semillero.activo:
            messages.error(
                request, 
                f'⚠️ El semillero "{semillero.nombre}" está desactivado. '
                f'No puedes gestionar el equipo. Actívalo primero.'
            )
            return redirect('resu-proyectos', id_sem=id_sem)
        proyecto_editar = get_object_or_404(Proyecto, cod_pro=cod_pro)
        mostrar_modal_gestionar = True

        if not proyecto_editar.estado_pro:
            messages.error(request, '❌ Este proyecto está desactivado y no puede ser editado.')
            return redirect('resu-proyectos', id_sem=id_sem)

        usuarios_proyecto = UsuarioProyecto.objects.filter(cod_pro=proyecto_editar).select_related('cedula')
        aprendices_proyecto = ProyectoAprendiz.objects.filter(cod_pro=proyecto_editar).select_related('cedula_apre')

        miembros_equipo = []

        for up in usuarios_proyecto:
            su = SemilleroUsuario.objects.filter(cedula=up.cedula, id_sem=semillero).first()
            es_lider_sem = su.es_lider if su else False

            miembros_equipo.append({
                'cedula': up.cedula.cedula,
                'nombre_completo': f"{up.cedula.nom_usu} {up.cedula.ape_usu}",
                'nom_usu': up.cedula.nom_usu,
                'ape_usu': up.cedula.ape_usu,
                'email': up.cedula.correo_ins if up.cedula.correo_ins else up.cedula.correo_per,
                'iniciales': up.cedula.get_iniciales,
                'tipo': 'Usuario',
                'rol': up.cedula.rol,
                'estado': up.estado,
                'es_lider': up.es_lider_pro,
                'es_lider_sem': es_lider_sem,
                'usuario': usuario
            })

        for ap in aprendices_proyecto:
            miembros_equipo.append({
                'cedula': ap.cedula_apre.cedula_apre,
                'nombre_completo': f"{ap.cedula_apre.nombre} {ap.cedula_apre.apellido}",
                'nom_usu': ap.cedula_apre.nombre,
                'ape_usu': ap.cedula_apre.apellido,
                'email': ap.cedula_apre.correo_ins if hasattr(ap.cedula_apre, 'correo_ins') and ap.cedula_apre.correo_ins else (ap.cedula_apre.correo_per if hasattr(ap.cedula_apre, 'correo_per') else ''),
                'iniciales': ap.cedula_apre.get_iniciales,
                'tipo': 'Aprendiz',
                'rol': 'Aprendiz',
                'estado': ap.estado,
                'es_lider': False,
            })

        busqueda = request.GET.get('busqueda_usuario', '').strip().lower()
        filtro_rol = request.GET.get('filtro_rol', '').strip().lower()
        filtro_estado = request.GET.get('filtro_estado', '').strip().lower()

        if busqueda:
            miembros_equipo = [
                m for m in miembros_equipo
                if busqueda in m['nombre_completo'].lower() or busqueda in m['email'].lower()
            ]

        if filtro_rol:
            if filtro_rol == 'es_lider':
                miembros_equipo = [m for m in miembros_equipo if m.get('es_lider', False)]
            else:
                miembros_equipo = [m for m in miembros_equipo if m['rol'].lower() == filtro_rol]

        if filtro_estado:
            miembros_equipo = [m for m in miembros_equipo if m['estado'].lower() == filtro_estado]

        miembros_proyecto_actual = miembros_equipo

    elif cod_pro and request.method == 'GET' and not mostrar_gestionar:
        if semillero.estado == 'desactivado' or not semillero.activo:
            messages.error(
                request, 
                f'⚠️ El semillero "{semillero.nombre}" está desactivado. '
                f'No puedes gestionar el equipo. Actívalo primero.'
            )
            return redirect('resu-proyectos', id_sem=id_sem)
        proyecto_editar = get_object_or_404(Proyecto, cod_pro=cod_pro)
        mostrar_modal_editar = True

        if not proyecto_editar.estado_pro:
            messages.error(request, ' Este proyecto está desactivado y no puede ser editado.')
            return redirect('resu-proyectos', id_sem=id_sem)

        lineas_tec_lista = []
        lineas_inv_lista = []
        lineas_sem_lista = []

        if proyecto_editar.linea_tec:
            lineas_tec_lista = [l.strip() for l in proyecto_editar.linea_tec.split('\n') if l.strip()]

        if proyecto_editar.linea_inv:
            lineas_inv_lista = [l.strip() for l in proyecto_editar.linea_inv.split('\n') if l.strip()]

        if proyecto_editar.linea_sem:
            lineas_sem_lista = [l.strip() for l in proyecto_editar.linea_sem.split('\n') if l.strip()]

        usuarios_proyecto = UsuarioProyecto.objects.filter(cod_pro=proyecto_editar).select_related('cedula')
        aprendices_proyecto = ProyectoAprendiz.objects.filter(cod_pro=proyecto_editar).select_related('cedula_apre')

        for up in usuarios_proyecto:
            miembros_proyecto_actual.append({
                'cedula': up.cedula.cedula,
                'nombre_completo': f"{up.cedula.nom_usu} {up.cedula.ape_usu}",
                'iniciales': up.cedula.get_iniciales,
                'tipo': 'Usuario',
                'rol': up.cedula.rol,
                'estado': up.estado
            })

        for ap in aprendices_proyecto:
            miembros_proyecto_actual.append({
                'cedula': ap.cedula_apre.cedula_apre,
                'nombre_completo': f"{ap.cedula_apre.nombre} {ap.cedula_apre.apellido}",
                'iniciales': ap.cedula_apre.get_iniciales,
                'tipo': 'Aprendiz',
                'rol': 'Aprendiz',
                'estado': ap.estado
            })

    proyectos = Proyecto.objects.filter(semilleroproyecto__id_sem=semillero)

    for proyecto in proyectos:
        verificar_y_actualizar_estados_entregables(proyecto)

    tipo_seleccionado = None
    if cod_pro:
        proyectos = proyectos.order_by(
            Case(
                When(cod_pro=cod_pro, then=Value(0)),
                default=Value(1),
                output_field=IntegerField(),
            )
        )

        proyecto_sel = proyectos.filter(cod_pro=cod_pro).first()
        if proyecto_sel:
            tipo_seleccionado = proyecto_sel.tipo.lower()

    proyectos_sennova = list(proyectos.filter(tipo__iexact="sennova"))
    proyectos_capacidad = list(proyectos.filter(tipo__iexact="capacidadinstalada"))
    proyectos_formativos = list(proyectos.filter(tipo__iexact="formativo"))

    for proyecto in proyectos_sennova + proyectos_capacidad + proyectos_formativos:
        usuarios_proyecto = UsuarioProyecto.objects.filter(cod_pro=proyecto).select_related('cedula')
        aprendices_proyecto = ProyectoAprendiz.objects.filter(cod_pro=proyecto).select_related('cedula_apre')

        proyecto.lineas_tec_lista = [l.strip() for l in proyecto.linea_tec.split('\n') if l.strip()] if proyecto.linea_tec else []
        proyecto.lineas_inv_lista = [l.strip() for l in proyecto.linea_inv.split('\n') if l.strip()] if proyecto.linea_inv else []
        proyecto.lineas_sem_lista = [l.strip() for l in proyecto.linea_sem.split('\n') if l.strip()] if proyecto.linea_sem else []
        
        miembros_lista = []

        for up in usuarios_proyecto:
            miembros_lista.append({
                'cedula': up.cedula.cedula,
                'nombre_completo': f"{up.cedula.nom_usu} {up.cedula.ape_usu}",
                'iniciales': up.cedula.get_iniciales,
                'tipo': 'Usuario',
                'rol': up.cedula.rol,
                'estado': up.estado
            })

        for ap in aprendices_proyecto:
            miembros_lista.append({
                'cedula': ap.cedula_apre.cedula_apre,
                'nombre_completo': f"{ap.cedula_apre.nombre} {ap.cedula_apre.apellido}",
                'iniciales': ap.cedula_apre.get_iniciales,
                'tipo': 'Aprendiz',
                'rol': 'Aprendiz',
                'estado': ap.estado
            })

        proyecto.miembros_lista = miembros_lista
        proyecto.miembros_activos = [m for m in miembros_lista if m['estado'] == 'activo']
        
        proyecto.lineas_tec_lista = [l.strip() for l in proyecto.linea_tec.split('\n') if l.strip()] if proyecto.linea_tec else []
        proyecto.lineas_inv_lista = [l.strip() for l in proyecto.linea_inv.split('\n') if l.strip()] if proyecto.linea_inv else []
        proyecto.lineas_sem_lista = [l.strip() for l in proyecto.linea_sem.split('\n') if l.strip()] if proyecto.linea_sem else []

    proyectos_count = SemilleroProyecto.objects.filter(id_sem=semillero)
    total_proyectos = proyectos_count.count()

    usuarios = SemilleroUsuario.objects.filter(id_sem=semillero)
    aprendices = Aprendiz.objects.filter(id_sem=semillero)
    total_miembros = usuarios.count() + aprendices.count()
    miembros = usuarios.select_related('cedula')

    total_entregables = Entregable.objects.filter(
        cod_pro__in=proyectos_count.values('cod_pro')
    ).count()

    proyectos_semillero = proyectos_count.values_list('cod_pro', flat=True)
    usuarios_asignados = UsuarioProyecto.objects.filter(
        cod_pro__in=proyectos_semillero
    ).values_list('cedula__cedula', flat=True)
    aprendices_asignados = ProyectoAprendiz.objects.filter(
        cod_pro__in=proyectos_semillero
    ).values_list('cedula_apre__cedula_apre', flat=True)

    cedulas_asignadas = set(str(c) for c in usuarios_asignados) | set(str(c) for c in aprendices_asignados)

    usuarios_semillero = SemilleroUsuario.objects.filter(id_sem=semillero).select_related('cedula')
    usuarios_disponibles = [u for u in usuarios_semillero if str(u.cedula.cedula) not in cedulas_asignadas]

    aprendices_semillero = Aprendiz.objects.filter(id_sem=semillero)
    aprendices_disponibles = [a for a in aprendices_semillero if str(a.cedula_apre) not in cedulas_asignadas]

    miembros_semillero = []
    for u in usuarios_disponibles:
        miembros_semillero.append({
            'cedula': u.cedula.cedula,
            'nombre_completo': f"{u.cedula.nom_usu} {u.cedula.ape_usu}",
            'iniciales': u.cedula.get_iniciales,
            'tipo': 'Usuario',
            'rol': u.cedula.rol
        })

    for a in aprendices_disponibles:
        miembros_semillero.append({
            'cedula': a.cedula_apre,
            'nombre_completo': f"{a.nombre} {a.apellido}",
            'iniciales': a.get_iniciales,
            'tipo': 'Aprendiz',
            'rol': 'Aprendiz'
        })

    context = {
        'current_page': 'resu_proyectos',
        'current_page_name': 'Semilleros',
        'semillero': semillero,
        'proyectos_sennova': proyectos_sennova,
        'proyectos_capacidad': proyectos_capacidad,
        'proyectos_formativos': proyectos_formativos,
        'total_proyectos': total_proyectos,
        'total_miembros': total_miembros,
        'miembros': miembros,
        'total_entregables': total_entregables,
        'miembros_semillero': miembros_semillero,
        'proyecto_seleccionado': cod_pro,
        'tipo_seleccionado': tipo_seleccionado,
        'miembros_proyecto_actual': miembros_proyecto_actual,
        'mostrar_modal_editar': mostrar_modal_editar,
        'mostrar_modal_gestionar': mostrar_modal_gestionar,
        'proyecto_editar': proyecto_editar,
        'lineas_tec_lista': lineas_tec_lista,
        'lineas_inv_lista': lineas_inv_lista,
        'lineas_sem_lista': lineas_sem_lista,
        'busqueda_usuario': request.GET.get('busqueda_usuario', ''),
        'filtro_rol': request.GET.get('filtro_rol', ''),
        'filtro_estado': request.GET.get('filtro_estado', ''),
        'usuario' : usuario
    }

    return render(request, 'paginas/resu-proyectos.html', context)

@login_required
@permission_required('GC2.change_usuario')
@semillero_activo_requerido
def asignar_lider_proyecto_ajax(request, id_sem, cod_pro):
    """
    Asigna o quita el rol de líder de proyecto mediante AJAX
    """
    semillero = get_object_or_404(Semillero, id_sem=id_sem)
    proyecto = get_object_or_404(Proyecto, cod_pro=cod_pro)
    cedula_miembro = request.POST.get('cedula_miembro')
    
    if not cedula_miembro:
        return JsonResponse({'success': False, 'error': 'No se especificó el miembro'})
    
    try:
        if not SemilleroProyecto.objects.filter(id_sem=semillero, cod_pro=proyecto).exists():
            return JsonResponse({'success': False, 'error': 'El proyecto no pertenece a este semillero'})
        
        try:
            miembro = Usuario.objects.get(cedula=cedula_miembro)
        except Usuario.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Solo los usuarios pueden ser líderes de proyecto'})
        
        if not SemilleroUsuario.objects.filter(id_sem=semillero, cedula=miembro).exists():
            return JsonResponse({'success': False, 'error': 'El usuario no pertenece a este semillero'})
        
        try:
            relacion_actual = UsuarioProyecto.objects.get(cedula=miembro, cod_pro=proyecto)
            es_lider_actual = relacion_actual.es_lider_pro
        except UsuarioProyecto.DoesNotExist:
            relacion_actual = UsuarioProyecto.objects.create(
                cedula=miembro,
                cod_pro=proyecto,
                es_lider_pro=False,
                estado='activo'
            )
            es_lider_actual = False
        
        if es_lider_actual:
            return JsonResponse({
                'success': True,
                'es_lider_pro': True,
                'mensaje': f'{miembro.nom_usu} {miembro.ape_usu} ya es líder de este proyecto'
            })
        
        try:
            relacion_anterior = UsuarioProyecto.objects.get(cod_pro=proyecto, es_lider_pro=True)
            usuario_anterior = relacion_anterior.cedula
            
            if not hasattr(usuario_anterior, 'rol_original') or not usuario_anterior.rol_original:
                rol_original = usuario_anterior.rol
                if rol_original == 'Líder de Proyecto':
                    rol_original = 'Instructor'
            
            if usuario_anterior.rol == 'Líder de Proyecto':
                otros_proyectos_lider = UsuarioProyecto.objects.filter(
                    cedula=usuario_anterior,
                    es_lider_pro=True
                ).exclude(cod_pro=proyecto).exists()
                
                if not otros_proyectos_lider:
                    if hasattr(usuario_anterior, 'rol_original') and usuario_anterior.rol_original:
                        usuario_anterior.rol = usuario_anterior.rol_original
                    else:
                        if usuario_anterior.vinculacion_laboral and 'instructor' in usuario_anterior.vinculacion_laboral.lower():
                            usuario_anterior.rol = 'Instructor'
                        else:
                            usuario_anterior.rol = 'Investigador'
                    
                    usuario_anterior.save()
            
            relacion_anterior.es_lider_pro = False
            relacion_anterior.save()
            
        except UsuarioProyecto.DoesNotExist:
            pass
        
        if miembro.rol != 'Líder de Proyecto':
            if hasattr(miembro, 'rol_original'):
                miembro.rol_original = miembro.rol
        
        relacion_actual.es_lider_pro = True
        relacion_actual.save()
        
        if miembro.rol != 'Líder de Proyecto':
            miembro.rol = 'Líder de Proyecto'
            miembro.save()
        
        return JsonResponse({
            'success': True,
            'es_lider_pro': True,
            'mensaje': f'{miembro.nom_usu} {miembro.ape_usu} ha sido asignado como líder del proyecto'
        })
        
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})

@login_required
@permission_required('GC2.change_usuario')
def alternar_estado_miembro(request, id_sem, cod_pro):
    semillero = get_object_or_404(Semillero, id_sem=id_sem)
    proyecto = get_object_or_404(Proyecto, cod_pro=cod_pro)
    cedula_miembro = request.POST.get('cedula_miembro')

    if not cedula_miembro:
        return JsonResponse({'success': False, 'error': 'No se especificÃ³ el miembro'})

    try:
        try:
            relacion = UsuarioProyecto.objects.get(cedula__cedula=cedula_miembro, cod_pro=proyecto)
            
            if relacion.estado == "activo" and relacion.es_lider_pro:
                return JsonResponse({
                    'success': False, 
                    'error': 'No se puede desactivar al lÃ­der del proyecto. Primero asigne otro lÃ­der.'
                })
            
        except UsuarioProyecto.DoesNotExist:
            relacion = ProyectoAprendiz.objects.get(cedula_apre__cedula_apre=cedula_miembro, cod_pro=proyecto)

        relacion.estado = "inactivo" if relacion.estado == "activo" else "activo"
        relacion.save()

        return JsonResponse({
            'success': True,
            'nuevo_estado': relacion.estado,
            'mensaje': f'Estado actualizado a {relacion.estado}'
        })

    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})

@login_required
@semillero_activo_requerido
def crear_proyecto(request, id_sem):
    semillero = get_object_or_404(Semillero, id_sem=id_sem)

    proyectos_semillero = SemilleroProyecto.objects.filter(
        id_sem=semillero
    ).values_list('cod_pro', flat=True)

    usuarios_asignados = UsuarioProyecto.objects.filter(
        cod_pro__in=proyectos_semillero
    ).values_list('cedula__cedula', flat=True)

    aprendices_asignados = ProyectoAprendiz.objects.filter(
        cod_pro__in=proyectos_semillero
    ).values_list('cedula_apre__cedula_apre', flat=True)

    cedulas_asignadas = set(str(c) for c in usuarios_asignados) | set(str(c) for c in aprendices_asignados)

    usuarios_semillero = SemilleroUsuario.objects.filter(id_sem=semillero).select_related('cedula')

    usuarios_disponibles = [u for u in usuarios_semillero if str(u.cedula.cedula) not in cedulas_asignadas]

    aprendices_semillero = Aprendiz.objects.filter(id_sem=semillero)

    aprendices_disponibles = [a for a in aprendices_semillero if str(a.cedula_apre) not in cedulas_asignadas]

    miembros_semillero = []

    for u in usuarios_disponibles:
        miembros_semillero.append({
            'cedula': u.cedula.cedula,
            'nombre_completo': f"{u.cedula.nom_usu} {u.cedula.ape_usu}",
            'iniciales': u.cedula.get_iniciales,
            'tipo': 'Usuario',
            'rol': u.cedula.rol
        })

    for a in aprendices_disponibles:
        miembros_semillero.append({
            'cedula': a.cedula_apre,
            'nombre_completo': f"{a.nombre} {a.apellido}",
            'iniciales': a.get_iniciales,
            'tipo': 'Aprendiz',
            'rol': 'Aprendiz'
        })

    if request.method == 'POST':
        try:
            cedula_usuario = request.session.get('cedula')
            if not cedula_usuario:
                messages.error(request, 'Debes iniciar sesión para crear un proyecto.')
                return redirect('iniciarsesion')

            usuario_actual = Usuario.objects.get(cedula=cedula_usuario)

            nom_pro = request.POST.get('nom_pro', '').strip()
            tipo = request.POST.get('tipo', '').strip().lower()
            programa_formacion = request.POST.get('programa_formacion', '').strip()

            desc_pro = request.POST.get('desc_pro', '').strip()
            lineas_tec = [l.strip() for l in request.POST.getlist('lineastec[]') if l.strip()]
            lineas_inv = [l.strip() for l in request.POST.getlist('lineasinv[]') if l.strip()]
            lineas_sem = [l.strip() for l in request.POST.getlist('lineassem[]') if l.strip()]
            miembros_seleccionados = request.POST.getlist('miembros_proyecto[]')

            if not all([nom_pro, tipo, desc_pro]):
                messages.error(request, 'Todos los campos son obligatorios.')
                return redirect('resu-proyectos', id_sem=id_sem)
            if tipo == "formativo" and not programa_formacion:
                messages.error(request, 'Debe ingresar el programa de formación para un proyecto formativo.')
                return redirect('resu-proyectos', id_sem=id_sem)

            ultimo_proyecto = Proyecto.objects.order_by('-cod_pro').first()
            nuevo_cod_pro = ultimo_proyecto.cod_pro + 1 if ultimo_proyecto else 1

            proyecto = Proyecto.objects.create(
                cod_pro=nuevo_cod_pro,
                nom_pro=nom_pro,
                tipo=tipo,
                desc_pro=desc_pro,
                linea_tec="\n".join(lineas_tec),
                linea_inv="\n".join(lineas_inv),
                linea_sem="\n".join(lineas_sem),
                estado_pro="Activo",
                programa_formacion=programa_formacion if tipo == "formativo" else None
            )

            SemilleroProyecto.objects.create(id_sem=semillero, cod_pro=proyecto)

            UsuarioProyecto.objects.create(cedula=usuario_actual, cod_pro=proyecto)

            for cedula in miembros_seleccionados:
                if str(cedula) != str(cedula_usuario):
                    try:
                        usuario = Usuario.objects.get(cedula=cedula)
                        UsuarioProyecto.objects.create(cedula=usuario, cod_pro=proyecto)
                    except Usuario.DoesNotExist:
                        try:
                            aprendiz = Aprendiz.objects.get(cedula_apre=cedula)
                            ProyectoAprendiz.objects.create(cedula_apre=aprendiz, cod_pro=proyecto)
                        except Aprendiz.DoesNotExist:
                            pass

            ultimo_entregable = Entregable.objects.order_by('-cod_entre').first()
            base_cod = ultimo_entregable.cod_entre if ultimo_entregable else 0

            if tipo in ["sennova", "capacidadinstalada"]:
                fecha_inicio_str = request.POST.get('fecha_inicio_7')
                fecha_fin_str = request.POST.get('fecha_fin_7')

                if not fecha_inicio_str or not fecha_fin_str:
                    messages.error(request, 'Error: Debes seleccionar las fechas de inicio y fin del entregable.')
                    proyecto.delete()
                    return redirect('resu-proyectos', id_sem=id_sem)

                fecha_inicio = None
                fecha_fin = None
                
                try:
                    if fecha_inicio_str:
                        fecha_inicio = datetime.strptime(fecha_inicio_str, '%Y-%m-%d').date()
                    if fecha_fin_str:
                        fecha_fin = datetime.strptime(fecha_fin_str, '%Y-%m-%d').date()
                except ValueError:
                    try:
                        if fecha_inicio_str:
                            fecha_inicio = datetime.strptime(fecha_inicio_str, '%d/%m/%Y').date()
                        if fecha_fin_str:
                            fecha_fin = datetime.strptime(fecha_fin_str, '%d/%m/%Y').date()
                    except Exception as e:
                        messages.error(request, 'Error: Formato de fecha inválido. Usa YYYY-MM-DD o DD/MM/YYYY.')
                        proyecto.delete() 
                        return redirect('resu-proyectos', id_sem=id_sem)

                if not fecha_inicio or not fecha_fin:
                    messages.error(request, 'Error: No se pudieron procesar las fechas del entregable.')
                    proyecto.delete()
                    return redirect('resu-proyectos', id_sem=id_sem)

                Entregable.objects.create(
                    cod_entre=base_cod + 1,
                    nom_entre="Resultados y Productos de Investigación",
                    desc_entre="Resultados y productos de investigación conforme a los parámetros de Minciencias.",  # ⬅️ Descripción genérica
                    estado="Pendiente",
                    fecha_inicio=fecha_inicio,
                    fecha_fin=fecha_fin,
                    cod_pro=proyecto
                )

            else:
                entregables_default = [
                    {"nombre": "Formalización de Proyecto", "descripcion": "Documento formal del proyecto."},
                    {"nombre": "Diagnóstico", "descripcion": "Análisis de la situación actual."},
                    {"nombre": "Planeación", "descripcion": "Cronograma y metodología del proyecto."},
                    {"nombre": "Ejecución", "descripcion": "Evidencias y resultados del proyecto."},
                    {"nombre": "Evaluación", "descripcion": "Cumplimiento e impacto del proyecto."},
                    {"nombre": "Conclusiones", "descripcion": "Reflexiones finales y recomendaciones."},
                ]

                for i, entregable_data in enumerate(entregables_default, start=1):
                    fecha_inicio_str = request.POST.get(f'fecha_inicio_{i}')
                    fecha_fin_str = request.POST.get(f'fecha_fin_{i}')

                    if not fecha_inicio_str or not fecha_fin_str:
                        messages.error(request, f'Error: Debes seleccionar las fechas para el entregable {i} ({entregable_data["nombre"]}).')
                        proyecto.delete()
                        return redirect('resu-proyectos', id_sem=id_sem)

                    fecha_inicio = None
                    fecha_fin = None
                    
                    try:
                        if fecha_inicio_str:
                            fecha_inicio = datetime.strptime(fecha_inicio_str, '%Y-%m-%d').date()
                        if fecha_fin_str:
                            fecha_fin = datetime.strptime(fecha_fin_str, '%Y-%m-%d').date()
                    except ValueError:
                        try:
                            if fecha_inicio_str:
                                fecha_inicio = datetime.strptime(fecha_inicio_str, '%d/%m/%Y').date()
                            if fecha_fin_str:
                                fecha_fin = datetime.strptime(fecha_fin_str, '%d/%m/%Y').date()
                        except Exception as e:
                            messages.error(request, f'Error: Formato de fecha inválido en entregable {i}.')
                            proyecto.delete()
                            return redirect('resu-proyectos', id_sem=id_sem)

                    if not fecha_inicio or not fecha_fin:
                        messages.error(request, f'Error: No se pudieron procesar las fechas del entregable {i}.')
                        proyecto.delete()
                        return redirect('resu-proyectos', id_sem=id_sem)

                    Entregable.objects.create(
                        cod_entre=base_cod + i,
                        nom_entre=entregable_data["nombre"],
                        desc_entre=entregable_data["descripcion"],
                        estado="Pendiente",
                        fecha_inicio=fecha_inicio,
                        fecha_fin=fecha_fin,
                        cod_pro=proyecto
                    )

            messages.success(request, f'Proyecto "{nom_pro}" creado correctamente.')
            return redirect('resu-proyectos', id_sem=id_sem)

        except Exception as e:
            messages.error(request, f'Error al crear proyecto: {str(e)}')
            return redirect('resu-proyectos', id_sem=id_sem)

    # Renderizar formulario
    return render(request, 'crear_proyecto.html', {
        'semillero': semillero,
        'miembros_semillero': miembros_semillero
    })

import unicodedata
import json

@login_required
def subir_archivo_entregable(request, id_sem, cod_pro, cod_entre):
    semillero = get_object_or_404(Semillero, id_sem=id_sem)
    proyecto = get_object_or_404(Proyecto, cod_pro=cod_pro)
    entregable = get_object_or_404(Entregable, cod_pro=cod_pro, cod_entre=cod_entre)

    if not proyecto.estado_pro or proyecto.estado_pro == "desactivado":
        messages.error(request, "Este proyecto está desactivado. No puedes subir entregables.")
        return redirect('resu-proyectos', id_sem=id_sem)

    if request.method == 'POST':
        if proyecto.tipo.lower() in ['sennova', 'capacidadinstalada', 'capacidad instalada']:
            categoria_principal = request.POST.get('categoria_principal', '')
            subcategorias_json = request.POST.get('subcategorias_json', '')
            if categoria_principal and subcategorias_json and subcategorias_json.strip():
                try:
                    from .forms import construir_descripcion_entregable, limpiar_descripcion_anterior
                    import unicodedata
                    desc_categorizacion = construir_descripcion_entregable(
                        categoria_principal,
                        subcategorias_json
                    )
                    desc_categorizacion = unicodedata.normalize('NFC', desc_categorizacion)
                    descripcion_generica = "Resultados y productos de investigación conforme a los parámetros de Minciencias."
                    
                    if entregable.desc_entre and descripcion_generica in entregable.desc_entre:
                        entregable.desc_entre = entregable.desc_entre.replace(descripcion_generica, "").strip()
                    if entregable.desc_entre:
                        entregable.desc_entre = limpiar_descripcion_anterior(entregable.desc_entre)

                    if entregable.desc_entre and entregable.desc_entre.strip():
                        entregable.desc_entre += f"\n\n--- Categorización Minciencias ---\n{desc_categorizacion}"
                    else:
                        entregable.desc_entre = f"--- Categorización Minciencias ---\n{desc_categorizacion}"

                    entregable.save(update_fields=['desc_entre'])

                    entregable.refresh_from_db()
                    
                except json.JSONDecodeError:
                    messages.warning(request, '⚠️ No se pudo procesar la categorización del entregable.')
                except Exception as e:
                    messages.warning(request, f'⚠️ Error al guardar categorización: {str(e)}')

        archivos = request.FILES.getlist('archivo')

        if not archivos:
            messages.error(request, '⚠️ Debes seleccionar uno o más archivos para subir.')
            return redirect('resu-proyectos', id_sem=id_sem)

        archivos_guardados = 0
        for archivo in archivos:
            try:
                import unicodedata
                nombre_normalizado = unicodedata.normalize('NFC', archivo.name)
                
                Archivo.objects.create(
                    entregable=entregable,
                    archivo=archivo,
                    nombre=nombre_normalizado
                )
                archivos_guardados += 1
            except Exception:
                messages.error(request, f'Error al guardar {archivo.name}')

        from datetime import date
        fecha_actual = date.today()

        if entregable.fecha_fin:
            if fecha_actual > entregable.fecha_fin:
                entregable.estado = 'Entrega Tardía'
            else:
                entregable.estado = 'Completado'
        else:
            entregable.estado = 'Completado'

        entregable.save(update_fields=['estado'])

        actualizar_progreso_proyecto(entregable.cod_pro)

        if archivos_guardados > 0:
            messages.success(
                request,
                f'✅ {archivos_guardados} archivo(s) subido(s) correctamente al entregable "{entregable.nom_entre}".'
            )
        
        return redirect('resu-proyectos', id_sem=id_sem)

    messages.error(request, 'Método no permitido.')
    return redirect('resu-proyectos', id_sem=id_sem)

def construir_descripcion_entregable(categoria_principal, subcategorias_json):
    try:
        datos = json.loads(subcategorias_json)
        lineas = []
        categoria_texto = CATEGORIAS_MAP.get(categoria_principal, 'No especificada')
        lineas.append(f"Categoría: {categoria_texto}")
        
        producto_texto = PRODUCTOS_MAP.get(datos.get('producto'), 'No especificado')
        lineas.append(f"Producto: {producto_texto}")
        
        for key, value in datos.items():
            if key in ['categoria', 'producto'] or not value:
                continue
            
            etiqueta = CAMPOS_LEGIBLES.get(key, key.replace('_', ' ').title())
            
            if isinstance(value, list):
                lineas.append(f"{etiqueta}: {', '.join(value)}")
            else:
                lineas.append(f"{etiqueta}: {value}")
        
        return "\n".join(lineas)
        
    except Exception as e:
        return f"Error al generar categorización: {e}"
    
def actualizar_progreso_proyecto(proyecto):  
    entregables = Entregable.objects.filter(cod_pro=proyecto)
    total_entregables = entregables.count()

    if total_entregables == 0:
        proyecto.progreso = 0
        proyecto.estado_pro = "pendiente"

    else:
        entregables_completados = entregables.filter(
            estado__in=['Completado', 'Entrega Tardía']
        ).count()

        progreso = round((entregables_completados / total_entregables) * 100)
        proyecto.progreso = progreso

        if entregables_completados == 0:
            proyecto.estado_pro = "pendiente"
        elif entregables_completados == 2:
            proyecto.estado_pro = "diagnostico"
        elif entregables_completados == 3:
            proyecto.estado_pro = "planeacion"
        elif 4 <= entregables_completados <= 5:
            proyecto.estado_pro = "ejecucion"
        elif entregables_completados >= 6:
            proyecto.estado_pro = "completado"

            if not proyecto.fecha_completado:
                proyecto.fecha_completado = date.today()

        else:
            if proyecto.fecha_completado:
                proyecto.fecha_completado = None

    proyecto.save(update_fields=['progreso', 'estado_pro', 'fecha_completado'])
    semilleros = Semillero.objects.filter(semilleroproyecto__cod_pro=proyecto)
    for semillero in semilleros:
        actualizar_progreso_semillero(semillero)

def verificar_y_actualizar_estados_entregables(proyecto):
    from datetime import date
    
    fecha_actual = date.today()
    entregables = Entregable.objects.filter(cod_pro=proyecto)
    
    for entregable in entregables:
        tiene_archivos = Archivo.objects.filter(entregable=entregable).exists()
        
        if tiene_archivos:
            if entregable.fecha_fin and fecha_actual > entregable.fecha_fin:
                if entregable.estado not in ['Completado', 'Entrega Tardía']:
                    entregable.estado = 'Entrega Tardía'
                    entregable.save()
            else:
                if entregable.estado != 'Completado':
                    entregable.estado = 'Completado'
                    entregable.save()
        else:
            if entregable.fecha_fin and fecha_actual > entregable.fecha_fin:
                if entregable.estado != 'Retrasado':
                    entregable.estado = 'Retrasado'
                    entregable.save()
            else:
                if entregable.estado not in ['Completado', 'Entrega Tardía']:
                    entregable.estado = 'Pendiente'
                    entregable.save()

@login_required
@permission_required('GC2.delete_archivo')
@semillero_activo_requerido
def eliminar_archivo(request, id_sem, cod_pro, cod_entre, id_archivo):
    cedula = request.session.get('cedula')
    
    try:
        usuario = Usuario.objects.get(cedula=cedula)
    except Usuario.DoesNotExist:
        messages.error(request, "❌ Usuario no encontrado.")
        return redirect('iniciarsesion')

    try:
        semillero, proyecto, entregable, archivo = obtener_objetos_eliminacion_archivo(
            id_sem, cod_pro, cod_entre, id_archivo
        )

        if not verificar_permisos_proyecto(proyecto):
            messages.error(request, "❌ El proyecto está desactivado. No puedes eliminar archivos.")
            return redirect('resu-proyectos', id_sem=id_sem)

        nombre_archivo = eliminar_archivo_fisico(archivo)

        archivos_restantes = Archivo.objects.filter(entregable=entregable).exists()
        
        if not archivos_restantes and proyecto.tipo.lower() in ['sennova', 'capacidadinstalada', 'capacidad instalada']:
            from .forms import limpiar_descripcion_anterior

            if entregable.desc_entre:
                entregable.desc_entre = limpiar_descripcion_anterior(entregable.desc_entre)
            
            descripcion_generica = "Resultados y productos de investigación conforme a los parámetros de Minciencias."
            entregable.desc_entre = descripcion_generica
            entregable.save(update_fields=['desc_entre'])

        actualizar_estado_entregable(entregable)
        actualizar_progreso_proyecto(proyecto)

        messages.success(request, f'✅ Archivo "{nombre_archivo}" eliminado correctamente')

    except Exception as e:
        messages.error(request, f'❌ Error al eliminar el archivo: {str(e)}')

    return redirect('resu-proyectos', id_sem=id_sem)

def obtener_objetos_eliminacion_archivo(id_sem, cod_pro, cod_entre, id_archivo):
    semillero = get_object_or_404(Semillero, id_sem=id_sem)

    proyecto = get_object_or_404(
        Proyecto.objects.filter(
            semilleroproyecto__id_sem=semillero
        ),
        cod_pro=cod_pro
    )

    entregable = get_object_or_404(
        Entregable,
        cod_entre=cod_entre,
        cod_pro=proyecto
    )

    archivo = get_object_or_404(
        Archivo,
        id=id_archivo,
        entregable=entregable
    )

    return semillero, proyecto, entregable, archivo

def verificar_permisos_proyecto(proyecto):
    if not proyecto.estado_pro:
        return False
    
    if proyecto.estado_pro.lower() == 'desactivado':
        return False
    
    return True

def eliminar_archivo_fisico(archivo):
    nombre_archivo = archivo.nombre if hasattr(archivo, 'nombre') else "archivo"
    
    try:
        if archivo.archivo:
            archivo.archivo.delete(save=False)
    except Exception as e:
        raise Exception(f"No se pudo eliminar el archivo físico: {e}")

    archivo.delete()
    
    return nombre_archivo

def actualizar_estado_entregable(entregable):
    archivos_restantes = Archivo.objects.filter(entregable=entregable).exists()
    
    if not archivos_restantes:
        entregable.estado = 'Pendiente'
        entregable.save()
    
@login_required
def eliminar_proyecto_semillero(request, id_sem, cod_pro):
    try:
        semillero = get_object_or_404(Semillero, id_sem=id_sem)
        proyecto = get_object_or_404(Proyecto, cod_pro=cod_pro)
        
        if not SemilleroProyecto.objects.filter(id_sem=semillero, cod_pro=proyecto).exists():
            messages.error(request, '❌ Este proyecto no pertenece a este semillero.')
            return redirect('resu-proyectos', id_sem=id_sem)

        restaurar_roles_lideres_proyecto(proyecto, semillero)

        eliminar_entregables_y_archivos(proyecto)

        eliminar_relaciones_proyecto(proyecto, semillero)

        nombre_proyecto = proyecto.nom_pro
        proyecto.delete()

        actualizar_progreso_semillero(semillero)

        messages.success(request, f'✅ Proyecto "{nombre_proyecto}" eliminado correctamente y roles restaurados.')

    except Exception as e:
        messages.error(request, f'⚠️ Error al eliminar el proyecto: {e}')

    return redirect('resu-proyectos', id_sem=id_sem)

def restaurar_roles_lideres_proyecto(proyecto, semillero):

    lideres_proyecto = UsuarioProyecto.objects.filter(
        cod_pro=proyecto, 
        es_lider_pro=True
    ).select_related('cedula')

    for relacion_lider in lideres_proyecto:
        usuario_lider = relacion_lider.cedula
        if usuario_lider.rol != 'Líder de Proyecto':
            continue

        otros_proyectos_lider = UsuarioProyecto.objects.filter(
            cedula=usuario_lider, 
            es_lider_pro=True
        ).exclude(cod_pro=proyecto).exists()

        if not otros_proyectos_lider:
            nuevo_rol = determinar_rol_original(usuario_lider, semillero)
            usuario_lider.rol = nuevo_rol
            usuario_lider.save()

def determinar_rol_original(usuario, semillero):
    if hasattr(usuario, 'rol_original') and usuario.rol_original:
        return usuario.rol_original
    
    es_lider_semillero = SemilleroUsuario.objects.filter(
        cedula=usuario, 
        es_lider=True
    ).exists()
    
    if es_lider_semillero:
        return 'Líder de Semillero'

    if usuario.vinculacion_laboral:
        vinculacion_lower = usuario.vinculacion_laboral.lower()
        if 'instructor' in vinculacion_lower:
            return 'Instructor'
        elif 'investigador' in vinculacion_lower:
            return 'Investigador'

    return 'Instructor'

def eliminar_entregables_y_archivos(proyecto):
    entregables = Entregable.objects.filter(cod_pro=proyecto)
    
    total_archivos_eliminados = 0
    total_entregables = entregables.count()
    
    for entregable in entregables:
        archivos = Archivo.objects.filter(entregable=entregable)

        for archivo in archivos:
            try:
                if archivo.archivo:
                    archivo.archivo.delete(save=False)
                    total_archivos_eliminados += 1
            except Exception as e:
                pass

        archivos.delete()

    entregables.delete()

def eliminar_relaciones_proyecto(proyecto, semillero):
    usuarios_eliminados = UsuarioProyecto.objects.filter(cod_pro=proyecto).delete()[0]

    aprendices_eliminados = ProyectoAprendiz.objects.filter(cod_pro=proyecto).delete()[0]

    SemilleroProyecto.objects.filter(id_sem=semillero, cod_pro=proyecto).delete()
    
@login_required
def cambiar_estado_proyecto(request, id_sem, cod_pro):
    cedula = request.session.get('cedula')  
    
    try:
        usuario = Usuario.objects.get(cedula=cedula)
    except Usuario.DoesNotExist:
        messages.error(request, "Usuario no encontrado.")
        return redirect('iniciarsesion') 
    
    semillero = get_object_or_404(Semillero, id_sem=id_sem)
    proyecto = get_object_or_404(Proyecto, cod_pro=cod_pro, semilleros=semillero)

    estados_activos = [
        'pendiente',
        'diagnostico',
        'planeacion',
        'ejecucion',
        'completado'
    ]

    if proyecto.estado_pro in estados_activos:
        proyecto.estado_original = proyecto.estado_pro
        proyecto.estado_pro = 'desactivado'
        proyecto.activo = False

        messages.warning(
            request,
            f'El proyecto "{proyecto.nom_pro}" fue DESACTIVADO'
        )

    else:
        proyecto.estado_pro = proyecto.estado_original if proyecto.estado_original else 'pendiente'
        proyecto.estado_anterior = None
        proyecto.activo = True

        messages.success(
            request,
            f'El proyecto "{proyecto.nom_pro}" fue ACTIVADO'
        )

    proyecto.save()
    return redirect('resu-proyectos', semillero.id_sem)

@login_required
def recursos(request, id_sem):
    usuario_id = request.session.get('cedula')
    if not usuario_id:
        messages.error(request, "Debes iniciar sesión para ver tu perfil.")
        return redirect('iniciarsesion')

    try:
        usuario = Usuario.objects.get(cedula=usuario_id)
    except Usuario.DoesNotExist:
        messages.error(request, "Usuario no encontrado.")
        return redirect('iniciarsesion') 
    
    semillero = get_object_or_404(Semillero, id_sem=id_sem)

    relaciones = SemilleroDocumento.objects.filter(id_sem=semillero)
    todos_documentos = Documento.objects.filter(
        cod_doc__in=relaciones.values_list('cod_doc', flat=True)
    )

    documentos = todos_documentos.filter(tipo__in=['Documento', 'Guía'])
    fichas = todos_documentos.filter(tipo__in=['Ficha', 'Acta'])

    cedulas = SemilleroUsuario.objects.filter(
        id_sem=semillero
    ).values_list('cedula', flat=True)
    
    total_usuarios = Usuario.objects.filter(cedula__in=cedulas).count()
    total_aprendices = Aprendiz.objects.filter(id_sem=semillero).count()
    total_miembros = total_usuarios + total_aprendices

    proyectos = SemilleroProyecto.objects.filter(id_sem=semillero)
    total_proyectos = proyectos.count()

    total_entregables = Entregable.objects.filter(
        cod_pro__in=proyectos.values('cod_pro')
    ).count()

    
    return render(request, 'paginas/recursos.html', {
        'current_page': 'recursos', 
        'current_page_name': 'Semilleros',
        'semillero': semillero,
        'documentos': documentos,
        'fichas': fichas,
        'total_miembros': total_miembros,
        'total_proyectos': total_proyectos,
        'total_entregables': total_entregables,
        'usuario' : usuario,
    })

@login_required
@semillero_activo_requerido
def agregar_recurso(request, id_sem):
    semillero = get_object_or_404(Semillero, id_sem=id_sem)
    
    if request.method == 'POST':
        nom_doc = request.POST.get('nom_doc')
        tipo = request.POST.get('tipo')
        archivo = request.FILES.get('archivo')
        
        if not all([nom_doc, tipo, archivo]):
            messages.error(request, 'Todos los campos son obligatorios')
            return redirect('recursos', id_sem=id_sem)

        if archivo and not archivo.name.lower().endswith('.pdf'):
            messages.error(request, 'Solo se permiten archivos PDF')
            return redirect('recursos', id_sem=id_sem)
        
        try:
            ultimo_doc = Documento.objects.order_by('-cod_doc').first()
            nuevo_cod_doc = (ultimo_doc.cod_doc + 1) if ultimo_doc else 1
            
            fecha_actual = datetime.now().strftime('%Y-%m-%d')

            documento = Documento(
                cod_doc=nuevo_cod_doc,
                nom_doc=nom_doc,
                tipo=tipo,
                fecha_doc=fecha_actual,
                archivo=archivo
            )

            documento.save()

            SemilleroDocumento.objects.create(
                id_sem=semillero,
                cod_doc=documento
            )
            
            messages.success(request, 'Documento guardado exitosamente')
            return redirect('recursos', id_sem=id_sem)
            
        except Exception as e:
            messages.error(request, f'Error al guardar el documento: {str(e)}')
            return redirect('recursos', id_sem=id_sem)

    return redirect('recursos', id_sem=id_sem)

@login_required
@semillero_activo_requerido
def eliminar_recurso(request, id_sem, cod_doc):
    semillero = get_object_or_404(Semillero, id_sem=id_sem)
    documento = get_object_or_404(Documento, cod_doc=cod_doc)

    try:
        if hasattr(documento, 'archivo') and documento.archivo:
            documento.archivo.delete(save=False)

        SemilleroDocumento.objects.filter(
            id_sem=semillero, cod_doc=documento
        ).delete()

        documento.delete()

        messages.success(request, f'✅ Recurso "{documento.nom_doc}" eliminado correctamente.')
    except Exception as e:
        messages.error(request, f'⚠️ Error al eliminar el recurso: {e}')

    return redirect('recursos', id_sem=id_sem)

# VISTAS DE PROYECTOS
@login_required
def proyectos(request):
    cedula = request.session.get('cedula')

    try:
        usuario = Usuario.objects.get(cedula=cedula)
    except Usuario.DoesNotExist:
        messages.error(request, "Usuario no encontrado.")
        return redirect('iniciarsesion')

    proyectos = usuario.proyectos.all()

    fecha_actual = timezone.now()
    inicio_mes = fecha_actual.replace(day=1)

    proyectos_list = Proyecto.objects.all().prefetch_related('semilleros')

    for proyecto in proyectos_list:
        verificar_y_actualizar_estados_entregables(proyecto)
        actualizar_progreso_proyecto(proyecto)

    total_proyectos = proyectos_list.count()
    
    proyectos_completados = proyectos_list.filter(estado_pro='completado').count()
    proyectos_pendientes = proyectos_list.filter(estado_pro='pendiente').count()

    proyectos_mes = proyectos_list.filter(
        fecha_creacion__gte=inicio_mes
    ).count()

    completados_mes = proyectos_list.filter(
        estado_pro='completado'
    ).count()

    pendientes_mes = proyectos_list.filter(
        fecha_creacion__gte=inicio_mes
    ).count()
    
    buscar = request.GET.get('buscar', '').strip()
    if buscar:
        proyectos_list = proyectos_list.filter(
            Q(nom_pro__icontains=buscar) |
            Q(semilleros__nombre__icontains=buscar)
        ).distinct()

    estado = request.GET.get('estado', '').strip()
    if estado:
        proyectos_list = proyectos_list.filter(estado_pro=estado)

    tipo = request.GET.get('tipo', '').strip()
    if tipo:
        proyectos_list = proyectos_list.filter(tipo=tipo)

    orden = request.GET.get('orden', '').strip()
    if orden == 'nombre':
        proyectos_list = proyectos_list.order_by('nom_pro')
    elif orden == 'fecha_creacion':
        proyectos_list = proyectos_list.order_by('fecha_creacion')
    else:
        proyectos_list = proyectos_list.order_by('-fecha_creacion')

    tipos_proyecto = Proyecto.objects.values_list('tipo', flat=True).exclude(tipo__isnull=True).exclude(tipo='').distinct().order_by('tipo')

    context = {
        'total_proyectos': total_proyectos,
        'proyectos_completados': proyectos_completados,
        'proyectos_pendientes': proyectos_pendientes,
        'proyectos_mes': proyectos_mes,
        'completados_mes': completados_mes,
        'pendientes_mes': pendientes_mes,
        'proyectos': proyectos_list,
        'tipos_proyecto': tipos_proyecto,
        'usuario' : usuario,
    }
    return render(request, 'paginas/proyectos.html', context)

@login_required
def detalle_proyecto(request, id_sem, cod_pro):
    usuario_id = request.session.get('cedula')
    if not usuario_id:
        messages.error(request, "Debes iniciar sesión para ver el proyecto.")
        return redirect('iniciarsesion')

    try:
        usuario = Usuario.objects.get(cedula=usuario_id)
    except Usuario.DoesNotExist:
        messages.error(request, "Usuario no encontrado.")
        return redirect('iniciarsesion')
    
    semillero = get_object_or_404(Semillero, id_sem=id_sem)
    
    proyectos = Proyecto.objects.filter(semilleroproyecto__id_sem=semillero)
    
    tipo_seleccionado = None
    proyecto_sel = None
    
    if cod_pro:
        proyectos = proyectos.order_by(
            Case(
                When(cod_pro=cod_pro, then=Value(0)),
                default=Value(1),
                output_field=IntegerField(),
            )
        )

        proyecto_sel = proyectos.filter(cod_pro=cod_pro).first()
        
        if proyecto_sel:
            tipo_seleccionado = proyecto_sel.tipo.lower()

    proyectos_sennova = list(proyectos.filter(tipo__iexact="Sennova"))
    proyectos_capacidad = list(proyectos.filter(tipo__iexact="CapacidadInstalada"))
    proyectos_formativos = list(proyectos.filter(tipo__iexact="Formativo"))

    todos_proyectos = proyectos_sennova + proyectos_capacidad + proyectos_formativos
    
    for proyecto in todos_proyectos:
        usuarios_proyecto = UsuarioProyecto.objects.filter(cod_pro=proyecto).select_related('cedula')
        aprendices_proyecto = ProyectoAprendiz.objects.filter(cod_pro=proyecto).select_related('cedula_apre')
        
        miembros_lista = []

        for up in usuarios_proyecto:
            miembros_lista.append({
                'cedula': up.cedula.cedula,
                'nombre_completo': f"{up.cedula.nom_usu} {up.cedula.ape_usu}",
                'iniciales': up.cedula.get_iniciales,
                'tipo': 'Usuario',
                'rol': up.cedula.rol,
                'estado': up.estado
            })

        for ap in aprendices_proyecto:
            miembros_lista.append({
                'cedula': ap.cedula_apre.cedula_apre,
                'nombre_completo': f"{ap.cedula_apre.nombre} {ap.cedula_apre.apellido}",
                'iniciales': ap.cedula_apre.get_iniciales,
                'tipo': 'Aprendiz',
                'rol': 'Aprendiz',
                'estado': ap.estado
            })
        
        proyecto.miembros_lista = miembros_lista
        proyecto.miembros_activos = [m for m in miembros_lista if m['estado'] == 'activo']

        proyecto.lineas_tec_lista = [l.strip() for l in proyecto.linea_tec.split('\n') if l.strip()] if proyecto.linea_tec else []
        proyecto.lineas_inv_lista = [l.strip() for l in proyecto.linea_inv.split('\n') if l.strip()] if proyecto.linea_inv else []
        proyecto.lineas_sem_lista = [l.strip() for l in proyecto.linea_sem.split('\n') if l.strip()] if proyecto.linea_sem else []

    proyectos_count = SemilleroProyecto.objects.filter(id_sem=semillero)
    total_proyectos = proyectos_count.count()
    
    usuarios_sem = SemilleroUsuario.objects.filter(id_sem=semillero)
    aprendices_sem = Aprendiz.objects.filter(id_sem=semillero)
    total_miembros = usuarios_sem.count() + aprendices_sem.count()
    miembros = usuarios_sem.select_related('cedula')
    
    total_entregables = Entregable.objects.filter(
        cod_pro__in=proyectos_count.values('cod_pro')
    ).count()

    context = {
        'current_page': 'resu_proyectos',
        'current_page_name': 'Detalle Proyecto',
        'usuario': usuario,
        'semillero': semillero,
        'proyectos_sennova': proyectos_sennova,
        'proyectos_capacidad': proyectos_capacidad,
        'proyectos_formativos': proyectos_formativos,
        'proyecto': proyecto_sel,
        'tipo_seleccionado': tipo_seleccionado,
        'cod_pro': cod_pro,
        'total_proyectos': total_proyectos,
        'total_miembros': total_miembros,
        'total_entregables': total_entregables,
        'miembros': miembros,
        'solo_lectura': True,
    }
    
    return render(request, 'paginas/resu-proyectos.html', context)

# VISTAS DE MIEMBROS
@login_required
def miembros(request):
    usuario_id = request.session.get('cedula')
    if not usuario_id:
        messages.error(request, "Debes iniciar sesión para ver tu perfil.")
        return redirect('iniciarsesion')

    mostrar_modal_codigo = request.session.get('mostrar_modal_codigo', False)
    aprendiz_verificacion = None

    if mostrar_modal_codigo:
        aprendiz_id = request.session.get('verificacion_aprendiz_id')
        if aprendiz_id:
            aprendiz_verificacion = Aprendiz.objects.filter(cedula_apre=aprendiz_id).first()

    if request.method == 'POST' and 'codigo' in request.POST:
        resultado = verificar_codigo_form(request)
        if resultado:
            return resultado

    try:
        usuario = Usuario.objects.get(cedula=usuario_id)
    except Usuario.DoesNotExist:
        messages.error(request, "Usuario no encontrado.")
        return redirect('iniciarsesion')

    vista = request.GET.get('vista', 'tarjeta')
    estado_filtro = request.GET.get('estado', '')
    rol_filtro = request.GET.get('rol', 'todos').strip().lower()
    busqueda = request.GET.get('busqueda', '').strip().lower()
    miembro_id = request.GET.get('miembro_id')

    if miembro_id and miembro_id.lower() == 'none':
        miembro_id = None

    if request.method == "POST" and 'verificar_codigo' not in request.POST and 'codigo' not in request.POST:
        cedula = request.POST.get("cedula")
        nuevo_estado = request.POST.get("estado")

        if cedula and nuevo_estado:
            usuario_obj = Usuario.objects.filter(cedula=cedula).first()
            aprendiz_obj = Aprendiz.objects.filter(cedula_apre=cedula).first()

            if usuario_obj:
                usuario_obj.estado = nuevo_estado
                usuario_obj.save()
                messages.success(request, f"Estado de {usuario_obj.nom_usu} actualizado a {nuevo_estado}.")
            elif aprendiz_obj:
                aprendiz_obj.estado_apre = nuevo_estado
                aprendiz_obj.save()
                messages.success(request, f"Estado de {aprendiz_obj.nombre} actualizado a {nuevo_estado}.")

        return redirect(f"{request.path}?miembro_id={cedula}")

    usuarios = Usuario.objects.all()
    aprendices = Aprendiz.objects.all()

    if busqueda:
        usuarios = usuarios.filter(
            Q(nom_usu__icontains=busqueda) |
            Q(ape_usu__icontains=busqueda) |
            Q(cedula__icontains=busqueda)
        )
        aprendices = aprendices.filter(
            Q(nombre__icontains=busqueda) |
            Q(apellido__icontains=busqueda) |
            Q(cedula_apre__icontains=busqueda)
        )

    if estado_filtro and estado_filtro != 'todos':
        usuarios = usuarios.filter(estado=estado_filtro)
        aprendices = aprendices.filter(estado_apre=estado_filtro)

    if rol_filtro == 'investigadores':
        usuarios = usuarios.filter(rol__iexact='Investigador')
        aprendices = aprendices.none()

    elif rol_filtro == 'instructores':
        usuarios = usuarios.filter(rol__iexact='Instructor')
        aprendices = aprendices.none()

    elif rol_filtro == 'lider_semillero':
        usuarios = usuarios.filter(rol__iregex=r'l[ií]der(\s+de)?\s+semillero')
        aprendices = aprendices.none()

    elif rol_filtro == 'dinamizador':
        usuarios = usuarios.filter(rol__iexact='Dinamizador')
        aprendices = aprendices.none()

    elif rol_filtro == 'lider_proyecto':
        usuarios = usuarios.filter(rol__iregex=r'l[ií]der(\s+de)?\s+proyecto')
        aprendices = aprendices.none()

    elif rol_filtro == 'aprendices':
        usuarios = usuarios.none()

    miembros = []

    for u in usuarios:
        ultimo_acceso = "Sin registro"
        if u.last_login:
            tiempo = now() - u.last_login
            dias, segundos = tiempo.days, tiempo.seconds

            if dias == 0:
                if segundos < 60:
                    ultimo_acceso = "Hace unos segundos"
                elif segundos < 3600:
                    minutos = segundos // 60
                    ultimo_acceso = f"Hace {minutos} minuto{'s' if minutos != 1 else ''}"
                else:
                    horas = segundos // 3600
                    ultimo_acceso = f"Hace {horas} hora{'s' if horas != 1 else ''}"
            elif dias == 1:
                ultimo_acceso = "Ayer"
            elif dias < 7:
                ultimo_acceso = f"Hace {dias} día{'s' if dias != 1 else ''}"
            elif dias < 30:
                semanas = dias // 7
                ultimo_acceso = f"Hace {semanas} semana{'s' if semanas != 1 else ''}"
            elif dias < 365:
                meses = dias // 30
                ultimo_acceso = f"Hace {meses} mes{'es' if meses != 1 else ''}"
            else:
                años = dias // 365
                ultimo_acceso = f"Hace {años} año{'s' if años != 1 else ''}"

        miembros.append({
            'id': u.cedula,
            'nombres': u.nom_usu,
            'apellidos': u.ape_usu,
            'correo_sena': u.correo_ins,
            'celular': u.telefono,
            'rol': u.rol,
            'ultima_sesion': ultimo_acceso,
            'tipo': 'usuario',
            'imagen_perfil': u.imagen_perfil.url if u.imagen_perfil else None,
            'objeto': u
        })

    for a in aprendices:
        miembros.append({
            'id': a.cedula_apre,
            'nombres': a.nombre,
            'apellidos': a.apellido,
            'correo_sena': a.correo_ins,
            'celular': a.telefono,
            'rol': 'Aprendiz',
            'ultima_sesion': None,
            'tipo': 'aprendiz',
            'objeto': a
        })

    total_instructores = Usuario.objects.filter(rol='Instructor').count()
    total_investigadores = Usuario.objects.filter(rol='Investigador').count()
    total_aprendices = Aprendiz.objects.count()

    miembro_seleccionado = None
    tipo_miembro = None

    if miembro_id:
        usuario_sel = Usuario.objects.filter(cedula=miembro_id).first()
        if usuario_sel:
            tipo_miembro = 'usuario'
            proyectos = SemilleroProyecto.objects.filter(
                cod_pro__usuarioproyecto__cedula=usuario_sel
            ).select_related(
                'id_sem',
                'cod_pro'
            ).distinct()
            miembro_seleccionado = {
                'id': usuario_sel.cedula,
                'cedula': usuario_sel.cedula,
                'nombres': usuario_sel.nom_usu,
                'apellidos': usuario_sel.ape_usu,
                'fecha_nacimiento': usuario_sel.fecha_nacimiento,
                'correo_personal': usuario_sel.correo_per,
                'correo_sena': usuario_sel.correo_ins,
                'celular': usuario_sel.telefono,
                'vinculacion': usuario_sel.vinculacion_laboral,
                'dependencia': usuario_sel.dependencia,
                'rol': usuario_sel.rol,
                'imagen_perfil': usuario_sel.imagen_perfil,
                'estado': usuario_sel.estado,
                'semilleros': usuario_sel.semilleros.all(),
                'proyectos': proyectos,
            }
        else:
            aprendiz_sel = Aprendiz.objects.filter(cedula_apre=miembro_id).first()
            if aprendiz_sel:
                tipo_miembro = 'aprendiz'

                numeros_revelados = request.session.get('numeros_revelados', {})
                info_numero = numeros_revelados.get(str(miembro_id))
                
                if info_numero:
                    timestamp_revelado = info_numero.get('timestamp', 0)
                    tiempo_transcurrido = timezone.now().timestamp() - timestamp_revelado
                    
                    if tiempo_transcurrido < 60:
                        numero_visible = info_numero['numero']
                    else:
                        del numeros_revelados[str(miembro_id)]
                        request.session['numeros_revelados'] = numeros_revelados
                        
                        numero_descifrado = descifrar_numero(aprendiz_sel.numero_cuenta)
                        if numero_descifrado and numero_descifrado != "****":
                            numero_visible = f"*********{numero_descifrado[-4:]}"
                        else:
                            numero_visible = "**********"
                else:
                    numero_descifrado = descifrar_numero(aprendiz_sel.numero_cuenta)
                    if numero_descifrado and numero_descifrado != "****":
                        numero_visible = f"*********{numero_descifrado[-4:]}"
                    else:
                        numero_visible = "**********"

                proyectos = SemilleroProyecto.objects.filter(
                    cod_pro__proyectoaprendiz__cedula_apre=aprendiz_sel
                ).select_related(
                    'id_sem',
                    'cod_pro'
                ).distinct()
                
                miembro_seleccionado = {
                    'id': aprendiz_sel.cedula_apre,
                    'cedula': aprendiz_sel.cedula_apre,
                    'nombres': aprendiz_sel.nombre,
                    'apellidos': aprendiz_sel.apellido,
                    'correo_personal': aprendiz_sel.correo_per,
                    'fecha_nacimiento': aprendiz_sel.fecha_nacimiento,
                    'correo_sena': aprendiz_sel.correo_ins,
                    'medio_bancario': aprendiz_sel.medio_bancario,
                    'numero_cuenta_visible': numero_visible,
                    'celular': aprendiz_sel.telefono,
                    'ficha': aprendiz_sel.ficha,
                    'programa': aprendiz_sel.programa,
                    'rol': 'Aprendiz',
                    'estado': aprendiz_sel.estado_apre,
                    'semilleros': [aprendiz_sel.id_sem] if aprendiz_sel.id_sem else [],
                    'proyectos': proyectos,
                }

    contexto = {
        'miembros': miembros,
        'total_instructores': total_instructores,
        'total_investigadores': total_investigadores,
        'total_aprendices': total_aprendices,
        'miembro_seleccionado': miembro_seleccionado,
        'tipo_miembro': tipo_miembro,
        'vista': vista,
        'estado_filtro': estado_filtro,
        'rol_filtro': rol_filtro,
        'busqueda': busqueda,
        'usuario': usuario,
        'mostrar_modal_codigo': mostrar_modal_codigo,
        'aprendiz_verificacion': aprendiz_verificacion,
    }

    return render(request, 'paginas/miembros.html', contexto)

def registro_aprendiz(request):  
    if request.method == 'POST':
        form = AprendizForm(request.POST)
        if form.is_valid():
            try:
                aprendiz = form.save(commit=False)
                aprendiz.estado_apre = 'Activo'
                
                if aprendiz.acepta_tratamiento_datos:
                    aprendiz.fecha_aceptacion_datos = timezone.now()
                
                aprendiz.save()
                
                messages.success(request, f'¡Aprendiz {aprendiz.nombre} {aprendiz.apellido} registrado exitosamente!')

                return redirect('registro_aprendiz')
                
            except Exception as e:
                messages.error(request, f'Error al guardar: {str(e)}')
        else:
            messages.error(request, 'Por favor corrija los errores señalados en el formulario.')
            
            errores_info = {}
            for field_name, errors in form.errors.items():
                if field_name != '__all__':
                    errores_info[field_name] = str(errors[0])

            return render(request, 'paginas/formaprendiz.html', {
                'form': form,
                'errores_info': errores_info
            })
    else:
        form = AprendizForm()
    
    return render(request, 'paginas/formaprendiz.html', {'form': form})

@login_required
@permission_required("GC2.change_aprendiz")
def solicitar_codigo_verificacion_form(request, aprendiz_id):
    try:
        usuario_id = request.session.get('cedula')
        if not usuario_id:
            messages.error(request, 'No hay sesión activa')
            return redirect('miembros')

        usuario = Usuario.objects.get(cedula=usuario_id)

        # 1. Verificar si puede solicitar un nuevo código
        puede_solicitar, mensaje_error = usuario.puede_solicitar_codigo()
        if not puede_solicitar:
            messages.error(request, mensaje_error)
            return redirect('miembros')

        # 2. Verificar que el aprendiz existe
        aprendiz = Aprendiz.objects.filter(cedula_apre=aprendiz_id).first()
        if not aprendiz:
            messages.error(request, 'Aprendiz no encontrado')
            return redirect('miembros')

        # 3. Verificar que el usuario tiene correo
        correo_destino = usuario.correo_per
        if not correo_destino:
            messages.error(request, 'No hay correo registrado para enviar el código')
            return redirect('miembros')

        # 4. Generar código y registrar envío
        codigo = usuario.generar_codigo_verificacion()
        usuario.registrar_codigo_enviado()

        intentos_restantes = max(0, 7 - usuario.intentos_codigo_fallidos)

        # 5. Renderizar y enviar correo
        asunto = "Código de Verificación - InnHub"
        mensaje = render_to_string('paginas/verification_code_email.html', {
            'nombre_usuario': usuario.nom_usu,
            'codigo': codigo,
            'intentos_restantes': intentos_restantes
        })

        try:
            send_mail(
                asunto,
                '',
                settings.DEFAULT_FROM_EMAIL,
                [correo_destino],
                html_message=mensaje,
                fail_silently=False
            )

            request.session['verificacion_aprendiz_id'] = aprendiz_id
            request.session['mostrar_modal_codigo'] = True
            request.session['codigo_enviado'] = True

            messages.success(request, f'✅ Código enviado a {correo_destino}.')
            return redirect('miembros')

        except Exception as email_error:
            messages.error(request, f'Error al enviar el correo: {str(email_error)}')
            return redirect('miembros')

    except Usuario.DoesNotExist:
        messages.error(request, 'Usuario no encontrado')
        return redirect('miembros')
    except Exception as e:
        messages.error(request, f'Error: {str(e)}')
        return redirect('miembros')

@login_required
@require_http_methods(["POST"])
def verificar_codigo_form(request):
    try:
        usuario_id = request.session.get('cedula')
        if not usuario_id:
            messages.error(request, 'No hay sesión activa')
            return redirect('miembros')

        usuario = Usuario.objects.get(cedula=usuario_id)
        ahora = timezone.now()

        # 1. Verificar si el usuario está bloqueado
        if usuario.bloqueado_hasta and ahora < usuario.bloqueado_hasta:
            tiempo_restante = usuario.bloqueado_hasta - ahora
            minutos = int(tiempo_restante.total_seconds() / 60)
            horas = minutos // 60
            mins = minutos % 60
            tiempo_msg = f"{horas} hora(s) y {mins} minuto(s)" if horas > 0 else f"{mins} minuto(s)"

            request.session['mostrar_modal_codigo'] = False
            request.session.pop('verificacion_aprendiz_id', None)

            messages.error(request, f'⏱️ Demasiados intentos fallidos. Espera {tiempo_msg} antes de intentar nuevamente.')
            return redirect('miembros')

        codigo_ingresado = request.POST.get('codigo', '').strip()
        aprendiz_id = request.session.get('verificacion_aprendiz_id')

        # 2. Validar formato del código
        if not codigo_ingresado or len(codigo_ingresado) != 6:
            messages.error(request, '❌ Debes ingresar los 6 dígitos del código')
            return redirect(f'/miembros/?miembro_id={aprendiz_id}')

        # 3. Validar que hay sesión de verificación activa
        if not aprendiz_id:
            messages.error(request, 'Sesión expirada')
            request.session['mostrar_modal_codigo'] = False
            return redirect('miembros')

        # 4. Verificar código
        if not usuario.verificar_codigo(codigo_ingresado):
            usuario.incrementar_intentos_fallidos()

            # ← FIX: refrescar desde BD para obtener bloqueado_hasta actualizado
            usuario.refresh_from_db()

            intentos_restantes = max(0, 7 - usuario.intentos_codigo_fallidos)
            request.session['intentos_restantes'] = intentos_restantes

            if intentos_restantes == 0:
                tiempo_bloqueo = usuario.bloqueado_hasta - ahora if usuario.bloqueado_hasta else timedelta(minutes=15)
                minutos = int(tiempo_bloqueo.total_seconds() / 60)
                horas = minutos // 60
                mins = minutos % 60
                tiempo_msg = f"{horas} hora(s) y {mins} minuto(s)" if horas > 0 else f"{mins} minuto(s)"

                request.session['mostrar_modal_codigo'] = False
                request.session.pop('verificacion_aprendiz_id', None)

                messages.error(request, f'🚫 Demasiados intentos fallidos. Espera {tiempo_msg} antes de intentar nuevamente.')
                return redirect('miembros')

            messages.error(request, f'❌ Código incorrecto. Te quedan {intentos_restantes} intentos.')
            return redirect(f'/miembros/?miembro_id={aprendiz_id}')

        # 5. Código correcto — obtener aprendiz
        aprendiz = Aprendiz.objects.filter(cedula_apre=aprendiz_id).first()
        if not aprendiz:
            messages.error(request, 'Aprendiz no encontrado')
            return redirect('miembros')

        # 6. Descifrar y guardar número en sesión (visible 60 segundos)
        numero_completo = descifrar_numero(aprendiz.numero_cuenta)
        numeros_revelados = request.session.get('numeros_revelados', {})
        numeros_revelados[str(aprendiz_id)] = {
            'numero': numero_completo,
            'timestamp': timezone.now().timestamp()
        }
        request.session['numeros_revelados'] = numeros_revelados
        request.session['numero_cuenta_aprendiz_id'] = str(aprendiz_id)

        # 7. Limpiar estado de verificación
        usuario.resetear_intentos_codigo()
        request.session['mostrar_modal_codigo'] = False
        request.session.pop('verificacion_aprendiz_id', None)
        request.session.pop('codigo_enviado', None)
        request.session.pop('intentos_restantes', None)

        messages.success(request, '✅ Código verificado correctamente. El número estará visible por 30 segundos.')
        return redirect(f'/miembros/?miembro_id={aprendiz_id}')

    except Usuario.DoesNotExist:
        messages.error(request, 'Usuario no encontrado')
        return redirect('miembros')
    except Exception as e:
        messages.error(request, f'Error: {str(e)}')
        return redirect('miembros')
    
@login_required
def cancelar_verificacion(request):
    request.session['mostrar_modal_codigo'] = False
    
    if 'verificacion_aprendiz_id' in request.session:
        del request.session['verificacion_aprendiz_id']
    if 'codigo_enviado' in request.session:
        del request.session['codigo_enviado']
    if 'intentos_restantes' in request.session:
        del request.session['intentos_restantes']
    
    if 'numeros_revelados' in request.session:
        del request.session['numeros_revelados']
    if 'numero_cuenta_aprendiz_id' in request.session:
        del request.session['numero_cuenta_aprendiz_id']
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse({'success': True})
    
    messages.info(request, 'Verificación cancelada')
    return redirect('miembros')

@login_required
def limpiar_numero_revelado(request):
    if 'numero_cuenta_revelado' in request.session:
        del request.session['numero_cuenta_revelado']
    if 'numero_cuenta_aprendiz_id' in request.session:
        del request.session['numero_cuenta_aprendiz_id']
    
    return redirect('miembros')

# VISTAS DE EVENTOS
@login_required
def eventos(request):
    cedula = request.session.get('cedula')
    
    try:
        usuario = Usuario.objects.get(cedula=cedula)
    except Usuario.DoesNotExist:
        messages.error(request, "Usuario no encontrado.")
        return redirect('iniciarsesion')

    limite = timezone.now() - timedelta(hours=12)
    Evento.objects.filter(
        estado_eve__in=["Cancelado", "Finalizado"],
        fecha_estado__lt=limite
    ).delete()

    ahora = timezone.localtime()
    eventos = Evento.objects.all()

    for evento in eventos:

        if evento.estado_eve.lower() == "cancelado":
            continue

        hora_inicio = datetime.strptime(str(evento.hora_inicio), "%H:%M:%S").time()
        hora_fin = datetime.strptime(str(evento.hora_fin), "%H:%M:%S").time()

        inicio = timezone.make_aware(datetime.combine(evento.fecha_eve, hora_inicio))
        fin = timezone.make_aware(datetime.combine(evento.fecha_eve, hora_fin))

        if ahora > fin:
            if evento.estado_eve != "Finalizado":
                evento.estado_eve = "Finalizado"
                evento.save()
            continue

        if inicio <= ahora <= fin:
            if evento.estado_eve != "En Curso":
                evento.estado_eve = "En Curso"
                evento.save()
            continue

        tiempo_falta = inicio - ahora

        if timedelta(hours=0) < tiempo_falta <= timedelta(hours=24):
            if evento.estado_eve != "Próximo":
                evento.estado_eve = "Próximo"
                evento.save()
            continue

        if tiempo_falta > timedelta(hours=24):
            if evento.estado_eve != "Programado":
                evento.estado_eve = "Programado"
                evento.save()
            continue

    buscar = request.GET.get("buscar")
    if buscar:
        eventos = eventos.filter(nom_eve__icontains=buscar)

    estado = request.GET.get("estado")
    modalidad = request.GET.get("modalidad")

    if estado and estado != "Todos":
        eventos = eventos.filter(estado_eve=estado)

    if modalidad and modalidad != "Todos":
        eventos = eventos.filter(modalidad_eve=modalidad)

    mes_actual = ahora.month

    total_eventos = Evento.objects.count()
    total_mes = Evento.objects.filter(fecha_eve__month=mes_actual).count()

    presenciales = Evento.objects.filter(modalidad_eve="Presencial").count()
    presenciales_mes = Evento.objects.filter(modalidad_eve="Presencial", fecha_eve__month=mes_actual).count()

    virtuales = Evento.objects.filter(modalidad_eve="Virtual").count()
    virtuales_mes = Evento.objects.filter(modalidad_eve="Virtual", fecha_eve__month=mes_actual).count()

    contexto = {
        'current_page': 'eventos',
        'current_page_name': 'Eventos',
        'eventos': eventos,
        'total_eventos': total_eventos,
        'total_mes': total_mes,
        'presenciales': presenciales,
        'presenciales_mes': presenciales_mes,
        'virtuales': virtuales,
        'virtuales_mes': virtuales_mes,
        'estado_seleccionado': estado,
        'modalidad_seleccionada': modalidad,
        'busqueda': buscar,
        'usuario': usuario
    }

    return render(request, 'paginas/eventos.html', contexto)

@login_required
def crear_evento(request):
    cedula = request.session.get('cedula')
    try:
        usuario = Usuario.objects.get(cedula=cedula)
    except Usuario.DoesNotExist:
        messages.error(request, "Usuario no encontrado.")
        return redirect('iniciarsesion')

    if request.method == 'POST':

        nom_eve = request.POST.get('nom_eve')
        fecha_eve = request.POST.get('fecha_eve')
        desc_eve = request.POST.get('desc_eve', '')
        modalidad_eve = request.POST.get('modalidad_eve')
        direccion_eve = request.POST.get('direccion_eve', '')
        estado_eve = request.POST.get('estado_eve', 'Programado')
        hora_inicio = request.POST.get('hora_inicio')
        hora_fin = request.POST.get('hora_fin')
        link = request.POST.get('link', '')

        if not nom_eve or not fecha_eve:
            messages.error(request, "Faltan campos obligatorios.")
            return redirect('eventos')

        if modalidad_eve == "Virtual" and not link.strip():
            messages.error(request, "El link es obligatorio para eventos virtuales.")
            return redirect('eventos')

        if modalidad_eve == "Presencial" and not direccion_eve.strip():
            messages.error(request, "La dirección es obligatoria para eventos presenciales.")
            return redirect('eventos')

        Evento.objects.create(
            nom_eve=nom_eve,
            fecha_eve=fecha_eve,
            desc_eve=desc_eve,
            modalidad_eve=modalidad_eve,
            direccion_eve=direccion_eve,
            link=link,
            estado_eve=estado_eve,
            hora_inicio=hora_inicio,
            hora_fin=hora_fin,
            cedula=usuario
        )

        messages.success(request, f"Evento '{nom_eve}' creado correctamente.")
        return redirect('eventos')

    return redirect('eventos')

@login_required
def editar_evento(request, cod_eve):
    evento = get_object_or_404(Evento, cod_eve=cod_eve)

    if request.method == "POST":

        evento.nom_eve = request.POST.get("nom_eve")
        evento.fecha_eve = request.POST.get("fecha_eve")
        evento.hora_inicio = request.POST.get("hora_inicio")
        evento.hora_fin = request.POST.get("hora_fin")
        evento.modalidad_eve = request.POST.get("modalidad_eve")
        evento.direccion_eve = request.POST.get("direccion_eve")
        evento.desc_eve = request.POST.get("desc_eve")
        evento.estado_eve = request.POST.get("estado_eve")
        evento.link = request.POST.get("link", "")

        if evento.modalidad_eve == "Virtual" and evento.link.strip() == "":
            messages.error(request, "Debe ingresar el link para eventos virtuales.")
            return redirect("eventos")

        if evento.modalidad_eve == "Presencial" and evento.direccion_eve.strip() == "":
            messages.error(request, "Debe ingresar la dirección para eventos presenciales.")
            return redirect("eventos")

        evento.save()
        messages.success(request, f"El evento '{evento.nom_eve}' fue actualizado correctamente.")

        return redirect("eventos")

    return redirect("eventos")

@login_required
def cancelar_evento(request):
    if request.method == "POST":
        cod = request.POST.get("cod_eve")

        evento = get_object_or_404(Evento, cod_eve=cod)

        if evento.estado_eve.lower() == "cancelado":
            messages.warning(request, f"El evento '{evento.nom_eve}' ya está cancelado.")
            return redirect("eventos")

        evento.estado_eve = "Cancelado"
        evento.save()

        messages.success(request, f"El evento '{evento.nom_eve}' fue cancelado correctamente.")
        return redirect("eventos")

    return redirect("eventos")

# VISTAS DE CENTRO DE AYUDA
@login_required
def centroayuda(request):
    cedula = request.session.get('cedula')

    try:
        usuario = Usuario.objects.get(cedula=cedula)
    except Usuario.DoesNotExist:
        messages.error(request, "Usuario no encontrado.")
        return redirect('iniciarsesion')
    
    contexto = {
        'usuario': usuario
    }
    return render(request, 'paginas/centroayuda.html', contexto)

def formulario_soporte(request):
    if request.method == 'POST':
        form = FormularioSoporte(request.POST, request.FILES)
        if form.is_valid():
            nombre = form.cleaned_data['nombreCompleto']
            email_remitente = form.cleaned_data['email']
            asunto = form.cleaned_data['asunto']
            descripcion = form.cleaned_data['descripcion']
            urgencia = form.cleaned_data['urgencia']
            
            # Determinar color según nivel de urgencia
            urgencia_colors = {
                'baja': '#28a745',
                'media': '#ffc107', 
                'alta': '#dc3545',
                'critica': '#6f42c1'
            }
            urgencia_color = urgencia_colors.get(urgencia.lower(), '#6c757d')
            
            # Renderizar plantilla HTML profesional
            mensaje_html = render_to_string('paginas/support_request_email.html', {
                'nombre': nombre,
                'email': email_remitente,
                'asunto': asunto,
                'urgencia': urgencia,
                'urgencia_color': urgencia_color,
                'descripcion': descripcion
            })
            
            # Crear email con HTML
            email = EmailMessage(
                f'Solicitud de Soporte - InnHub: {asunto}',
                mensaje_html,
                settings.DEFAULT_FROM_EMAIL,
                ['mundobovinoapp@gmail.com'], 
                reply_to=[email_remitente]
            )
            
            # Configurar como HTML
            email.content_subtype = "html"
            
            # Adjuntar archivos si existen
            files = request.FILES.getlist('adjuntos')
            if files:
                for i, adjunto in enumerate(files[:3]):
                    email.attach(adjunto.name, adjunto.read(), adjunto.content_type)
            
            email.send()
            messages.success(request, 'Tu solicitud ha sido enviada correctamente.')
            return render(request, 'paginas/centroayuda.html', {'form': FormularioSoporte()})
    else:
        form = FormularioSoporte()
    
    return render(request, 'paginas/centroayuda.html', {'form': form})

# VISTAS DE REPORTES
def reportes(request):
    cedula = request.session.get('cedula')
 
    try:
        usuario = Usuario.objects.get(cedula=cedula)
    except Usuario.DoesNotExist:
        messages.error(request, "Usuario no encontrado.")
        return redirect('iniciarsesion')
    
    contexto = {
        'usuario': usuario
    }
    return render(request, 'paginas/reportes.html', contexto)

def reporte_general_semilleros(request):
    wb = Workbook()
    ws = wb.active
    ws.title = "Semilleros"

    crear_encabezado_reporte(ws, request)

    thin_border = Border(
        left=Side(style="thin", color="090979"),
        right=Side(style="thin", color="090979"),
        top=Side(style="thin", color="090979"),
        bottom=Side(style="thin", color="090979")
    )

    ws.merge_cells("A7:K7")
    titulo = ws["A7"]
    titulo.value = "REPORTE GENERAL DE SEMILLEROS"
    titulo.font = Font(bold=True, size=16)
    titulo.alignment = Alignment(horizontal="center")

    fila_encabezado = 8
    encabezados = [
        "Código Semillero", "Siglas", "Nombre Semillero", "Descripción",
        "Objetivos", "Fecha Creación", "Cantidad de Miembros",
        "Número de Proyectos", "Estado", "Progreso General",
        "Líder de Semillero"
    ]

    for col, texto in enumerate(encabezados, start=1):
        cell = ws.cell(row=fila_encabezado, column=col, value=texto)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill(start_color="3498DB", end_color="3498DB", fill_type="solid")
        cell.border = thin_border
        cell.alignment = Alignment(horizontal="center", vertical="center")

    fila_actual = fila_encabezado + 1

    semilleros = Semillero.objects.all()

    for s in semilleros:
        cantidad_miembros = (
            SemilleroUsuario.objects.filter(id_sem=s).count() +
            Aprendiz.objects.filter(id_sem=s).count()
        )

        cantidad_proyectos = s.proyectos.count()
        lider = SemilleroUsuario.objects.filter(id_sem=s, es_lider=True).first()
        nombre_lider = lider.cedula.nom_usu + " " + lider.cedula.ape_usu if lider else "Sin líder"
        objetivos = ", ".join(s.objetivo.splitlines()) if s.objetivo else ""

        ws.append([
            s.cod_sem,
            s.sigla,
            s.nombre,
            s.desc_sem,
            objetivos,
            s.fecha_creacion.strftime("%Y-%m-%d"),
            cantidad_miembros,
            cantidad_proyectos,
            s.estado,
            s.progreso_sem,
            nombre_lider
        ])

        for col in range(1, 12):
            ws.cell(row=fila_actual, column=col).border = thin_border

        fila_actual += 1

    fila_fin_datos = fila_actual - 1

    widths = [20, 12, 30, 35, 30, 15, 20, 20, 14, 18, 25]
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[chr(64 + i)].width = w

    chart1 = BarChart()
    chart1.title = "Miembros por Semillero"
    data1 = Reference(ws, min_col=7, min_row=fila_encabezado, max_row=fila_fin_datos)
    cats = Reference(ws, min_col=3, min_row=fila_encabezado + 1, max_row=fila_fin_datos)
    chart1.add_data(data1, titles_from_data=True)
    chart1.set_categories(cats)
    ws.add_chart(chart1, "M9")

    chart2 = BarChart()
    chart2.title = "Proyectos por Semillero"
    data2 = Reference(ws, min_col=8, min_row=fila_encabezado, max_row=fila_fin_datos)
    chart2.add_data(data2, titles_from_data=True)
    chart2.set_categories(cats)
    ws.add_chart(chart2, "M26")

    chart3 = BarChart()
    chart3.title = "Progreso General"
    data3 = Reference(ws, min_col=10, min_row=fila_encabezado, max_row=fila_fin_datos)
    chart3.add_data(data3, titles_from_data=True)
    chart3.set_categories(cats)
    ws.add_chart(chart3, "M43")

    estados_count = {}
    for s in semilleros:
        if s.estado:
            estados_count[s.estado] = estados_count.get(s.estado, 0) + 1

    if estados_count:
        fila_titulo = ws.max_row + 3

        ws.merge_cells(start_row=fila_titulo, start_column=1, end_row=fila_titulo, end_column=2)
        titulo_estado = ws.cell(row=fila_titulo, column=1)
        titulo_estado.value = "RESUMEN DE ESTADO DE LOS SEMILLEROS"
        titulo_estado.font = Font(bold=True, size=13)
        titulo_estado.alignment = Alignment(horizontal="center")

        fila_tabla = fila_titulo + 1

        ws.cell(row=fila_tabla, column=1, value="Estado").font = Font(bold=True)
        ws.cell(row=fila_tabla, column=2, value="Cantidad").font = Font(bold=True)

        fila = fila_tabla
        for estado, cantidad in estados_count.items():
            fila += 1
            ws.cell(row=fila, column=1, value=estado)
            ws.cell(row=fila, column=2, value=cantidad)

        for row in ws.iter_rows(
            min_row=fila_tabla,
            max_row=fila,
            min_col=1,
            max_col=2
        ):
            for cell in row:
                cell.border = thin_border

        data_estado = Reference(ws, min_col=2, min_row=fila_tabla, max_row=fila)
        labels_estado = Reference(ws, min_col=1, min_row=fila_tabla + 1, max_row=fila)

        chart_estado = PieChart()
        chart_estado.title = "Estados de los Semilleros"
        chart_estado.add_data(data_estado, titles_from_data=True)
        chart_estado.set_categories(labels_estado)
        ws.add_chart(chart_estado, "M60")

    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response["Content-Disposition"] = 'attachment; filename="reporte_general_semilleros.xlsx"'
    wb.save(response)

    return response

def reporte_general_proyectos(request):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Proyectos"

    crear_encabezado_reporte(ws, request)
    
    thin_border = Border(
        left=Side(style="thin", color="090979"),
        right=Side(style="thin", color="090979"),
        top=Side(style="thin", color="090979"),
        bottom=Side(style="thin", color="090979")
    )

    ws.merge_cells("A7:M7")
    titulo = ws["A7"]
    titulo.value = "REPORTE GENERAL DE PROYECTOS"
    titulo.font = Font(bold=True, size=16)
    titulo.alignment = Alignment(horizontal="center")

    fila_encabezado = 8
    encabezados = [
        "Nombre Proyecto", "Tipo", "Descripción",
        "Líneas Tecnológicas", "Líneas de Investigación",
        "Líneas de Semillero", "Notas Adicionales",
        "Cantidad de Miembros", "Cantidad de Entregables",
        "Fecha Creación", "Estado Actual",
        "Progreso", "Líder de Proyecto"
    ]

    for col, texto in enumerate(encabezados, start=1):
        cell = ws.cell(row=fila_encabezado, column=col, value=texto)
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal="center")
        cell.border = thin_border

    fila_actual = fila_encabezado + 1
    proyectos = Proyecto.objects.all()

    for p in proyectos:
        cantidad_miembros = (
            UsuarioProyecto.objects.filter(cod_pro=p).count() +
            ProyectoAprendiz.objects.filter(cod_pro=p).count()
        )
        cantidad_entregables = Entregable.objects.filter(cod_pro=p).count()

        lider_pro = UsuarioProyecto.objects.filter(cod_pro=p, es_lider_pro=True).first()
        nombre_lider = lider_pro.cedula.nom_usu + " " + lider_pro.cedula.ape_usu if lider_pro else "Sin líder"

        lineas_tec = ", ".join(l.strip() for l in p.linea_tec.split("\n") if l.strip()) if p.linea_tec else ""
        lineas_inv = ", ".join(l.strip() for l in p.linea_inv.split("\n") if l.strip()) if p.linea_inv else ""
        lineas_sem = ", ".join(l.strip() for l in p.linea_sem.split("\n") if l.strip()) if p.linea_sem else ""
        notas = ", ".join(l.strip() for l in p.notas.split("\n") if l.strip()) if p.notas else ""

        ws.append([
            p.nom_pro, p.tipo, p.desc_pro,
            lineas_tec, lineas_inv, lineas_sem,
            notas, cantidad_miembros,
            cantidad_entregables,
            p.fecha_creacion.strftime("%Y-%m-%d %H:%M"),
            p.estado_pro, p.progreso,
            nombre_lider
        ])

        for col in range(1, 14):
            ws.cell(row=fila_actual, column=col).border = thin_border

        fila_actual += 1

    fila_fin = fila_actual - 1

    categorias = Reference(ws, min_col=1, min_row=fila_encabezado + 1, max_row=fila_fin)

    chart_progreso = BarChart()
    chart_progreso.title = "Progreso por Proyecto"
    valores = Reference(ws, min_col=12, min_row=fila_encabezado, max_row=fila_fin)
    chart_progreso.add_data(valores, titles_from_data=True)
    chart_progreso.set_categories(categorias)
    ws.add_chart(chart_progreso, "O3")

    chart_miembros = BarChart()
    chart_miembros.title = "Miembros por Proyecto"
    valores = Reference(ws, min_col=8, min_row=fila_encabezado, max_row=fila_fin)
    chart_miembros.add_data(valores, titles_from_data=True)
    chart_miembros.set_categories(categorias)
    ws.add_chart(chart_miembros, "O20")

    chart_entregables = BarChart()
    chart_entregables.title = "Entregables por Proyecto"
    valores = Reference(ws, min_col=9, min_row=fila_encabezado, max_row=fila_fin)
    chart_entregables.add_data(valores, titles_from_data=True)
    chart_entregables.set_categories(categorias)
    ws.add_chart(chart_entregables, "O37")

    def crear_tabla_resumen(titulo_txt, data_dict, chart, pos):
        fila_titulo = ws.max_row + 3
        ws.merge_cells(start_row=fila_titulo, start_column=1, end_row=fila_titulo, end_column=2)
        t = ws.cell(row=fila_titulo, column=1)
        t.value = titulo_txt
        t.font = Font(bold=True)
        t.alignment = Alignment(horizontal="center")

        fila_tabla = fila_titulo + 1
        ws.cell(row=fila_tabla, column=1, value="Categoría").font = Font(bold=True)
        ws.cell(row=fila_tabla, column=2, value="Cantidad").font = Font(bold=True)

        fila = fila_tabla
        for k, v in data_dict.items():
            fila += 1
            ws.cell(row=fila, column=1, value=k)
            ws.cell(row=fila, column=2, value=v)

        for r in ws.iter_rows(min_row=fila_tabla, max_row=fila, min_col=1, max_col=2):
            for c in r:
                c.border = thin_border

        data = Reference(ws, min_col=2, min_row=fila_tabla, max_row=fila)
        labels = Reference(ws, min_col=1, min_row=fila_tabla + 1, max_row=fila)
        chart.add_data(data, titles_from_data=True)
        chart.set_categories(labels)
        ws.add_chart(chart, pos)

    estados = {}
    for p in proyectos:
        if p.estado_pro:
            estados[p.estado_pro] = estados.get(p.estado_pro, 0) + 1

    if estados:
        chart = PieChart()
        chart.title = "Estados de los Proyectos"
        crear_tabla_resumen("RESUMEN DE ESTADOS", estados, chart, "N55")

    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response["Content-Disposition"] = 'attachment; filename="reporte_proyectos.xlsx"'
    wb.save(response)
    return response

def reporte_entregables(request):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Entregables"

    crear_encabezado_reporte(ws, request)

    thin_border = Border(
        left=Side(style="thin", color="090979"),
        right=Side(style="thin", color="090979"),
        top=Side(style="thin", color="090979"),
        bottom=Side(style="thin", color="090979")
    )

    ws.merge_cells("A7:L7")
    titulo = ws["A7"]
    titulo.value = "REPORTE GENERAL DE ENTREGABLES"
    titulo.font = Font(bold=True, size=16)
    titulo.alignment = Alignment(horizontal="center")

    fila_encabezado = 8
    encabezados = [
        "Proyecto",
        "Nombre Entregable",
        "Fecha Inicio",
        "Fecha Fin",
        "Descripción",
        "Estado",
        "Fechas de Subida"
    ]

    for col, texto in enumerate(encabezados, start=1):
        cell = ws.cell(row=fila_encabezado, column=col, value=texto)
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal="center")
        cell.border = thin_border

    entregables = Entregable.objects.all()
    fila_actual = fila_encabezado + 1
    max_archivos = 0

    for e in entregables:
        archivos = Archivo.objects.filter(entregable=e)
        max_archivos = max(max_archivos, archivos.count())

        fechas_subida = ", ".join(
            a.fecha_subida.strftime("%Y-%m-%d %H:%M") for a in archivos
        ) if archivos else ""

        ws.append([
            e.cod_pro.nom_pro,
            e.nom_entre,
            e.fecha_inicio.strftime("%Y-%m-%d") if e.fecha_inicio else "",
            e.fecha_fin.strftime("%Y-%m-%d") if e.fecha_fin else "",
            e.desc_entre,
            e.estado,
            fechas_subida
        ])

        for col in range(1, len(encabezados) + 1):
            ws.cell(row=fila_actual, column=col).border = thin_border

        col_base = len(encabezados) + 1
        for i, archivo in enumerate(archivos, start=1):
            col = col_base + i - 1
            cell = ws.cell(row=fila_actual, column=col)
            cell.value = f"Descargar archivo {i}"
            cell.hyperlink = request.build_absolute_uri(archivo.archivo.url)
            cell.style = "Hyperlink"
            cell.border = thin_border

        fila_actual += 1

    fila_fin = fila_actual - 1

    for i in range(1, max_archivos + 1):
        col = len(encabezados) + i
        cell = ws.cell(row=fila_encabezado, column=col, value=f"Archivo {i}")
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal="center")
        cell.border = thin_border

    estados_count = {}
    for e in entregables:
        if e.estado:
            estados_count[e.estado] = estados_count.get(e.estado, 0) + 1

    if estados_count:
        fila_titulo = ws.max_row + 3
        ws.merge_cells(start_row=fila_titulo, start_column=1, end_row=fila_titulo, end_column=2)
        t = ws.cell(row=fila_titulo, column=1)
        t.value = "RESUMEN DE ESTADOS"
        t.font = Font(bold=True)
        t.alignment = Alignment(horizontal="center")

        fila_tabla = fila_titulo + 1
        ws.cell(row=fila_tabla, column=1, value="Estado").font = Font(bold=True)
        ws.cell(row=fila_tabla, column=2, value="Cantidad").font = Font(bold=True)

        fila = fila_tabla
        for estado, cantidad in estados_count.items():
            fila += 1
            ws.append([estado, cantidad])

        for r in ws.iter_rows(min_row=fila_tabla, max_row=fila, min_col=1, max_col=2):
            for c in r:
                c.border = thin_border

        data = Reference(ws, min_col=2, min_row=fila_tabla, max_row=fila)
        labels = Reference(ws, min_col=1, min_row=fila_tabla + 1, max_row=fila)
        chart_estado = PieChart()
        chart_estado.title = "Estados de los Entregables"
        chart_estado.add_data(data, titles_from_data=True)
        chart_estado.set_categories(labels)
        ws.add_chart(chart_estado, "L9")

    proyectos_count = {}
    for e in entregables:
        nom = e.cod_pro.nom_pro
        proyectos_count[nom] = proyectos_count.get(nom, 0) + 1

    if proyectos_count:
        fila_titulo = ws.max_row + 3
        ws.merge_cells(start_row=fila_titulo, start_column=1, end_row=fila_titulo, end_column=2)
        t = ws.cell(row=fila_titulo, column=1)
        t.value = "RESUMEN DE ENTREGABLES POR PROYECTO"
        t.font = Font(bold=True)
        t.alignment = Alignment(horizontal="center")

        fila_tabla = fila_titulo + 1
        ws.cell(row=fila_tabla, column=1, value="Proyecto").font = Font(bold=True)
        ws.cell(row=fila_tabla, column=2, value="Cantidad").font = Font(bold=True)

        fila = fila_tabla
        for proyecto, cantidad in proyectos_count.items():
            fila += 1
            ws.append([proyecto, cantidad])

        for r in ws.iter_rows(min_row=fila_tabla, max_row=fila, min_col=1, max_col=2):
            for c in r:
                c.border = thin_border

        data = Reference(ws, min_col=2, min_row=fila_tabla, max_row=fila)
        labels = Reference(ws, min_col=1, min_row=fila_tabla + 1, max_row=fila)
        chart_proyectos = BarChart()
        chart_proyectos.title = "Entregables por Proyecto"
        chart_proyectos.y_axis.title = "Cantidad"
        chart_proyectos.x_axis.title = "Proyectos"
        chart_proyectos.add_data(data, titles_from_data=True)
        chart_proyectos.set_categories(labels)
        ws.add_chart(chart_proyectos, "L25")

    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response["Content-Disposition"] = 'attachment; filename="reporte_entregables.xlsx"'
    wb.save(response)
    return response

def reporte_participantes(request):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Participantes"

    crear_encabezado_reporte(ws, request)
    
    thin_border = Border(
        left=Side(style="thin", color="090979"),
        right=Side(style="thin", color="090979"),
        top=Side(style="thin", color="090979"),
        bottom=Side(style="thin", color="090979")
    )

    ws.merge_cells("A7:G7")
    titulo = ws["A7"]
    titulo.value = "REPORTE GENERAL DE PARTICIPANTES"
    titulo.font = Font(bold=True, size=16)
    titulo.alignment = Alignment(horizontal="center")

    fila_encabezado = 8
    encabezados = [
        "Nombre",
        "Rol",
        "Proyecto",
        "Semillero",
        "Correo Personal",
        "Correo Institucional",
        "Estado"
    ]
    for col, texto in enumerate(encabezados, start=1):
        cell = ws.cell(row=fila_encabezado, column=col, value=texto)
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal="center")
        cell.border = thin_border

    fila_actual = fila_encabezado + 1

    aprendices = Aprendiz.objects.all()
    for a in aprendices:
        semillero_nombre = a.id_sem.nombre if a.id_sem else "Sin semillero"
        proyectos_apre = ProyectoAprendiz.objects.filter(cedula_apre=a)
        if not proyectos_apre.exists():
            fila = [
                f"{a.nombre} {a.apellido}",
                "Aprendiz",
                "Sin proyecto",
                semillero_nombre,
                a.correo_per,
                a.correo_ins,
                a.estado_apre
            ]
            ws.append(fila)
        else:
            for pa in proyectos_apre:
                fila = [
                    f"{a.nombre} {a.apellido}",
                    "Aprendiz",
                    pa.cod_pro.nom_pro,
                    semillero_nombre,
                    a.correo_per,
                    a.correo_ins,
                    a.estado_apre
                ]
                ws.append(fila)


    usuarios = Usuario.objects.filter(rol__in=["Instructor", "Investigador"])
    for u in usuarios:
        proyectos_usuario = UsuarioProyecto.objects.filter(cedula=u, estado="activo")
        semilleros_usuario = SemilleroUsuario.objects.filter(cedula=u)
        semillero_nombre = ", ".join([s.id_sem.nombre for s in semilleros_usuario]) if semilleros_usuario else "Sin semillero"

        if not proyectos_usuario.exists():
            fila = [
                f"{u.nom_usu} {u.ape_usu}",
                u.rol,
                "Sin proyecto",
                semillero_nombre,
                u.correo_per,
                u.correo_ins,
                u.estado or ""
            ]
            ws.append(fila)
        else:
            for up in proyectos_usuario:
                fila = [
                    f"{u.nom_usu} {u.ape_usu}",
                    u.rol,
                    up.cod_pro.nom_pro,
                    semillero_nombre,
                    u.correo_per,
                    u.correo_ins,
                    u.estado or ""
                ]
                ws.append(fila)

    for row in ws.iter_rows(min_row=fila_encabezado, max_row=ws.max_row, min_col=1, max_col=len(encabezados)):
        for cell in row:
            cell.border = thin_border

    roles_count = {}
    for row in ws.iter_rows(min_row=fila_encabezado + 1, max_row=ws.max_row, min_col=2, max_col=2, values_only=True):
        rol = row[0]
        roles_count[rol] = roles_count.get(rol, 0) + 1

    if roles_count:
        fila_titulo = ws.max_row + 2
        ws.merge_cells(start_row=fila_titulo, start_column=1, end_row=fila_titulo, end_column=2)
        t = ws.cell(row=fila_titulo, column=1)
        t.value = "RESUMEN DE PARTICIPANTES POR ROL"
        t.font = Font(bold=True)
        t.alignment = Alignment(horizontal="center")

        fila_tabla = fila_titulo + 1
        ws.cell(row=fila_tabla, column=1, value="Rol").font = Font(bold=True)
        ws.cell(row=fila_tabla, column=2, value="Cantidad").font = Font(bold=True)

        fila = fila_tabla
        for rol, cantidad in roles_count.items():
            fila += 1
            ws.append([rol, cantidad])

        for row_cells in ws.iter_rows(min_row=fila_tabla, max_row=fila, min_col=1, max_col=2):
            for cell in row_cells:
                cell.border = thin_border

        data = Reference(ws, min_col=2, min_row=fila_tabla, max_row=fila)
        labels = Reference(ws, min_col=1, min_row=fila_tabla + 1, max_row=fila)
        chart_roles = PieChart()
        chart_roles.title = "Participantes por Rol"
        chart_roles.add_data(data, titles_from_data=True)
        chart_roles.set_categories(labels)
        ws.add_chart(chart_roles, "I2")


    proyectos_count = {}
    for row in ws.iter_rows(min_row=fila_encabezado + 1, max_row=ws.max_row, min_col=3, max_col=3, values_only=True):
        proyecto = row[0] or "Sin proyecto"
        proyectos_count[proyecto] = proyectos_count.get(proyecto, 0) + 1

    if proyectos_count:
        fila_titulo = ws.max_row + 2
        ws.merge_cells(start_row=fila_titulo, start_column=1, end_row=fila_titulo, end_column=2)
        t = ws.cell(row=fila_titulo, column=1)
        t.value = "RESUMEN DE PARTICIPANTES POR PROYECTO"
        t.font = Font(bold=True)
        t.alignment = Alignment(horizontal="center")

        fila_tabla = fila_titulo + 1
        ws.cell(row=fila_tabla, column=1, value="Proyecto").font = Font(bold=True)
        ws.cell(row=fila_tabla, column=2, value="Cantidad").font = Font(bold=True)

        fila = fila_tabla
        for proyecto, cantidad in proyectos_count.items():
            fila += 1
            ws.append([proyecto, cantidad])

        for row_cells in ws.iter_rows(min_row=fila_tabla, max_row=fila, min_col=1, max_col=2):
            for cell in row_cells:
                cell.border = thin_border

        data = Reference(ws, min_col=2, min_row=fila_tabla, max_row=fila)
        labels = Reference(ws, min_col=1, min_row=fila_tabla + 1, max_row=fila)
        chart_proyectos = BarChart()
        chart_proyectos.title = "Participantes por Proyecto"
        chart_proyectos.y_axis.title = "Cantidad"
        chart_proyectos.x_axis.title = "Proyectos"
        chart_proyectos.add_data(data, titles_from_data=True)
        chart_proyectos.set_categories(labels)
        ws.add_chart(chart_proyectos, "I20")

    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response["Content-Disposition"] = 'attachment; filename="reporte_participantes.xlsx"'
    wb.save(response)
    return response

def crear_encabezado_reporte(ws, request):

    thin_border = Border(
        left=Side(style="thin", color="090979"),
        right=Side(style="thin", color="090979"),
        top=Side(style="thin", color="090979"),
        bottom=Side(style="thin", color="090979")
    )

    try:
        posibles_rutas = [
            os.path.join(settings.BASE_DIR, 'static', 'img', 'logo_gc.png'),
            os.path.join(settings.STATIC_ROOT, 'img', 'logo_gc.png') if getattr(settings, 'STATIC_ROOT', None) else None,
            os.path.join(settings.BASE_DIR, 'staticfiles', 'img', 'logo_gc.png'),
        ]

        logo_path = next((r for r in posibles_rutas if r and os.path.exists(r)), None)

        ws.merge_cells("A1:A4")

        for row in ws.iter_rows(min_row=1, max_row=4, min_col=1, max_col=1):
            for cell in row:
                cell.border = thin_border

        if logo_path:
            logo = XLImage(logo_path)
            logo.width = 120
            logo.height = 100
            ws.add_image(logo, "A1")

            ws["A1"] = "Powered by InnHub"
            ws["A1"].alignment = Alignment(horizontal="center", vertical="bottom")
            ws["A1"].font = Font(size=9, italic=True, color="777777")

    except:
        pass

    info = [
        ("Creado por:", f"{request.user.nom_usu} {request.user.ape_usu}"),
        ("Fecha y hora de generación:", timezone.now().strftime('%Y-%m-%d %H:%M')),
    ]

    fila = 1
    for titulo, valor in info:

        ws.merge_cells(start_row=fila, start_column=2, end_row=fila, end_column=5)
        c = ws.cell(row=fila, column=2, value=titulo)
        c.font = Font(bold=True, size=11, name="Calibri")
        c.alignment = Alignment(vertical="center", horizontal="left", indent=1)
        c.fill = PatternFill(start_color="D9E9F7", end_color="D9E9F7", fill_type="solid")

        for row in ws.iter_rows(min_row=fila, max_row=fila, min_col=2, max_col=5):
            for cell in row:
                cell.border = thin_border

        ws.merge_cells(start_row=fila + 1, start_column=2, end_row=fila + 1, end_column=5)
        c = ws.cell(row=fila + 1, column=2, value=valor)
        c.font = Font(size=11, name="Calibri")
        c.alignment = Alignment(vertical="center", horizontal="left", indent=1)

        for row in ws.iter_rows(min_row=fila + 1, max_row=fila + 1, min_col=2, max_col=5):
            for cell in row:
                cell.border = thin_border

        fila += 2

    ws.column_dimensions['A'].width = 20
    for col in ['B', 'C', 'D', 'E']:
        ws.column_dimensions[col].width = 12

    for i in range(1, 5):
        ws.row_dimensions[i].height = 22

def generar_reporte_excel(request):
    if request.method != "POST":
        return redirect("constructor_reportes")

    nombre_archivo = request.POST.get("nombre_plantilla", "").strip()
    if not nombre_archivo:
        nombre_archivo = "reporte_personalizado"

    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response["Content-Disposition"] = f'attachment; filename="{nombre_archivo}.xlsx"'

    categorias = request.POST.getlist("categoria")

    if not categorias:
        messages.error(request, "Debes seleccionar al menos una categoría.")
        return redirect("constructor_reportes")

    campos = {
        "semilleros": request.POST.getlist("campo_semilleros"),
        "proyectos": request.POST.getlist("campo_proyectos"),
        "miembros": request.POST.getlist("campo_miembros"),
        "entregables": request.POST.getlist("campo_entregables"),
    }

    wb = Workbook()
    hoja_default = wb.active
    wb.remove(hoja_default)

    thin_border = Border(
        left=Side(style="thin", color="090979"),
        right=Side(style="thin", color="090979"),
        top=Side(style="thin", color="090979"),
        bottom=Side(style="thin", color="090979")
    )

    if "semilleros" in categorias:
        ws = wb.create_sheet("Semilleros")

        crear_encabezado_reporte(ws, request)

        fila_titulo = 7
        ws.cell(row=fila_titulo, column=1, value="SEMILLEROS").font = Font(bold=True)

        fila_encabezado = 8
        for col_idx, campo in enumerate(campos["semilleros"], start=1):
            cell = ws.cell(row=fila_encabezado, column=col_idx, value=campo)
            cell.font = Font(bold=True)
        
        semilleros = Semillero.objects.all()
        fila_inicio_datos = 9

        for s in semilleros:
            fila = []
            for campo in campos["semilleros"]:
                match campo:
                    case "Código de Semillero": 
                        fila.append(s.cod_sem)
                    case "Nombre del Semillero": 
                        fila.append(s.nombre)
                    case "Siglas": 
                        fila.append(s.sigla)
                    case "Descripción": 
                        fila.append(s.desc_sem)
                    case "Progreso": 
                        fila.append(s.progreso_sem)
                    case "Objetivos": 
                        objetivos = s.objetivo.replace('\n', ', ') if s.objetivo else "Sin objetivos"
                        fila.append(objetivos)
                    case "Líder de Semillero":
                        lider = SemilleroUsuario.objects.filter(id_sem=s, es_lider=True).first()
                        fila.append(lider.cedula.nom_usu if lider else "Sin líder")
                    case "Fecha de Creación": 
                        fila.append(s.fecha_creacion.strftime("%Y-%m-%d"))
                    case "Estado Actual": 
                        fila.append(s.estado)
                    case "Número de Integrantes":
                        usuarios_sem = SemilleroUsuario.objects.filter(id_sem=s).select_related('cedula')
                        aprendices_sem = Aprendiz.objects.filter(id_sem=s)
                        roles_count = {}
                        for u_rel in usuarios_sem:
                            rol = u_rel.cedula.rol
                            roles_count[rol] = roles_count.get(rol, 0) + 1
                        cant_aprendices = aprendices_sem.count()
                        if cant_aprendices > 0:
                            roles_count['Aprendiz'] = cant_aprendices
                        total = sum(roles_count.values())
                        fila.append(total)
                    case "Cantidad de Proyectos": 
                        fila.append(s.proyectos.count())
                        
            ws.append(fila)

        fila_fin = ws.max_row
        for row in ws.iter_rows(min_row=fila_encabezado, max_row=fila_fin, 
                                min_col=1, max_col=len(campos["semilleros"])):
            for cell in row:
                cell.border = thin_border

        if "Número de Integrantes" in campos["semilleros"]:
            col_inicio_roles = len(campos["semilleros"]) + 2
            
            ws.cell(row=fila_encabezado, column=col_inicio_roles, value="Rol").font = Font(bold=True)
            ws.cell(row=fila_encabezado, column=col_inicio_roles + 1, value="Cantidad por Rol").font = Font(bold=True)
            
            todos_roles = {}
            for s in semilleros:
                usuarios_sem = SemilleroUsuario.objects.filter(id_sem=s).select_related('cedula')
                aprendices_sem = Aprendiz.objects.filter(id_sem=s)
                
                for u_rel in usuarios_sem:
                    rol = u_rel.cedula.rol
                    todos_roles[rol] = todos_roles.get(rol, 0) + 1
                
                cant_aprendices = aprendices_sem.count()
                if cant_aprendices > 0:
                    todos_roles['Aprendiz'] = todos_roles.get('Aprendiz', 0) + cant_aprendices
            
            fila_actual = fila_inicio_datos
            for rol, cantidad in todos_roles.items():
                ws.cell(row=fila_actual, column=col_inicio_roles, value=rol)
                ws.cell(row=fila_actual, column=col_inicio_roles + 1, value=cantidad)
                fila_actual += 1
            
            for row in ws.iter_rows(min_row=fila_encabezado, max_row=fila_actual - 1, 
                                    min_col=col_inicio_roles, max_col=col_inicio_roles + 1):
                for cell in row:
                    cell.border = thin_border

        if "Cantidad de Proyectos" in campos["semilleros"]:
            col_proyectos = campos["semilleros"].index("Cantidad de Proyectos") + 1
            col_nombre = campos["semilleros"].index("Nombre del Semillero") + 1 if "Nombre del Semillero" in campos["semilleros"] else 1
            
            col_inicio_tabla_proy = len(campos["semilleros"]) + 8
            
            ws.cell(row=fila_encabezado, column=col_inicio_tabla_proy, value="Semillero").font = Font(bold=True)
            ws.cell(row=fila_encabezado, column=col_inicio_tabla_proy + 1, value="Cantidad de Proyectos").font = Font(bold=True)
            
            fila_actual = fila_inicio_datos
            
            for row in ws.iter_rows(min_row=fila_inicio_datos, max_row=fila_fin, 
                                min_col=col_nombre, max_col=col_nombre, values_only=True):
                nombre_sem = row[0]
                cant_proyectos = ws.cell(row=fila_actual, column=col_proyectos).value
                
                ws.cell(row=fila_actual, column=col_inicio_tabla_proy, value=nombre_sem)
                ws.cell(row=fila_actual, column=col_inicio_tabla_proy + 1, value=cant_proyectos)
                fila_actual += 1
            
            for row in ws.iter_rows(min_row=fila_encabezado, max_row=fila_actual - 1, 
                                min_col=col_inicio_tabla_proy, max_col=col_inicio_tabla_proy + 1):
                for cell in row:
                    cell.border = thin_border
            
            chart_proy = BarChart()
            chart_proy.title = "Cantidad de Proyectos por Semillero"
            chart_proy.y_axis.title = "Número de Proyectos"
            chart_proy.x_axis.title = "Semilleros"
            
            data = Reference(ws, min_col=col_inicio_tabla_proy + 1, min_row=fila_encabezado, max_row=fila_actual - 1)
            labels = Reference(ws, min_col=col_inicio_tabla_proy, min_row=fila_inicio_datos, max_row=fila_actual - 1)
            
            chart_proy.add_data(data, titles_from_data=True)
            chart_proy.set_categories(labels)
            chart_proy.height = 15
            chart_proy.width = 20
            
            ws.add_chart(chart_proy, "N56")

        if "Progreso" in campos["semilleros"]:
            col_progreso = campos["semilleros"].index("Progreso") + 1
            col_nombre = campos["semilleros"].index("Nombre del Semillero") + 1 if "Nombre del Semillero" in campos["semilleros"] else 1
            
            col_inicio_tabla_prog = len(campos["semilleros"]) + 11
            
            ws.cell(row=fila_encabezado, column=col_inicio_tabla_prog, value="Semillero").font = Font(bold=True)
            ws.cell(row=fila_encabezado, column=col_inicio_tabla_prog + 1, value="Progreso (%)").font = Font(bold=True)
            
            fila_actual = fila_inicio_datos
            
            for row_idx in range(fila_inicio_datos, fila_fin + 1):
                nombre_sem = ws.cell(row=row_idx, column=col_nombre).value
                progreso = ws.cell(row=row_idx, column=col_progreso).value
                
                if progreso is None or progreso == "":
                    progreso = 0
                else:
                    try:
                        progreso = float(progreso)
                    except:
                        progreso = 0
                
                ws.cell(row=fila_actual, column=col_inicio_tabla_prog, value=nombre_sem)
                ws.cell(row=fila_actual, column=col_inicio_tabla_prog + 1, value=progreso)
                fila_actual += 1
            
            for row in ws.iter_rows(min_row=fila_encabezado, max_row=fila_actual - 1, 
                                min_col=col_inicio_tabla_prog, max_col=col_inicio_tabla_prog + 1):
                for cell in row:
                    cell.border = thin_border
            
            chart_prog = BarChart()
            chart_prog.title = "Progreso de Semilleros"
            chart_prog.y_axis.title = "Progreso (%)"
            chart_prog.x_axis.title = "Semilleros"
            
            data = Reference(ws, min_col=col_inicio_tabla_prog + 1, min_row=fila_encabezado, max_row=fila_actual - 7)
            labels = Reference(ws, min_col=col_inicio_tabla_prog, min_row=fila_inicio_datos, max_row=fila_actual - 8)
            
            chart_prog.add_data(data, titles_from_data=True)
            chart_prog.set_categories(labels)
            chart_prog.height = 15
            chart_prog.width = 20
            
            ws.add_chart(chart_prog, "N74")

        if "Estado Actual" in campos["semilleros"]:
            try:
                col_estado = campos["semilleros"].index("Estado Actual") + 1
                
                estados = {}
                for row in ws.iter_rows(min_row=fila_inicio_datos, max_row=ws.max_row, min_col=col_estado, max_col=col_estado, values_only=True):
                    estado = row[0]
                    if estado:
                        estados[estado] = estados.get(estado, 0) + 1
                
                if estados:
                    col_inicio_estados = len(campos["semilleros"]) + 5
                    
                    ws.cell(row=fila_encabezado, column=col_inicio_estados, value="Estado").font = Font(bold=True)
                    ws.cell(row=fila_encabezado, column=col_inicio_estados + 1, value="Cantidad por Estado").font = Font(bold=True)
                    
                    fila_actual = fila_inicio_datos
                    for estado, cantidad in estados.items():
                        ws.cell(row=fila_actual, column=col_inicio_estados, value=estado)
                        ws.cell(row=fila_actual, column=col_inicio_estados + 1, value=cantidad)
                        fila_actual += 1
                    
                    for row in ws.iter_rows(min_row=fila_encabezado, max_row=fila_actual - 1, 
                                            min_col=col_inicio_estados, max_col=col_inicio_estados + 1):
                        for cell in row:
                            cell.border = thin_border
                    
                    chart = PieChart()
                    chart.title = "Distribución por Estado"
                    
                    data = Reference(ws, min_col=col_inicio_estados + 1, min_row=fila_encabezado, max_row=fila_actual - 1)
                    labels = Reference(ws, min_col=col_inicio_estados, min_row=fila_inicio_datos, max_row=fila_actual - 1)
                    
                    chart.add_data(data, titles_from_data=True)
                    chart.set_categories(labels)
                    chart.height = 10
                    chart.width = 15
                    
                    ws.add_chart(chart, "N20")
            except ValueError:
                pass

        if "Número de Integrantes" in campos["semilleros"]:
            try:
                col_inicio_roles = len(campos["semilleros"]) + 2
                
                ultima_fila_desglose = fila_encabezado
                for row in ws.iter_rows(min_row=fila_inicio_datos, min_col=col_inicio_roles, max_col=col_inicio_roles, values_only=True):
                    if row[0]:
                        ultima_fila_desglose += 1
                
                if ultima_fila_desglose > fila_encabezado:
                    chart = PieChart()
                    chart.title = "Distribución de Integrantes por Rol"
                    
                    data = Reference(ws, min_col=col_inicio_roles + 1, min_row=fila_encabezado, max_row=ultima_fila_desglose)
                    labels = Reference(ws, min_col=col_inicio_roles, min_row=fila_inicio_datos, max_row=ultima_fila_desglose)
                    
                    chart.add_data(data, titles_from_data=True)
                    chart.set_categories(labels)
                    chart.height = 10
                    chart.width = 15
                    
                    ws.add_chart(chart, "N38")
            except ValueError:
                pass

    if "proyectos" in categorias:
        ws = wb.create_sheet("Proyectos")
        crear_encabezado_reporte(ws, request)

        fila_titulo = 7
        ws.cell(row=fila_titulo, column=1, value="PROYECTOS").font = Font(bold=True)
        
        fila_encabezado = 8
        num_cols = len(campos["proyectos"])
        for col_idx, campo in enumerate(campos["proyectos"], start=1):
            cell = ws.cell(row=fila_encabezado, column=col_idx, value=campo)
            cell.font = Font(bold=True)

        proyectos = list(Proyecto.objects.all())
        fila_inicio_datos = 9

        for p_idx, p in enumerate(proyectos):
            fila_vals = [""] * num_cols

            for i, campo in enumerate(campos["proyectos"]):
                match campo:
                    case "Título del Proyecto":
                        fila_vals[i] = p.nom_pro or ""
                    case "Tipo de Proyecto":
                        fila_vals[i] = p.tipo or ""
                    case "Estado":
                        fila_vals[i] = p.estado_pro or ""
                    case "Fecha de Creación":
                        fila_vals[i] = p.fecha_creacion.strftime("%Y-%m-%d") if getattr(p, "fecha_creacion", None) else ""
                    case "Porcentaje de Avance":
                        fila_vals[i] = p.progreso if p.progreso is not None else ""
                    case "Lider":
                        lider = UsuarioProyecto.objects.filter(cod_pro=p, es_lider_pro=True).select_related('cedula').first()
                        fila_vals[i] = lider.cedula.nom_usu if lider else "Sin líder"
                    case "Línea Tecnológica":
                        if getattr(p, "linea_tec", None):
                            lista = [s.strip() for s in p.linea_tec.splitlines() if s.strip()]
                            fila_vals[i] = ", ".join(lista)
                        else:
                            fila_vals[i] = ""
                    case "Línea de Investigación":
                        if getattr(p, "linea_inv", None):
                            lista = [s.strip() for s in p.linea_inv.splitlines() if s.strip()]
                            fila_vals[i] = ", ".join(lista)
                        else:
                            fila_vals[i] = ""
                    case "Línea de Semillero":
                        if getattr(p, "linea_sem", None):
                            lista = [s.strip() for s in p.linea_sem.splitlines() if s.strip()]
                            fila_vals[i] = ", ".join(lista)
                        else:
                            fila_vals[i] = ""
                    case "Participantes De Proyecto":
                        usuarios_pro = UsuarioProyecto.objects.filter(cod_pro=p).select_related('cedula')
                        aprendices_pro = ProyectoAprendiz.objects.filter(cod_pro=p)
                        fila_vals[i] = usuarios_pro.count() + aprendices_pro.count()
                    case "Notas":
                        fila_vals[i] = ", ".join([s.strip() for s in p.notas.splitlines() if s.strip()]) if getattr(p, "notas", None) else ""
                    case "Programa de Formación":
                        fila_vals[i] = p.programa_formacion if getattr(p, "programa_formacion", None) else ""

            ws.append(fila_vals)

        fila_fin = ws.max_row
        for row in ws.iter_rows(min_row=fila_encabezado, max_row=fila_fin,
                                min_col=1, max_col=len(campos["proyectos"])):
            for cell in row:
                cell.border = thin_border

        if "Participantes De Proyecto" in campos["proyectos"]:

            col_inicio = len(campos["proyectos"]) + 2

            ws.cell(row=fila_encabezado, column=col_inicio, value="Rol").font = Font(bold=True)
            ws.cell(row=fila_encabezado, column=col_inicio + 1, value="Cantidad").font = Font(bold=True)

            roles_count = {}

            for p in proyectos:
                usuarios = UsuarioProyecto.objects.filter(cod_pro=p).select_related('cedula')
                aprendices = ProyectoAprendiz.objects.filter(cod_pro=p)

                for rel in usuarios:
                    rol = rel.cedula.rol
                    roles_count[rol] = roles_count.get(rol, 0) + 1

                count_apre = aprendices.count()
                if count_apre > 0:
                    roles_count["Aprendiz"] = roles_count.get("Aprendiz", 0) + count_apre

            fila_actual = fila_inicio_datos
            for rol, cant in roles_count.items():
                ws.cell(row=fila_actual, column=col_inicio, value=rol)
                ws.cell(row=fila_actual, column=col_inicio + 1, value=cant)
                fila_actual += 1
            
            for row in ws.iter_rows(min_row=fila_encabezado, max_row=fila_actual - 1, 
                                    min_col=col_inicio, max_col=col_inicio + 1):
                for cell in row:
                    cell.border = thin_border

            chart = PieChart()
            chart.title = "Participantes por Rol"

            data = Reference(ws, min_col=col_inicio + 1, min_row=fila_encabezado, max_row=fila_actual - 1)
            labels = Reference(ws, min_col=col_inicio, min_row=fila_inicio_datos, max_row=fila_actual - 1)

            chart.add_data(data, titles_from_data=True)
            chart.set_categories(labels)
            chart.height = 10
            chart.width = 15

            ws.add_chart(chart, "N2")
            
        if "Tipo de Proyecto" in campos["proyectos"]:

            col_inicio = len(campos["proyectos"]) + 8
            ws.cell(row=fila_encabezado, column=col_inicio, value="Tipo").font = Font(bold=True)
            ws.cell(row=fila_encabezado, column=col_inicio + 1, value="Cantidad").font = Font(bold=True)

            tipos = {}

            for p in proyectos:
                if p.tipo:
                    tipos[p.tipo] = tipos.get(p.tipo, 0) + 1

            fila_actual = fila_inicio_datos
            for tipo, cantidad in tipos.items():
                ws.cell(row=fila_actual, column=col_inicio, value=tipo)
                ws.cell(row=fila_actual, column=col_inicio + 1, value=cantidad)
                fila_actual += 1
            
            for row in ws.iter_rows(min_row=fila_encabezado, max_row=fila_actual - 1, 
                                    min_col=col_inicio, max_col=col_inicio + 1):
                for cell in row:
                    cell.border = thin_border

            chart = PieChart()
            chart.title = "Proyectos por Tipo"
            data = Reference(ws, min_col=col_inicio + 1, min_row=fila_encabezado, max_row=fila_actual - 1)
            labels = Reference(ws, min_col=col_inicio, min_row=fila_inicio_datos, max_row=fila_actual - 1)

            chart.add_data(data, titles_from_data=True)
            chart.set_categories(labels)
            chart.height = 10
            chart.width = 15

            ws.add_chart(chart, "N38")

        if "Porcentaje de Avance" in campos["proyectos"]:
            col_avance = campos["proyectos"].index("Porcentaje de Avance") + 1
            col_nombre = campos["proyectos"].index("Título del Proyecto") + 1 if "Título del Proyecto" in campos["proyectos"] else 1
      
            col_inicio = len(campos["proyectos"]) + 11

            ws.cell(row=fila_encabezado, column=col_inicio, value="Proyecto").font = Font(bold=True)
            ws.cell(row=fila_encabezado, column=col_inicio + 1, value="Avance (%)").font = Font(bold=True)

            fila_actual = fila_inicio_datos

            for row_idx in range(fila_inicio_datos, fila_fin + 1):
                nombre_pro = ws.cell(row=row_idx, column=col_nombre).value
                avance = ws.cell(row=row_idx, column=col_avance).value
                
                if avance is None or avance == "":
                    avance = 0
                else:
                    try:
                        avance = float(avance)
                    except:
                        avance = 0
                
                ws.cell(row=fila_actual, column=col_inicio, value=nombre_pro)
                ws.cell(row=fila_actual, column=col_inicio + 1, value=avance)
                fila_actual += 1

            for row in ws.iter_rows(
                min_row=fila_encabezado,
                max_row=fila_actual - 1,
                min_col=col_inicio,
                max_col=col_inicio + 1
            ):
                for cell in row:
                    cell.border = thin_border

            data = Reference(ws, min_col=col_inicio + 1, min_row=fila_encabezado, max_row=fila_actual - 1)
            labels = Reference(ws, min_col=col_inicio, min_row=fila_inicio_datos, max_row=fila_actual - 1)

            chart = BarChart()
            chart.title = "Porcentaje de Avance por Proyecto"
            chart.y_axis.title = "Avance (%)"
            chart.x_axis.title = "Proyectos"
            
            chart.add_data(data, titles_from_data=True)
            chart.set_categories(labels)
            chart.height = 15
            chart.width = 20

            ws.add_chart(chart, "N56")
            
        if "Línea Tecnológica" in campos["proyectos"]:

            col_inicio = len(campos["proyectos"]) + 14
            ws.cell(row=fila_encabezado, column=col_inicio, value="Línea Tec.").font = Font(bold=True)
            ws.cell(row=fila_encabezado, column=col_inicio + 1, value="Cantidad").font = Font(bold=True)

            lineas_tec = {}

            for p in proyectos:
                if p.linea_tec and p.linea_tec.strip():
                    lineas_lista = [l.strip() for l in p.linea_tec.split('\n') if l.strip()]
                    for linea in lineas_lista:
                        lineas_tec[linea] = lineas_tec.get(linea, 0) + 1

            if lineas_tec:
                fila_actual = fila_inicio_datos
                for linea, cant in lineas_tec.items():
                    ws.cell(row=fila_actual, column=col_inicio, value=linea)
                    ws.cell(row=fila_actual, column=col_inicio + 1, value=cant)
                    fila_actual += 1
                
                for row in ws.iter_rows(
                    min_row=fila_encabezado, max_row=fila_actual - 1, 
                    min_col=col_inicio, max_col=col_inicio + 1
                ):
                    for cell in row:
                        cell.border = thin_border

                chart = PieChart()
                chart.title = "Proyectos por Línea Tecnológica"
                data = Reference(ws, min_col=col_inicio + 1, min_row=fila_encabezado, max_row=fila_actual - 1)
                labels = Reference(ws, min_col=col_inicio, min_row=fila_inicio_datos, max_row=fila_actual - 1)

                chart.add_data(data, titles_from_data=True)
                chart.set_categories(labels)
                chart.height = 10
                chart.width = 15

                ws.add_chart(chart, "N74")

        if "Línea de Investigación" in campos["proyectos"]:

            col_inicio = len(campos["proyectos"]) + 17
            ws.cell(row=fila_encabezado, column=col_inicio, value="Línea Inv.").font = Font(bold=True)
            ws.cell(row=fila_encabezado, column=col_inicio + 1, value="Cantidad").font = Font(bold=True)

            lineas_inv = {}

            for p in proyectos:
                if p.linea_inv and p.linea_inv.strip():
                    lineas_lista = [l.strip() for l in p.linea_inv.split('\n') if l.strip()]
                    for linea in lineas_lista:
                        lineas_inv[linea] = lineas_inv.get(linea, 0) + 1

            if lineas_inv:
                fila_actual = fila_inicio_datos
                for linea, cant in lineas_inv.items():
                    ws.cell(row=fila_actual, column=col_inicio, value=linea)
                    ws.cell(row=fila_actual, column=col_inicio + 1, value=cant)
                    fila_actual += 1
                
                for row in ws.iter_rows(
                    min_row=fila_encabezado, max_row=fila_actual - 1, 
                    min_col=col_inicio, max_col=col_inicio + 1
                ):
                    for cell in row:
                        cell.border = thin_border

                chart = PieChart()
                chart.title = "Proyectos por Línea de Investigación"
                data = Reference(ws, min_col=col_inicio + 1, min_row=fila_encabezado, max_row=fila_actual - 1)
                labels = Reference(ws, min_col=col_inicio, min_row=fila_inicio_datos, max_row=fila_actual - 1)

                chart.add_data(data, titles_from_data=True)
                chart.set_categories(labels)
                chart.height = 10
                chart.width = 15

                ws.add_chart(chart, "N92")

        if "Línea de Semillero" in campos["proyectos"]:

            col_inicio = len(campos["proyectos"]) + 20
            ws.cell(row=fila_encabezado, column=col_inicio, value="Línea Sem.").font = Font(bold=True)
            ws.cell(row=fila_encabezado, column=col_inicio + 1, value="Cantidad").font = Font(bold=True)

            lineas_sem = {}

            for p in proyectos:
                if p.linea_sem and p.linea_sem.strip():
                    lineas_lista = [l.strip() for l in p.linea_sem.split('\n') if l.strip()]
                    for linea in lineas_lista:
                        lineas_sem[linea] = lineas_sem.get(linea, 0) + 1

            if lineas_sem:
                fila_actual = fila_inicio_datos
                for linea, cant in lineas_sem.items():
                    ws.cell(row=fila_actual, column=col_inicio, value=linea)
                    ws.cell(row=fila_actual, column=col_inicio + 1, value=cant)
                    fila_actual += 1
                
                for row in ws.iter_rows(min_row=fila_encabezado, max_row=fila_actual - 1, 
                                        min_col=col_inicio, max_col=col_inicio + 1):
                    for cell in row:
                        cell.border = thin_border

                chart = PieChart()
                chart.title = "Proyectos por Línea de Semillero"
                data = Reference(ws, min_col=col_inicio + 1, min_row=fila_encabezado, max_row=fila_actual - 1)
                labels = Reference(ws, min_col=col_inicio, min_row=fila_inicio_datos, max_row=fila_actual - 1)

                chart.add_data(data, titles_from_data=True)
                chart.set_categories(labels)
                chart.height = 10
                chart.width = 15

                ws.add_chart(chart, "N110")

            if "Programa de Formación" in campos["proyectos"]:

                col_inicio = len(campos["proyectos"]) + 23

                ws.cell(row=fila_encabezado, column=col_inicio, value="Programa de Formación").font = Font(bold=True)
                ws.cell(row=fila_encabezado, column=col_inicio + 1, value="Cantidad").font = Font(bold=True)

                programas_count = {}

                for p in proyectos:
                    programa = p.programa_formacion.strip() if p.programa_formacion else "Sin programa"
                    programas_count[programa] = programas_count.get(programa, 0) + 1

                fila_actual = fila_inicio_datos
                for programa, cantidad in programas_count.items():
                    ws.cell(row=fila_actual, column=col_inicio, value=programa)
                    ws.cell(row=fila_actual, column=col_inicio + 1, value=cantidad)
                    fila_actual += 1
                
                # Bordes
                for row in ws.iter_rows(min_row=fila_encabezado, max_row=fila_actual - 1, 
                                        min_col=col_inicio, max_col=col_inicio + 1):
                    for cell in row:
                        cell.border = thin_border

                chart = PieChart()
                chart.title = "Proyectos por Programa de Formación"

                data = Reference(ws, min_col=col_inicio + 1, min_row=fila_encabezado, max_row=fila_actual - 1)
                labels = Reference(ws, min_col=col_inicio, min_row=fila_inicio_datos, max_row=fila_actual - 1)

                chart.add_data(data, titles_from_data=True)
                chart.set_categories(labels)
                chart.height = 10
                chart.width = 15

                ws.add_chart(chart, "N128")

            if "Estado" in campos["proyectos"]:
                try:
                    col_estado = campos["proyectos"].index("Estado") + 1
                    
                    estados = {}
                    for row in ws.iter_rows(min_row=fila_inicio_datos, max_row=ws.max_row, min_col=col_estado, max_col=col_estado, values_only=True):
                        estado = row[0]
                        if estado:
                            estados[estado] = estados.get(estado, 0) + 1
                    
                    if estados:
                        col_inicio_estados = len(campos["proyectos"]) + 5
                        
                        ws.cell(row=fila_encabezado, column=col_inicio_estados, value="Estado del Proyecto").font = Font(bold=True)
                        ws.cell(row=fila_encabezado, column=col_inicio_estados + 1, value="Cantidad por Estado").font = Font(bold=True)
                        
                        fila_actual = fila_inicio_datos
                        for estado, cantidad in estados.items():
                            ws.cell(row=fila_actual, column=col_inicio_estados, value=estado)
                            ws.cell(row=fila_actual, column=col_inicio_estados + 1, value=cantidad)
                            fila_actual += 1
                        
                        # Bordes
                        for row in ws.iter_rows(min_row=fila_encabezado, max_row=fila_actual - 1, 
                                                min_col=col_inicio_estados, max_col=col_inicio_estados + 1):
                            for cell in row:
                                cell.border = thin_border
                        
                        chart = PieChart()
                        chart.title = "Distribución por Estado"
                        
                        data = Reference(ws, min_col=col_inicio_estados + 1, min_row=fila_encabezado, max_row=fila_actual - 1)
                        labels = Reference(ws, min_col=col_inicio_estados, min_row=fila_inicio_datos, max_row=fila_actual - 1)
                        
                        chart.add_data(data, titles_from_data=True)
                        chart.set_categories(labels)
                        chart.height = 10
                        chart.width = 15
                        
                        ws.add_chart(chart, "N20")

                except ValueError:
                    pass
    
    if "miembros" in categorias:

        ws = wb.create_sheet("Miembros")

        crear_encabezado_reporte(ws, request)

        fila_actual = 7
        ws.cell(row=fila_actual, column=1, value="MIEMBROS").font = Font(bold=True, size=14)
        fila_actual += 1

        campos_seleccionados = campos["miembros"]

        campos_usuarios = [c for c in campos_seleccionados 
            if c not in ["Programa", "Ficha", "Modalidad", "Programa de Formación"]]
        
        if campos_usuarios:
            ws.cell(row=fila_actual, column=1, value="USUARIOS").font = Font(bold=True)
            fila_actual += 1
            
            fila_inicio_usuarios = fila_actual
            for col_idx, campo in enumerate(campos_usuarios, start=1):
                cell = ws.cell(row=fila_actual, column=col_idx, value=campo)
                cell.font = Font(bold=True)
            fila_actual += 1

            usuarios = Usuario.objects.all()

            for u in usuarios:

                if u.rol.lower() == "aprendiz":
                    continue

                fila = []
                for campo in campos_usuarios:

                    match campo:
                        case "Nombre Completo":
                            fila.append(f"{u.nom_usu} {u.ape_usu}")

                        case "Tipo de Documento":
                            fila.append("Cédula")

                        case "Documento":
                            fila.append(u.cedula)

                        case "Rol":
                            fila.append(u.rol)

                        case "Email":
                            fila.append(u.correo_ins or u.correo_per)

                        case "Teléfono":
                            fila.append(u.telefono)

                ws.append(fila)
            
            fila_fin_usuarios = ws.max_row
            for row in ws.iter_rows(min_row=fila_inicio_usuarios, max_row=fila_fin_usuarios, 
                                    min_col=1, max_col=len(campos_usuarios)):
                for cell in row:
                    cell.border = thin_border

        fila_sep = ws.max_row + 2
        ws.cell(row=fila_sep, column=1, value="APRENDICES").font = Font(bold=True)

        fila_inicio_ap = fila_sep + 1

        aprendices = Aprendiz.objects.all()

        for col_idx, campo in enumerate(campos_seleccionados, start=1):
            cell = ws.cell(row=fila_inicio_ap, column=col_idx, value=campo)
            cell.font = Font(bold=True)
        
        fila_inicio_ap_datos = fila_inicio_ap + 1

        for a in aprendices:

            fila = []

            for campo in campos_seleccionados:
                match campo:
                    case "Nombre Completo":
                        fila.append(f"{a.nombre} {a.apellido}")

                    case "Tipo de Documento":
                        fila.append(a.tipo_doc)

                    case "Documento":
                        fila.append(a.cedula_apre)

                    case "Rol":
                        fila.append("Aprendiz")

                    case "Email":
                        fila.append(a.correo_ins or a.correo_per)

                    case "Teléfono":
                        fila.append(a.telefono)

                    case "Programa" | "Programa de Formación":
                        fila.append(a.programa if hasattr(a, 'programa') else "")

                    case "Ficha":
                        fila.append(a.ficha if hasattr(a, 'ficha') else "")

                    case "Modalidad":
                        fila.append(a.modalidad if hasattr(a, 'modalidad') else "")

            ws.append(fila)

        fila_fin_aprendices = ws.max_row
        for row in ws.iter_rows(min_row=fila_inicio_ap, max_row=fila_fin_aprendices, 
                                min_col=1, max_col=len(campos_seleccionados)):
            for cell in row:
                cell.border = thin_border

        fila_inicio_graficos = fila_inicio_ap + len(aprendices) + 3
        
        desplazamiento_col = 0

        if "Rol" in campos_seleccionados:
            col_inicio_roles = len(campos_seleccionados) + 2
            
            ws.cell(row=fila_inicio_ap, column=col_inicio_roles, value="Rol").font = Font(bold=True)
            ws.cell(row=fila_inicio_ap, column=col_inicio_roles + 1, value="Cantidad").font = Font(bold=True)
            
            roles_count = {}
            usuarios = Usuario.objects.all()
            
            for u in usuarios:
                if u.rol.lower() != "aprendiz":
                    rol = u.rol
                    roles_count[rol] = roles_count.get(rol, 0) + 1
            
            cant_aprendices = aprendices.count()
            if cant_aprendices > 0:
                roles_count["Aprendiz"] = cant_aprendices
            
            fila_g = fila_inicio_ap + 1
            for rol, cant in roles_count.items():
                ws.cell(row=fila_g, column=col_inicio_roles, value=rol)
                ws.cell(row=fila_g, column=col_inicio_roles + 1, value=cant)
                fila_g += 1
            
            for row in ws.iter_rows(min_row=fila_inicio_ap, max_row=fila_g - 1, 
                                    min_col=col_inicio_roles, max_col=col_inicio_roles + 1):
                for cell in row:
                    cell.border = thin_border
            
            chart = PieChart()
            chart.title = "Distribución de Miembros por Rol"
            data = Reference(ws, min_col=col_inicio_roles + 1, min_row=fila_inicio_ap, max_row=fila_g - 1)
            labels = Reference(ws, min_col=col_inicio_roles, min_row=fila_inicio_ap + 1, max_row=fila_g - 1)
            chart.add_data(data, titles_from_data=True)
            chart.set_categories(labels)
            chart.height = 10
            chart.width = 15
            ws.add_chart(chart, f"N{fila_inicio_graficos}")
            
            desplazamiento_col = 4  

        if "Programa" in campos_seleccionados or "Programa de Formación" in campos_seleccionados:

            col_inicio = len(campos_seleccionados) + 2 + desplazamiento_col

            ws.cell(row=fila_inicio_ap, column=col_inicio, value="Programa").font = Font(bold=True)
            ws.cell(row=fila_inicio_ap, column=col_inicio + 1, value="Cantidad").font = Font(bold=True)

            programas = {}
            for a in aprendices:
                prog = (a.programa if hasattr(a, 'programa') else None) or "Sin programa"
                programas[prog] = programas.get(prog, 0) + 1

            fila_g = fila_inicio_ap + 1
            for prog, cant in programas.items():
                ws.cell(row=fila_g, column=col_inicio, value=prog)
                ws.cell(row=fila_g, column=col_inicio + 1, value=cant)
                fila_g += 1
            
            for row in ws.iter_rows(min_row=fila_inicio_ap, max_row=fila_g - 1, 
                                    min_col=col_inicio, max_col=col_inicio + 1):
                for cell in row:
                    cell.border = thin_border

            chart = PieChart()
            chart.title = "Aprendices por Programa"
            data = Reference(ws, min_col=col_inicio + 1, min_row=fila_inicio_ap, max_row=fila_g - 1)
            labels = Reference(ws, min_col=col_inicio, min_row=fila_inicio_ap + 1, max_row=fila_g - 1)
            chart.add_data(data, titles_from_data=True)
            chart.set_categories(labels)
            chart.height = 10
            chart.width = 15
            
            pos_grafico = fila_inicio_graficos + 18 if desplazamiento_col > 0 else fila_inicio_graficos
            ws.add_chart(chart, f"N{pos_grafico}")

        if "Ficha" in campos_seleccionados:

            col_inicio = len(campos_seleccionados) + 6 + desplazamiento_col

            ws.cell(row=fila_inicio_ap, column=col_inicio, value="Ficha").font = Font(bold=True)
            ws.cell(row=fila_inicio_ap, column=col_inicio + 1, value="Cantidad").font = Font(bold=True)

            fichas = {}
            for a in aprendices:
                f = (a.ficha if hasattr(a, 'ficha') else None) or "Sin ficha"
                fichas[f] = fichas.get(f, 0) + 1

            fila_g = fila_inicio_ap + 1
            for f, cant in fichas.items():
                ws.cell(row=fila_g, column=col_inicio, value=f)
                ws.cell(row=fila_g, column=col_inicio + 1, value=cant)
                fila_g += 1

            for row in ws.iter_rows(min_row=fila_inicio_ap, max_row=fila_g - 1, 
                                    min_col=col_inicio, max_col=col_inicio + 1):
                for cell in row:
                    cell.border = thin_border

            chart = PieChart()
            chart.title = "Aprendices por Ficha"
            data = Reference(ws, min_col=col_inicio + 1, min_row=fila_inicio_ap, max_row=fila_g - 1)
            labels = Reference(ws, min_col=col_inicio, min_row=fila_inicio_ap + 1, max_row=fila_g - 1)
            chart.add_data(data, titles_from_data=True)
            chart.set_categories(labels)
            chart.height = 10
            chart.width = 15
            
            # Ajustar posición según si existe tabla de roles
            pos_grafico = fila_inicio_graficos + 36 if desplazamiento_col > 0 else fila_inicio_graficos + 18
            ws.add_chart(chart, f"N{pos_grafico}")

        if "Modalidad" in campos_seleccionados:

            col_inicio = len(campos_seleccionados) + 10 + desplazamiento_col

            ws.cell(row=fila_inicio_ap, column=col_inicio, value="Modalidad").font = Font(bold=True)
            ws.cell(row=fila_inicio_ap, column=col_inicio + 1, value="Cantidad").font = Font(bold=True)

            modalidades = {}
            for a in aprendices:
                mod = (a.modalidad if hasattr(a, 'modalidad') else None) or "Sin modalidad"
                modalidades[mod] = modalidades.get(mod, 0) + 1

            fila_g = fila_inicio_ap + 1
            for mod, cant in modalidades.items():
                ws.cell(row=fila_g, column=col_inicio, value=mod)
                ws.cell(row=fila_g, column=col_inicio + 1, value=cant)
                fila_g += 1

            for row in ws.iter_rows(min_row=fila_inicio_ap, max_row=fila_g - 1, 
                                    min_col=col_inicio, max_col=col_inicio + 1):
                for cell in row:
                    cell.border = thin_border

            chart = PieChart()
            chart.title = "Aprendices por Modalidad"
            data = Reference(ws, min_col=col_inicio + 1, min_row=fila_inicio_ap, max_row=fila_g - 1)
            labels = Reference(ws, min_col=col_inicio, min_row=fila_inicio_ap + 1, max_row=fila_g - 1)
            chart.add_data(data, titles_from_data=True)
            chart.set_categories(labels)
            chart.height = 10
            chart.width = 15
            
            # Ajustar posición según si existe tabla de roles
            pos_grafico = fila_inicio_graficos + 54 if desplazamiento_col > 0 else fila_inicio_graficos + 36
            ws.add_chart(chart, f"N{pos_grafico}")

        if "Tipo de Documento" in campos_seleccionados:
            
            col_inicio = len(campos_seleccionados) + 14 + desplazamiento_col
            
            ws.cell(row=fila_inicio_ap, column=col_inicio, value="Tipo de Documento").font = Font(bold=True)
            ws.cell(row=fila_inicio_ap, column=col_inicio + 1, value="Cantidad").font = Font(bold=True)
            
            tipos_doc = {}
            
            usuarios = Usuario.objects.all()
            for u in usuarios:
                if u.rol.lower() != "aprendiz":
                    tipos_doc["Cédula"] = tipos_doc.get("Cédula", 0) + 1
           
            for a in aprendices:
                tipo = (a.tipo_doc if hasattr(a, 'tipo_doc') else None) or "Cédula"
                tipos_doc[tipo] = tipos_doc.get(tipo, 0) + 1
            
            fila_g = fila_inicio_ap + 1
            for tipo, cant in tipos_doc.items():
                ws.cell(row=fila_g, column=col_inicio, value=tipo)
                ws.cell(row=fila_g, column=col_inicio + 1, value=cant)
                fila_g += 1
            
       
            for row in ws.iter_rows(min_row=fila_inicio_ap, max_row=fila_g - 1, 
                                    min_col=col_inicio, max_col=col_inicio + 1):
                for cell in row:
                    cell.border = thin_border

            chart = PieChart()
            chart.title = "Distribución por Tipo de Documento"
            data = Reference(ws, min_col=col_inicio + 1, min_row=fila_inicio_ap, max_row=fila_g - 1)
            labels = Reference(ws, min_col=col_inicio, min_row=fila_inicio_ap + 1, max_row=fila_g - 1)
            chart.add_data(data, titles_from_data=True)
            chart.set_categories(labels)
            chart.height = 10
            chart.width = 15

            pos_grafico = fila_inicio_graficos + 72 if desplazamiento_col > 0 else fila_inicio_graficos + 54
            ws.add_chart(chart, f"N{pos_grafico}")

    if "entregables" in categorias:
        ws = wb.create_sheet("Entregables")
        crear_encabezado_reporte(ws, request)

        fila_actual = 7
        ws.cell(row=fila_actual, column=1, value="ENTREGABLES").font = Font(bold=True, size=14)
        fila_actual += 1
 
        fila_encabezado = 8
        for col_idx, campo in enumerate(campos["entregables"], start=1):
            cell = ws.cell(row=fila_encabezado, column=col_idx, value=campo)
            cell.font = Font(bold=True)

        entregables = Entregable.objects.all()
        fila_inicio_datos = 9

        for e in entregables:
            fila = []
            for campo in campos["entregables"]:
                match campo:
                    case "Nombre del Entregable":
                        fila.append(e.nom_entre)
                    case "Estado":
                        fila.append(e.estado)
                    case "Descripción":
                        fila.append(e.desc_entre) if e.desc_entre else None
                    case "Fecha de Entrega":
                        fila.append(e.fecha_fin.strftime("%Y-%m-%d") if e.fecha_fin else "")
                    case "Proyecto Asociado":
                        fila.append(e.cod_pro.nom_pro)
                    case "Responsable":
                        resp = UsuarioProyecto.objects.filter(cod_pro=e.cod_pro, es_lider_pro=True).first()
                        fila.append(resp.cedula.nom_usu if resp else "Sin responsable")
            ws.append(fila)

        fila_fin = ws.max_row
        for row in ws.iter_rows(min_row=fila_encabezado, max_row=fila_fin, 
                                min_col=1, max_col=len(campos["entregables"])):
            for cell in row:
                cell.border = thin_border

        if "Estado" in campos["entregables"]:
            try:
                col_estado = campos["entregables"].index("Estado") + 1
                
                estados = {}
                for row in ws.iter_rows(min_row=fila_inicio_datos, max_row=ws.max_row, min_col=col_estado, max_col=col_estado, values_only=True):
                    estado = row[0]
                    if estado:
                        estados[estado] = estados.get(estado, 0) + 1
                
                if estados:
                    col_inicio_grafico = len(campos["entregables"]) + 2
                    
                    ws.cell(row=fila_encabezado, column=col_inicio_grafico, value="Estado").font = Font(bold=True)
                    ws.cell(row=fila_encabezado, column=col_inicio_grafico + 1, value="Cantidad").font = Font(bold=True)
                    
                    fila_actual = fila_inicio_datos
                    for estado, cantidad in estados.items():
                        ws.cell(row=fila_actual, column=col_inicio_grafico, value=estado)
                        ws.cell(row=fila_actual, column=col_inicio_grafico + 1, value=cantidad)
                        fila_actual += 1

                    for row in ws.iter_rows(min_row=fila_encabezado, max_row=fila_actual - 1, 
                                            min_col=col_inicio_grafico, max_col=col_inicio_grafico + 1):
                        for cell in row:
                            cell.border = thin_border
                    
                    chart = PieChart()
                    chart.title = "Entregables por Estado"
                    
                    data = Reference(ws, min_col=col_inicio_grafico + 1, min_row=fila_encabezado, max_row=fila_actual - 1)
                    labels = Reference(ws, min_col=col_inicio_grafico, min_row=fila_inicio_datos, max_row=fila_actual - 1)
                    
                    chart.add_data(data, titles_from_data=True)
                    chart.set_categories(labels)
                    chart.height = 10
                    chart.width = 15
                    
                    ws.add_chart(chart, "H2")
            except ValueError:
                pass

        if "Proyecto Asociado" in campos["entregables"]:
            try:
                col_proyecto = campos["entregables"].index("Proyecto Asociado") + 1
                
                proyectos = {}
                for row in ws.iter_rows(min_row=fila_inicio_datos, max_row=ws.max_row, min_col=col_proyecto, max_col=col_proyecto, values_only=True):
                    proyecto = row[0]
                    if proyecto:
                        proyectos[proyecto] = proyectos.get(proyecto, 0) + 1
                
                if proyectos:
                    col_inicio_proyectos = len(campos["entregables"]) + 5
                    
                    ws.cell(row=fila_encabezado, column=col_inicio_proyectos, value="Proyecto").font = Font(bold=True)
                    ws.cell(row=fila_encabezado, column=col_inicio_proyectos + 1, value="Cantidad de Entregables").font = Font(bold=True)
                    
                    fila_actual = fila_inicio_datos
                    for proyecto, cantidad in proyectos.items():
                        ws.cell(row=fila_actual, column=col_inicio_proyectos, value=proyecto)
                        ws.cell(row=fila_actual, column=col_inicio_proyectos + 1, value=cantidad)
                        fila_actual += 1
                    
                    # Bordes
                    for row in ws.iter_rows(min_row=fila_encabezado, max_row=fila_actual - 1, 
                                            min_col=col_inicio_proyectos, max_col=col_inicio_proyectos + 1):
                        for cell in row:
                            cell.border = thin_border
                    
                    chart = PieChart()
                    chart.title = "Entregables por Proyecto"
                    
                    data = Reference(ws, min_col=col_inicio_proyectos + 1, min_row=fila_encabezado, max_row=fila_actual - 1)
                    labels = Reference(ws, min_col=col_inicio_proyectos, min_row=fila_inicio_datos, max_row=fila_actual - 1)
                    
                    chart.add_data(data, titles_from_data=True)
                    chart.set_categories(labels)
                    chart.height = 10
                    chart.width = 15
                    
                    ws.add_chart(chart, "H20")
            except ValueError:
                pass

    wb.save(response)
    return response

def generar_reporte_dinamico(request):
    if request.method != "POST":
        return redirect("reportes")

    formato = request.POST.get("formato", "excel")
    
    if formato == "pdf":
        return generar_reporte_pdf(request)
    else:
        return generar_reporte_excel(request)

def agregar_marca_agua_pdf(c):
    ruta = os.path.join(settings.BASE_DIR, "static", "img", "logo_gc.png")
    logo = ImageReader(ruta)

    ancho, alto = landscape(A4)

    c.saveState()
    c.setFillAlpha(0.08)

    c.translate(ancho / 2, alto / 2)

    c.drawImage(
        logo,
        -9 * cm,
        -9 * cm,
        width=18 * cm,
        height=18 * cm,
        mask='auto'
    )

    c.restoreState()

def generar_reporte_pdf(request):
    from reportlab.lib.units import inch
    from reportlab.pdfgen import canvas as pdf_canvas

    nombre_archivo = request.POST.get("nombre_plantilla", "").strip()
    if not nombre_archivo:
        nombre_archivo = "reporte_personalizado"

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{nombre_archivo}.pdf"'

    buffer = BytesIO()

    def agregar_encabezado_pie(canvas, doc):
        """
        Agrega encabezado y pie de página a cada página del PDF
        """
        canvas.saveState()

        agregar_marca_agua_pdf(canvas)
        
        width, height = landscape(A4)
        
        canvas.setStrokeColor(colors.HexColor('#2C3E50'))
        canvas.setLineWidth(3)
        canvas.line(30, height - 40, width - 30, height - 40)
        
        canvas.setFont('Helvetica-Bold', 14)
        canvas.setFillColor(colors.HexColor('#2C3E50'))
        canvas.drawString(40, height - 32, "Powered by InnHub")
        
        canvas.setFont('Helvetica', 9)
        canvas.setFillColor(colors.HexColor('#7F8C8D'))

        fecha_actual = timezone.localtime(timezone.now()).strftime("%d/%m/%Y %H:%M")
        canvas.drawRightString(
            width - 20,
            height - 22,
            f"Generado el: {fecha_actual}"
        )

        usuario = request.user

        nombre = f"{usuario.nom_usu} {usuario.ape_usu}".strip()

        nombre_final = nombre if nombre else usuario.correo_ins

        canvas.drawRightString(
            width - 30,
            height - 34,
            f"por: {nombre_final}"
        )

        canvas.setStrokeColor(colors.HexColor('#3498DB'))
        canvas.setLineWidth(1)
        canvas.line(30, height - 45, width - 30, height - 45)
       
        canvas.setStrokeColor(colors.HexColor('#3498DB'))
        canvas.setLineWidth(1)
        canvas.line(30, 35, width - 30, 35)
        
        canvas.setFont('Helvetica', 8)
        canvas.setFillColor(colors.HexColor('#7F8C8D'))
        canvas.drawString(40, 22, "Centro de Recursos Naturales Renovables La Salada - SENA")
        
        canvas.setFont('Helvetica-Bold', 9)
        canvas.setFillColor(colors.HexColor('#2C3E50'))
        page_num = canvas.getPageNumber()
        texto_pagina = f"Página {page_num}"
        canvas.drawCentredString(width / 2, 22, texto_pagina)
        
        canvas.setFont('Helvetica', 8)
        canvas.setFillColor(colors.HexColor('#7F8C8D'))
        canvas.drawRightString(width - 40, 22, "www.sena.edu.co")
        
        canvas.setStrokeColor(colors.HexColor('#2C3E50'))
        canvas.setLineWidth(2)
        canvas.line(30, 15, width - 30, 15)
        
        canvas.restoreState()
    
    doc = SimpleDocTemplate(
        buffer, 
        pagesize=landscape(A4),
        rightMargin=30, 
        leftMargin=30,
        topMargin=60,      
        bottomMargin=50,   
        title=nombre_archivo
    )
    
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=18,
        textColor=colors.HexColor('#2C3E50'),
        spaceAfter=20,
        alignment=TA_CENTER,
        fontName='Helvetica-Bold'
    )
    
    heading_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=14,
        textColor=colors.HexColor('#34495E'),
        spaceAfter=12,
        fontName='Helvetica-Bold'
    )
    
    style_header = ParagraphStyle(
        'HeaderCell',
        fontSize=9,
        textColor=colors.whitesmoke,
        fontName='Helvetica-Bold',
        alignment=TA_CENTER,
        leading=11,
        wordWrap='CJK'
    )
    
    style_celda = ParagraphStyle(
        'DataCell',
        fontSize=8,
        alignment=TA_CENTER,
        leading=10,
        wordWrap='CJK'
    )
    
    elements = []
    
    categorias = request.POST.getlist("categoria")
    
    if not categorias:
        messages.error(request, "Debes seleccionar al menos una categoría.")
        return redirect("constructor_reportes")

    campos = {
        "semilleros": request.POST.getlist("campo_semilleros"),
        "proyectos": request.POST.getlist("campo_proyectos"),
        "miembros": request.POST.getlist("campo_miembros"),
        "entregables": request.POST.getlist("campo_entregables"),
    }

    if "semilleros" in categorias:
        elements.append(Paragraph("REPORTE DE SEMILLEROS", title_style))
        elements.append(Spacer(1, 12))
        
        semilleros = Semillero.objects.all()
    
        data = [campos["semilleros"]]
        
        for s in semilleros:
            fila = []
            for campo in campos["semilleros"]:
                valor = "" 
                
                if campo == "Código de Semillero":
                    valor = str(s.cod_sem) if s.cod_sem else ""
                elif campo == "Nombre del Semillero":
                    valor = str(s.nombre) if s.nombre else ""
                elif campo == "Siglas":
                    valor = str(s.sigla) if s.sigla else ""
                elif campo == "Descripción":
                    valor = str(s.desc_sem) if s.desc_sem else ""
                elif campo == "Progreso":
                    valor = f"{s.progreso_sem}%" if s.progreso_sem is not None else "0%"
                elif campo == "Objetivos":
                    valor = s.objetivo.replace('\n', ', ') if s.objetivo else ""
                elif campo == "Líder de Semillero":
                    lider = SemilleroUsuario.objects.filter(id_sem=s, es_lider=True).first()
                    valor = lider.cedula.nom_usu if lider else ""
                elif campo == "Fecha de Creación":
                    valor = s.fecha_creacion.strftime("%Y-%m-%d") if s.fecha_creacion else ""
                elif campo == "Estado Actual":
                    valor = str(s.estado) if s.estado else ""
                elif campo == "Número de Integrantes":
                    usuarios_sem = SemilleroUsuario.objects.filter(id_sem=s).count()
                    aprendices_sem = Aprendiz.objects.filter(id_sem=s).count()
                    valor = str(usuarios_sem + aprendices_sem)
                elif campo == "Cantidad de Proyectos":
                    valor = str(s.proyectos.count())
                
                fila.append(valor)
            
            data.append(fila)
        
        for i in range(len(data)):
            for j in range(len(data[i])):
                if i == 0:
                    data[i][j] = Paragraph(str(data[i][j]), style_header)
                else: 
                    data[i][j] = Paragraph(str(data[i][j]) if data[i][j] else " ", style_celda)  # ✅ Espacio si está vacío
        
        ancho_disponible = landscape(A4)[0] - 60
        col_widths = []
        for campo in campos["semilleros"]:
            if campo in ["Código de Semillero", "Siglas", "Progreso", "Estado Actual"]:
                col_widths.append(50)
            elif campo in ["Fecha de Creación", "Número de Integrantes", "Cantidad de Proyectos"]:
                col_widths.append(70)
            elif campo in ["Nombre del Semillero", "Líder de Semillero"]:
                col_widths.append(100)
            else:
                col_widths.append(150)
        
        total_width = sum(col_widths)
        if total_width > ancho_disponible:
            factor = ancho_disponible / total_width
            col_widths = [w * factor for w in col_widths]
        
        t = Table(data, repeatRows=1, colWidths=col_widths)
        t.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#3498DB')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 9),
            ('FONTSIZE', (0, 1), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('LEFTPADDING', (0, 0), (-1, -1), 4),
            ('RIGHTPADDING', (0, 0), (-1, -1), 4),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ]))
        elements.append(t)
        elements.append(PageBreak())

    if "proyectos" in categorias:
        elements.append(Paragraph("REPORTE DE PROYECTOS", title_style))
        elements.append(Spacer(1, 12))
        
        proyectos = Proyecto.objects.all()
        data = [campos["proyectos"]]
        
        for p in proyectos:
            fila = []
            for campo in campos["proyectos"]:
                valor = ""
                
                if campo == "Título del Proyecto":
                    valor = str(p.nom_pro) if p.nom_pro else ""
                elif campo == "Tipo de Proyecto":
                    valor = str(p.tipo) if p.tipo else ""
                elif campo == "Estado":
                    valor = str(p.estado_pro) if p.estado_pro else ""
                elif campo == "Fecha de Creación":
                    valor = p.fecha_creacion.strftime("%Y-%m-%d") if hasattr(p, "fecha_creacion") and p.fecha_creacion else ""
                elif campo == "Porcentaje de Avance":
                    valor = f"{p.progreso}%" if p.progreso is not None else "0%"
                elif campo == "Lider":
                    lider = UsuarioProyecto.objects.filter(cod_pro=p, es_lider_pro=True).first()
                    valor = lider.cedula.nom_usu if lider else ""
                elif campo == "Línea Tecnológica":
                    if p.linea_tec:
                        valor = ", ".join([l.strip() for l in p.linea_tec.splitlines() if l.strip()])
                elif campo == "Línea de Investigación":
                    if p.linea_inv:
                        valor = ", ".join([l.strip() for l in p.linea_inv.splitlines() if l.strip()])
                elif campo == "Línea de Semillero":
                    if p.linea_sem:
                        valor = ", ".join([l.strip() for l in p.linea_sem.splitlines() if l.strip()])
                elif campo == "Participantes De Proyecto":
                    usuarios = UsuarioProyecto.objects.filter(cod_pro=p).count()
                    aprendices = ProyectoAprendiz.objects.filter(cod_pro=p).count()
                    valor = str(usuarios + aprendices)
                elif campo == "Programa de Formación":
                    valor = str(p.programa_formacion) if p.programa_formacion else ""
                elif campo == "Notas":
                    valor = ", ".join([s.strip() for s in p.notas.splitlines() if s.strip()]) if hasattr(p, "notas") and p.notas else ""
                
                fila.append(valor) 
            
            data.append(fila)
        
        for i in range(len(data)):
            for j in range(len(data[i])):
                if i == 0:
                    data[i][j] = Paragraph(str(data[i][j]), style_header)
                else:
                    data[i][j] = Paragraph(str(data[i][j]) if data[i][j] else " ", style_celda) 
        
        ancho_disponible = landscape(A4)[0] - 60
        col_widths = []
        for campo in campos["proyectos"]:
            if campo in ["Estado", "Porcentaje de Avance", "Participantes De Proyecto"]:
                col_widths.append(60)
            elif campo in ["Tipo de Proyecto", "Fecha de Creación"]:
                col_widths.append(80)
            elif campo in ["Título del Proyecto", "Lider", "Programa de Formación"]:
                col_widths.append(100)
            elif campo == "Notas":
                col_widths.append(150)
            else:
                col_widths.append(120)
        
        total_width = sum(col_widths)
        if total_width > ancho_disponible:
            factor = ancho_disponible / total_width
            col_widths = [w * factor for w in col_widths]
        
        t = Table(data, repeatRows=1, colWidths=col_widths)
        t.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#E74C3C')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 9),
            ('FONTSIZE', (0, 1), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('LEFTPADDING', (0, 0), (-1, -1), 4),
            ('RIGHTPADDING', (0, 0), (-1, -1), 4),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ]))
        elements.append(t)
        elements.append(PageBreak())

    if "miembros" in categorias:
        elements.append(Paragraph("REPORTE DE MIEMBROS", title_style))
        elements.append(Spacer(1, 12))
        
        # USUARIOS
        elements.append(Paragraph("Usuarios", heading_style))
        usuarios = Usuario.objects.exclude(rol__iexact="aprendiz")

        campos_usuarios = [c for c in campos["miembros"] 
            if c not in ["Programa", "Ficha", "Modalidad", "Programa de Formación"]]
        
        if campos_usuarios and usuarios.exists():
            data = [campos_usuarios]
            
            for u in usuarios:
                fila = []
                for campo in campos_usuarios:
                    valor = ""
                    
                    if campo == "Nombre Completo":
                        valor = f"{u.nom_usu or ''} {u.ape_usu or ''}".strip()
                    elif campo == "Tipo de Documento":
                        valor = "Cédula"
                    elif campo == "Documento":
                        valor = str(u.cedula) if u.cedula else ""
                    elif campo == "Rol":
                        valor = str(u.rol) if u.rol else ""
                    elif campo == "Email":
                        valor = u.correo_ins or u.correo_per or ""
                    elif campo == "Teléfono":
                        valor = str(u.telefono) if u.telefono else ""
                    
                    fila.append(valor)
                
                data.append(fila)
            
            for i in range(len(data)):
                for j in range(len(data[i])):
                    if i == 0:
                        data[i][j] = Paragraph(str(data[i][j]), style_header)
                    else:
                        data[i][j] = Paragraph(str(data[i][j]) if data[i][j] else " ", style_celda)
            
            ancho_disponible = landscape(A4)[0] - 60
            col_widths = []
            for campo in campos_usuarios:
                if campo in ["Tipo de Documento", "Documento", "Rol", "Teléfono"]:
                    col_widths.append(70)
                elif campo == "Nombre Completo":
                    col_widths.append(120)
                elif campo == "Email":
                    col_widths.append(150)
                else:
                    col_widths.append(100)  
            
            total_width = sum(col_widths)
            if total_width > ancho_disponible:
                factor = ancho_disponible / total_width
                col_widths = [w * factor for w in col_widths]
            
            t = Table(data, repeatRows=1, colWidths=col_widths)
            t.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#27AE60')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 9),
                ('FONTSIZE', (0, 1), (-1, -1), 8),
                ('TOPPADDING', (0, 0), (-1, -1), 6),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
                ('LEFTPADDING', (0, 0), (-1, -1), 4),
                ('RIGHTPADDING', (0, 0), (-1, -1), 4),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ]))
            elements.append(t)
            elements.append(Spacer(1, 20))
        
        elements.append(Paragraph("Aprendices", heading_style))
        aprendices = Aprendiz.objects.all()
        
        if campos["miembros"] and aprendices.exists(): 
            data = [campos["miembros"]]
            
            for a in aprendices:
                fila = []
                for campo in campos["miembros"]:
                    valor = ""
                    
                    if campo == "Nombre Completo":
                        valor = f"{a.nombre or ''} {a.apellido or ''}".strip()
                    elif campo == "Tipo de Documento":
                        valor = str(a.tipo_doc) if a.tipo_doc else "Cédula"
                    elif campo == "Documento":
                        valor = str(a.cedula_apre) if a.cedula_apre else ""
                    elif campo == "Rol":
                        valor = "Aprendiz"
                    elif campo == "Email":
                        valor = a.correo_ins or a.correo_per or ""
                    elif campo == "Teléfono":
                        valor = str(a.telefono) if a.telefono else ""
                    elif campo in ["Programa", "Programa de Formación"]:
                        valor = str(a.programa) if hasattr(a, 'programa') and a.programa else ""
                    elif campo == "Ficha":
                        valor = str(a.ficha) if hasattr(a, 'ficha') and a.ficha else ""
                    elif campo == "Modalidad":
                        valor = str(a.modalidad) if hasattr(a, 'modalidad') and a.modalidad else ""
                    
                    fila.append(valor)
                
                data.append(fila)
            
            for i in range(len(data)):
                for j in range(len(data[i])):
                    if i == 0:
                        data[i][j] = Paragraph(str(data[i][j]), style_header)
                    else:
                        data[i][j] = Paragraph(str(data[i][j]) if data[i][j] else " ", style_celda)
            
            ancho_disponible = landscape(A4)[0] - 60
            col_widths = []
            for campo in campos["miembros"]:
                if campo in ["Tipo de Documento", "Documento", "Rol", "Teléfono", "Ficha", "Modalidad"]:
                    col_widths.append(70)
                elif campo == "Nombre Completo":
                    col_widths.append(120)
                elif campo == "Email":
                    col_widths.append(150)
                elif campo in ["Programa", "Programa de Formación"]:
                    col_widths.append(130)
                else:
                    col_widths.append(100)  
            
            total_width = sum(col_widths)
            if total_width > ancho_disponible:
                factor = ancho_disponible / total_width
                col_widths = [w * factor for w in col_widths]
            
            t = Table(data, repeatRows=1, colWidths=col_widths)
            t.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#27AE60')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 9),
                ('FONTSIZE', (0, 1), (-1, -1), 8),
                ('TOPPADDING', (0, 0), (-1, -1), 6),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
                ('LEFTPADDING', (0, 0), (-1, -1), 4),
                ('RIGHTPADDING', (0, 0), (-1, -1), 4),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ]))
            elements.append(t)
        
        elements.append(PageBreak())

    if "entregables" in categorias:
        elements.append(Paragraph("REPORTE DE ENTREGABLES", title_style))
        elements.append(Spacer(1, 12))
        
        entregables = Entregable.objects.all()
        
        if campos["entregables"] and entregables.exists():
            data = [campos["entregables"]]
            
            for e in entregables:
                fila = []
                for campo in campos["entregables"]:
                    valor = ""
                    
                    if campo == "Nombre del Entregable":
                        valor = str(e.nom_entre) if e.nom_entre else ""
                    elif campo == "Estado":
                        valor = str(e.estado) if e.estado else ""
                    elif campo == "Descripción":
                        valor = e.desc_entre.replace('\n', ', ') if e.desc_entre else ""
                    elif campo == "Fecha de Entrega":
                        valor = e.fecha_fin.strftime("%Y-%m-%d") if e.fecha_fin else ""
                    elif campo == "Proyecto Asociado":
                        if e.cod_pro and hasattr(e.cod_pro, 'nom_pro') and e.cod_pro.nom_pro:
                            valor = str(e.cod_pro.nom_pro)
                        else:
                            valor = "Sin proyecto"
                    elif campo == "Responsable":
                        if e.cod_pro:
                            resp = UsuarioProyecto.objects.filter(
                                cod_pro=e.cod_pro, 
                                es_lider_pro=True
                            ).first()
                            valor = resp.cedula.nom_usu if resp and resp.cedula else ""
                        else:
                            valor = ""
                    
                    fila.append(valor)
                
                data.append(fila)
            
            for i in range(len(data)):
                for j in range(len(data[i])):
                    if i == 0:
                        data[i][j] = Paragraph(str(data[i][j]), style_header)
                    else:
                        data[i][j] = Paragraph(str(data[i][j]) if data[i][j] else " ", style_celda)
            
            ancho_disponible = landscape(A4)[0] - 60
            col_widths = []
            for campo in campos["entregables"]:
                if campo in ["Estado", "Fecha de Entrega"]:
                    col_widths.append(80)
                elif campo in ["Nombre del Entregable", "Proyecto Asociado", "Responsable"]:
                    col_widths.append(150)
                else:
                    col_widths.append(100)  
            
            total_width = sum(col_widths)
            if total_width > ancho_disponible:
                factor = ancho_disponible / total_width
                col_widths = [w * factor for w in col_widths]
            
            t = Table(data, repeatRows=1, colWidths=col_widths)
            t.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#9B59B6')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 9),
                ('FONTSIZE', (0, 1), (-1, -1), 8),
                ('TOPPADDING', (0, 0), (-1, -1), 6),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
                ('LEFTPADDING', (0, 0), (-1, -1), 4),
                ('RIGHTPADDING', (0, 0), (-1, -1), 4),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ]))
            elements.append(t)
    doc.build(elements, onFirstPage=agregar_encabezado_pie, onLaterPages=agregar_encabezado_pie)
    
    pdf = buffer.getvalue()
    buffer.close()
    response.write(pdf)
    
    return response

def reporte_tendencias_crecimiento(request):
    from collections import defaultdict
    import openpyxl
    from django.http import HttpResponse
    from django.utils import timezone
    from dateutil.relativedelta import relativedelta
    from openpyxl.styles import Font, Border, Side, PatternFill, Alignment
    from openpyxl.chart import LineChart, Reference

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Tendencias de Crecimiento"

    thin_border = Border(
        left=Side(style="thin", color="090979"),
        right=Side(style="thin", color="090979"),
        top=Side(style="thin", color="090979"),
        bottom=Side(style="thin", color="090979")
    )

    crear_encabezado_reporte(ws, request)

    fila_titulo = 7
    ws.merge_cells(start_row=fila_titulo, start_column=1, end_row=fila_titulo, end_column=5)
    titulo = ws.cell(row=fila_titulo, column=1)
    titulo.value = "TENDENCIAS DE CRECIMIENTO"
    titulo.font = Font(bold=True, size=16)
    titulo.alignment = Alignment(horizontal="center")

    fila_encabezado = fila_titulo + 1
    encabezados = [
        "Período",
        "Semilleros Creados",
        "Proyectos Creados",
        "Participantes Activos",
        "Entregables Completados"
    ]

    for col, texto in enumerate(encabezados, 1):
        cell = ws.cell(row=fila_encabezado, column=col, value=texto)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill(start_color="3498DB", end_color="3498DB", fill_type="solid")
        cell.alignment = Alignment(horizontal="center")
        cell.border = thin_border

    fecha_actual = timezone.now()
    fecha_inicio = (fecha_actual - relativedelta(months=11)).replace(
        day=1, hour=0, minute=0, second=0, microsecond=0
    )

    sem_dict = defaultdict(int)
    proy_dict = defaultdict(int)

    for fecha in Semillero.objects.filter(fecha_creacion__isnull=False).values_list("fecha_creacion", flat=True):
        fecha = timezone.make_aware(fecha) if timezone.is_naive(fecha) else fecha
        sem_dict[timezone.localtime(fecha).strftime("%Y-%m")] += 1

    for fecha in Proyecto.objects.filter(fecha_creacion__isnull=False).values_list("fecha_creacion", flat=True):
        fecha = timezone.make_aware(fecha) if timezone.is_naive(fecha) else fecha
        proy_dict[timezone.localtime(fecha).strftime("%Y-%m")] += 1

    fila_datos = fila_encabezado + 1

    for i in range(12):
        mes_actual = fecha_inicio + relativedelta(months=i)
        mes_siguiente = mes_actual + relativedelta(months=1)

        clave_mes = mes_actual.strftime("%Y-%m")
        periodo = mes_actual.strftime("%b %Y")

        semilleros_mes = sem_dict.get(clave_mes, 0)
        proyectos_mes = proy_dict.get(clave_mes, 0)

        participantes = (
            Usuario.objects.filter(fecha_registro__lte=mes_siguiente).count() +
            Aprendiz.objects.filter(fecha_registro__lte=mes_siguiente).count()
        )

        entregables_mes = Entregable.objects.filter(
            estado__in=["Completado", "Entrega Tardía"],
            fecha_fin__gte=mes_actual,
            fecha_fin__lt=mes_siguiente
        ).count()

        ws.append([periodo, semilleros_mes, proyectos_mes, participantes, entregables_mes])

        for col in range(1, 6):
            ws.cell(row=fila_datos, column=col).border = thin_border

        fila_datos += 1

    chart = LineChart()
    chart.title = "Evolución Temporal"
    chart.y_axis.title = "Cantidad"
    chart.x_axis.title = "Período"

    data = Reference(ws, min_col=2, min_row=fila_encabezado, max_col=5, max_row=ws.max_row)
    cats = Reference(ws, min_col=1, min_row=fila_encabezado + 1, max_row=ws.max_row)

    chart.add_data(data, titles_from_data=True)
    chart.set_categories(cats)

    ws.add_chart(chart, "G7")

    fila_resumen = ws.max_row + 3
    ws.cell(row=fila_resumen, column=1, value="RESUMEN ESTADÍSTICO").font = Font(bold=True, size=12)

    fila_resumen += 2
    ws.append(["Métrica", "Valor"])
    ws.cell(row=ws.max_row, column=1).font = Font(bold=True)
    ws.cell(row=ws.max_row, column=2).font = Font(bold=True)

    fila_tabla_resumen = ws.max_row

    ws.append(["Total Semilleros (12 meses)", sum(sem_dict.values())])
    ws.append(["Total Proyectos (12 meses)", sum(proy_dict.values())])
    ws.append(["Total Participantes", Usuario.objects.count() + Aprendiz.objects.count()])
    ws.append([
        "Total Entregables Completados",
        Entregable.objects.filter(estado__in=["Completado", "Entrega Tardía"]).count()
    ])

    # BORDES
    for row in ws.iter_rows(
        min_row=fila_tabla_resumen,
        max_row=ws.max_row,
        min_col=1,
        max_col=2
    ):
        for cell in row:
            cell.border = thin_border

    fila_inicio_resumen = fila_tabla_resumen + 1
    fila_fin_resumen = ws.max_row


    chart_resumen = BarChart()
    chart_resumen.title = "Resumen Estadístico"
    chart_resumen.y_axis.title = "Cantidad"
    chart_resumen.x_axis.title = "Métricas"


    data = Reference(ws, min_col=2, min_row=fila_inicio_resumen, max_row=fila_fin_resumen)
    labels = Reference(ws, min_col=1, min_row=fila_inicio_resumen, max_row=fila_fin_resumen)
    chart_resumen.add_data(data, titles_from_data=False)
    chart_resumen.set_categories(labels)

    ws.add_chart(chart_resumen, f"G{fila_inicio_resumen}")

    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response["Content-Disposition"] = 'attachment; filename="tendencias_crecimiento.xlsx"'
    wb.save(response)
    return response

def reporte_productividad_semillero(request):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Productividad"

    thin_border = Border(
        left=Side(style="thin", color="090979"),
        right=Side(style="thin", color="090979"),
        top=Side(style="thin", color="090979"),
        bottom=Side(style="thin", color="090979")
    )

    crear_encabezado_reporte(ws, request)

    fila_titulo = 7
    ws.merge_cells(start_row=fila_titulo, start_column=1, end_row=fila_titulo, end_column=6)
    titulo = ws.cell(row=fila_titulo, column=1)
    titulo.value = "PRODUCTIVIDAD POR SEMILLERO"
    titulo.font = Font(bold=True, size=16)
    titulo.alignment = Alignment(horizontal="center")

    fila_encabezado = fila_titulo + 1
    encabezados = [
        "Semillero",
        "Proyectos Finalizados",
        "Entregables Completados",
        "Total Participantes",
        "Tasa de Finalización (%)",
        "Productividad Promedio"
    ]

    for col, texto in enumerate(encabezados, 1):
        cell = ws.cell(row=fila_encabezado, column=col, value=texto)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill(start_color="3498DB", end_color="3498DB", fill_type="solid")
        cell.border = thin_border
        cell.alignment = Alignment(horizontal="center")

    fila_datos = fila_encabezado + 1

    for sem in Semillero.objects.all():
        proyectos = SemilleroProyecto.objects.filter(id_sem=sem)
        total_proyectos = proyectos.count()

        proyectos_finalizados = Proyecto.objects.filter(
            semilleroproyecto__id_sem=sem,
            estado_pro="completado"
        ).count()

        entregables_completados = Entregable.objects.filter(
            cod_pro__in=proyectos.values("cod_pro"),
            estado__in=["Completado", "Entrega Tardía"]
        ).count()

        usuarios = SemilleroUsuario.objects.filter(id_sem=sem).count()
        aprendices = Aprendiz.objects.filter(id_sem=sem).count()
        total_participantes = usuarios + aprendices

        tasa = (proyectos_finalizados / total_proyectos * 100) if total_proyectos else 0
        productividad = (entregables_completados / total_participantes) if total_participantes else 0

        valores = [
            sem.nombre,
            proyectos_finalizados,
            entregables_completados,
            total_participantes,
            round(tasa, 1),
            round(productividad, 2)
        ]

        for col, valor in enumerate(valores, 1):
            cell = ws.cell(row=fila_datos, column=col, value=valor)
            cell.border = thin_border
            cell.alignment = Alignment(horizontal="center")

        fila_datos += 1

    fila_ultima_tabla = fila_datos - 1

    chart1 = BarChart()
    chart1.title = "Entregables Completados por Semillero"
    chart1.y_axis.title = "Cantidad"
    chart1.x_axis.title = "Semillero"

    chart1.add_data(
        Reference(ws, min_col=3, min_row=fila_encabezado, max_row=fila_ultima_tabla),
        titles_from_data=True
    )
    chart1.set_categories(
        Reference(ws, min_col=1, min_row=fila_encabezado + 1, max_row=fila_ultima_tabla)
    )
    ws.add_chart(chart1, "H3")

    chart2 = BarChart()
    chart2.title = "Proyectos Finalizados por Semillero"
    chart2.y_axis.title = "Cantidad"

    chart2.add_data(
        Reference(ws, min_col=2, min_row=fila_encabezado, max_row=fila_ultima_tabla),
        titles_from_data=True
    )
    chart2.set_categories(
        Reference(ws, min_col=1, min_row=fila_encabezado + 1, max_row=fila_ultima_tabla)
    )
    ws.add_chart(chart2, "H20")

    chart3 = BarChart()
    chart3.title = "Productividad Promedio por Semillero"
    chart3.y_axis.title = "Productividad"

    chart3.add_data(
        Reference(ws, min_col=6, min_row=fila_encabezado, max_row=fila_ultima_tabla),
        titles_from_data=True
    )
    chart3.set_categories(
        Reference(ws, min_col=1, min_row=fila_encabezado + 1, max_row=fila_ultima_tabla)
    )
    ws.add_chart(chart3, "H37")

    fila_ranking_titulo = fila_ultima_tabla + 3
    ws.cell(row=fila_ranking_titulo, column=1,
            value="TOP 5 SEMILLEROS MÁS PRODUCTIVOS").font = Font(bold=True, size=12)

    fila_ranking_encabezado = fila_ranking_titulo + 1
    ranking_headers = ["Posición", "Semillero", "Productividad"]

    for col, texto in enumerate(ranking_headers, 1):
        cell = ws.cell(row=fila_ranking_encabezado, column=col, value=texto)
        cell.font = Font(bold=True)
        cell.border = thin_border
        cell.alignment = Alignment(horizontal="center")

    datos_ranking = []
    for row in range(fila_encabezado + 1, fila_ultima_tabla + 1):
        datos_ranking.append({
            "nombre": ws.cell(row=row, column=1).value,
            "productividad": ws.cell(row=row, column=6).value or 0
        })

    datos_ranking.sort(key=lambda x: x["productividad"], reverse=True)

    fila_ranking_datos = fila_ranking_encabezado + 1
    for i, dato in enumerate(datos_ranking[:5], 1):
        ws.cell(row=fila_ranking_datos, column=1, value=i)
        ws.cell(row=fila_ranking_datos, column=2, value=dato["nombre"])
        ws.cell(row=fila_ranking_datos, column=3, value=dato["productividad"])

        for col in range(1, 4):
            ws.cell(row=fila_ranking_datos, column=col).border = thin_border
            ws.cell(row=fila_ranking_datos, column=col).alignment = Alignment(horizontal="center")

        fila_ranking_datos += 1

    chart_participantes = BarChart()
    chart_participantes.title = "Total Participantes por Semillero"
    chart_participantes.y_axis.title = "Cantidad"
    chart_participantes.x_axis.title = "Semillero"

    chart_participantes.add_data(
        Reference(ws, min_col=4, min_row=fila_encabezado, max_row=fila_ultima_tabla),
        titles_from_data=True
    )
    chart_participantes.set_categories(
        Reference(ws, min_col=1, min_row=fila_encabezado + 1, max_row=fila_ultima_tabla)
    )
    ws.add_chart(chart_participantes, "H54")

    fila_top5_inicio = fila_ranking_encabezado + 1
    fila_top5_fin = fila_ranking_datos - 1

    chart_top5 = BarChart()
    chart_top5.title = "Top 5 Semilleros Más Productivos"
    chart_top5.y_axis.title = "Productividad"
    chart_top5.x_axis.title = "Semillero"

    chart_top5.add_data(
        Reference(ws, min_col=3, min_row=fila_top5_inicio, max_row=fila_top5_fin),
        titles_from_data=False
    )
    chart_top5.set_categories(
        Reference(ws, min_col=2, min_row=fila_top5_inicio, max_row=fila_top5_fin)
    )
    ws.add_chart(chart_top5, f"H70")
    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response["Content-Disposition"] = 'attachment; filename="productividad_semillero.xlsx"'
    wb.save(response)
    return response

def reporte_mensual_ejecutivo(request):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Reporte Mensual"

    crear_encabezado_reporte(ws, request)

    fecha_actual = timezone.now()
    inicio_mes = fecha_actual.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

    if fecha_actual.month == 12:
        fin_mes = fecha_actual.replace(year=fecha_actual.year + 1, month=1, day=1)
    else:
        fin_mes = fecha_actual.replace(month=fecha_actual.month + 1, day=1)

    thin_border = Border(
        left=Side(style="thin", color="090979"),
        right=Side(style="thin", color="090979"),
        top=Side(style="thin", color="090979"),
        bottom=Side(style="thin", color="090979")
    )

    fila_titulo = 7
    ws.merge_cells(start_row=fila_titulo, start_column=1, end_row=fila_titulo, end_column=4)
    titulo = ws.cell(row=fila_titulo, column=1)
    titulo.value = f"REPORTE MENSUAL EJECUTIVO - {fecha_actual.strftime('%B %Y').upper()}"
    titulo.font = Font(bold=True, size=16)
    titulo.alignment = Alignment(horizontal="center")

    fila = fila_titulo + 2
    ws.cell(row=fila, column=1, value="RESUMEN GENERAL").font = Font(bold=True, size=14)
    fila += 1

    semilleros_activos = Semillero.objects.filter(estado='Activo').count()
    proyectos_mes = Proyecto.objects.filter(
        fecha_creacion__gte=inicio_mes,
        fecha_creacion__lt=fin_mes
    ).count()
    entregables_completados_mes = Entregable.objects.filter(
        estado__in=['Completado', 'Entrega Tardía'],
        fecha_fin__gte=inicio_mes,
        fecha_fin__lt=fin_mes
    ).count()

    ws.cell(row=fila, column=1, value="Métrica").font = Font(bold=True)
    ws.cell(row=fila, column=2, value="Valor").font = Font(bold=True)
    fila += 1

    datos_resumen = [
        ["Semilleros Activos", semilleros_activos],
        ["Proyectos Creados Este Mes", proyectos_mes],
        ["Entregables Completados", entregables_completados_mes],
        ["Total Participantes", Usuario.objects.count() + Aprendiz.objects.count()],
    ]

    inicio_resumen = fila
    for dato in datos_resumen:
        ws.cell(row=fila, column=1, value=dato[0])
        ws.cell(row=fila, column=2, value=dato[1])
        fila += 1

    for row in ws.iter_rows(min_row=inicio_resumen-1, max_row=fila-1, min_col=1, max_col=2):
        for cell in row:
            cell.border = thin_border

    fila += 2
    ws.cell(row=fila, column=1, value="LOGROS DEL MES").font = Font(bold=True, size=14)
    fila += 1

    inicio_logros = fila
    ws.cell(row=fila, column=1, value="Proyecto").font = Font(bold=True)
    ws.cell(row=fila, column=2, value="Avance (%)").font = Font(bold=True)
    ws.cell(row=fila, column=3, value="Estado").font = Font(bold=True)
    fila += 1

    proyectos_avance = Proyecto.objects.filter(
        fecha_creacion__lt=fin_mes
    ).order_by('-progreso')[:10]

    for p in proyectos_avance:
        ws.cell(row=fila, column=1, value=p.nom_pro)
        ws.cell(row=fila, column=2, value=p.progreso)
        ws.cell(row=fila, column=3, value=p.estado_pro)
        fila += 1

    fila_final_logros = fila - 1

    for row in ws.iter_rows(min_row=inicio_logros, max_row=fila_final_logros, min_col=1, max_col=3):
        for cell in row:
            cell.border = thin_border

    fila += 2
    ws.cell(row=fila, column=1, value="PARTICIPACIÓN POR SEMILLERO").font = Font(bold=True, size=14)
    fila += 1

    inicio_participacion = fila
    ws.cell(row=fila, column=1, value="Semillero").font = Font(bold=True)
    ws.cell(row=fila, column=2, value="Integrantes").font = Font(bold=True)
    ws.cell(row=fila, column=3, value="Proyectos Activos").font = Font(bold=True)
    fila += 1

    for sem in Semillero.objects.all():
        integrantes = (
            SemilleroUsuario.objects.filter(id_sem=sem).count() +
            Aprendiz.objects.filter(id_sem=sem).count()
        )
        proyectos_activos = SemilleroProyecto.objects.filter(id_sem=sem).count()

        ws.cell(row=fila, column=1, value=sem.nombre)
        ws.cell(row=fila, column=2, value=integrantes)
        ws.cell(row=fila, column=3, value=proyectos_activos)
        fila += 1

    fila_final_participacion = fila - 1

    for row in ws.iter_rows(
        min_row=inicio_participacion,
        max_row=fila_final_participacion,
        min_col=1,
        max_col=3
    ):
        for cell in row:
            cell.border = thin_border

    chart1 = BarChart()
    chart1.title = "Top 10 Proyectos por Avance"
    chart1.y_axis.title = "Progreso (%)"

    data1 = Reference(ws, min_col=2, min_row=inicio_logros+1, max_row=fila_final_logros)
    cats1 = Reference(ws, min_col=1, min_row=inicio_logros+1, max_row=fila_final_logros)
    chart1.add_data(data1, titles_from_data=False)
    chart1.set_categories(cats1)
    ws.add_chart(chart1, "F5")

    chart2 = PieChart()
    chart2.title = "Distribución de Integrantes"

    data2 = Reference(ws, min_col=2, min_row=inicio_participacion+1, max_row=fila_final_participacion)
    cats2 = Reference(ws, min_col=1, min_row=inicio_participacion+1, max_row=fila_final_participacion)
    chart2.add_data(data2, titles_from_data=False)
    chart2.set_categories(cats2)
    ws.add_chart(chart2, "F25")

    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response["Content-Disposition"] = (
        f'attachment; filename="reporte_mensual_{fecha_actual.strftime("%Y_%m")}.xlsx"'
    )

    wb.save(response)
    return response

def informe_trimestral(request):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Informe Trimestral"

    crear_encabezado_reporte(ws, request)
    
    fecha_actual = timezone.now()
    
    mes_actual = fecha_actual.month
    if mes_actual <= 3:
        inicio_trimestre = fecha_actual.replace(month=1, day=1)
        trimestre = "Q1"
    elif mes_actual <= 6:
        inicio_trimestre = fecha_actual.replace(month=4, day=1)
        trimestre = "Q2"
    elif mes_actual <= 9:
        inicio_trimestre = fecha_actual.replace(month=7, day=1)
        trimestre = "Q3"
    else:
        inicio_trimestre = fecha_actual.replace(month=10, day=1)
        trimestre = "Q4"
    
    thin_border = Border(
        left=Side(style="thin", color="090979"),
        right=Side(style="thin", color="090979"),
        top=Side(style="thin", color="090979"),
        bottom=Side(style="thin", color="090979")
    )

    ws.merge_cells('A7:E7')
    titulo = ws['A7']
    titulo.value = f"INFORME TRIMESTRAL {trimestre} - {fecha_actual.year}"
    titulo.font = Font(bold=True, size=16)
    titulo.alignment = openpyxl.styles.Alignment(horizontal='center')

    fila = 8
    ws.cell(row=fila, column=1, value="CUMPLIMIENTO DE OBJETIVOS").font = Font(bold=True, size=14)
    fila += 2
    
    inicio_cumplimiento = fila
    ws.cell(row=fila, column=1, value="Semillero").font = Font(bold=True)
    ws.cell(row=fila, column=2, value="Proyectos Completados").font = Font(bold=True)
    ws.cell(row=fila, column=3, value="Proyectos En Curso").font = Font(bold=True)
    ws.cell(row=fila, column=4, value="Tasa de Cumplimiento (%)").font = Font(bold=True)
    fila += 1
    
    semilleros = Semillero.objects.all()
    for sem in semilleros:
        proyectos_completados = Proyecto.objects.filter(
            semilleroproyecto__id_sem=sem,
            estado_pro='completado',
            fecha_creacion__gte=inicio_trimestre
        ).count()
        
        proyectos_curso = Proyecto.objects.filter(
            semilleroproyecto__id_sem=sem,
            estado_pro__in=['planeacion', 'ejecucion']
        ).count()
        
        total = proyectos_completados + proyectos_curso
        tasa = (proyectos_completados / total * 100) if total > 0 else 0
        
        ws.cell(row=fila, column=1, value=sem.nombre)
        ws.cell(row=fila, column=2, value=proyectos_completados)
        ws.cell(row=fila, column=3, value=proyectos_curso)
        ws.cell(row=fila, column=4, value=round(tasa, 1))
        fila += 1

    fila_final_cumplimiento = fila - 1

    for row in ws.iter_rows(min_row=inicio_cumplimiento, max_row=fila_final_cumplimiento, min_col=1, max_col=4):
        for cell in row:
            cell.border = thin_border

    fila += 2
    ws.cell(row=fila, column=1, value="ENTREGABLES COMPLETADOS POR MES").font = Font(bold=True, size=14)
    fila += 1
    
    inicio_entregables = fila
    ws.cell(row=fila, column=1, value="Mes").font = Font(bold=True)
    ws.cell(row=fila, column=2, value="Completados").font = Font(bold=True)
    ws.cell(row=fila, column=3, value="Tardíos").font = Font(bold=True)
    ws.cell(row=fila, column=4, value="Pendientes").font = Font(bold=True)
    fila += 1

    for i in range(3):
        mes_analisis = inicio_trimestre + relativedelta(months=i)
        mes_siguiente = mes_analisis + relativedelta(months=1)
        
        completados = Entregable.objects.filter(
            estado='Completado',
            fecha_fin__gte=mes_analisis,
            fecha_fin__lt=mes_siguiente
        ).count()
        
        tardios = Entregable.objects.filter(
            estado='Entrega Tardía',
            fecha_fin__gte=mes_analisis,
            fecha_fin__lt=mes_siguiente
        ).count()
        
        pendientes = Entregable.objects.filter(
            estado='Pendiente',
            fecha_inicio__gte=mes_analisis,
            fecha_inicio__lt=mes_siguiente
        ).count()
        
        ws.cell(row=fila, column=1, value=mes_analisis.strftime("%B"))
        ws.cell(row=fila, column=2, value=completados)
        ws.cell(row=fila, column=3, value=tardios)
        ws.cell(row=fila, column=4, value=pendientes)
        fila += 1

    fila_final_entregables = fila - 1

    for row in ws.iter_rows(min_row=inicio_entregables, max_row=fila_final_entregables, min_col=1, max_col=4):
        for cell in row:
            cell.border = thin_border

    chart1 = BarChart()
    chart1.title = "Tasa de Cumplimiento por Semillero"
    chart1.y_axis.title = "Porcentaje (%)"
    chart1.x_axis.title = "Semilleros"

    data1 = Reference(ws, min_col=4, min_row=inicio_cumplimiento, max_row=fila_final_cumplimiento)
    cats1 = Reference(ws, min_col=1, min_row=inicio_cumplimiento+1, max_row=fila_final_cumplimiento)

    chart1.add_data(data1, titles_from_data=True)  
    chart1.set_categories(cats1)
    chart1.height = 10
    chart1.width = 15
    ws.add_chart(chart1, "G5")

    chart2 = LineChart()
    chart2.title = "Evolución de Entregables"
    chart2.y_axis.title = "Cantidad"
    chart2.x_axis.title = "Mes"

    data2 = Reference(ws, min_col=2, min_row=inicio_entregables, max_col=4, max_row=fila_final_entregables)
    cats2 = Reference(ws, min_col=1, min_row=inicio_entregables+1, max_row=fila_final_entregables)

    chart2.add_data(data2, titles_from_data=True)
    chart2.set_categories(cats2)
    chart2.height = 10
    chart2.width = 15
    ws.add_chart(chart2, "G25")

    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response["Content-Disposition"] = f'attachment; filename="informe_trimestral_{trimestre}_{fecha_actual.year}.xlsx"'
    
    wb.save(response)
    return response

def balance_anual(request):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Balance Anual"

    crear_encabezado_reporte(ws, request)
    
    fecha_actual = timezone.now()
    año_actual = fecha_actual.year
    inicio_año = fecha_actual.replace(month=1, day=1, hour=0, minute=0, second=0)
    
    thin_border = Border(
        left=Side(style="thin", color="090979"),
        right=Side(style="thin", color="090979"),
        top=Side(style="thin", color="090979"),
        bottom=Side(style="thin", color="090979")
    )
    
    ws.merge_cells('A7:F7')
    titulo = ws['A7']
    titulo.value = f"BALANCE ANUAL {año_actual}"
    titulo.font = Font(bold=True, size=18)
    titulo.alignment = openpyxl.styles.Alignment(horizontal='center')

    fila = 9
    ws.cell(row=fila, column=1, value="RESUMEN EJECUTIVO").font = Font(bold=True, size=14)
    fila += 1
    
    inicio_resumen_anual = fila
    ws.cell(row=fila, column=1, value="Indicador").font = Font(bold=True)
    ws.cell(row=fila, column=2, value="Total Año").font = Font(bold=True)
    ws.cell(row=fila, column=3, value="Promedio Mensual").font = Font(bold=True)
    fila += 1
    
    inicio_datos_resumen = fila

    proyectos_año = Proyecto.objects.filter(fecha_creacion__year=año_actual).count()
    entregables_año = Entregable.objects.filter(
        estado__in=['Completado', 'Entrega Tardía'],
        fecha_fin__year=año_actual
    ).count()
    participantes_nuevos = Usuario.objects.filter(fecha_registro__year=año_actual).count() + \
                          Aprendiz.objects.filter(fecha_registro__year=año_actual).count()
    
    meses_transcurridos = fecha_actual.month
    
    indicadores = [
        ["Proyectos Creados", proyectos_año, round(proyectos_año / meses_transcurridos, 1)],
        ["Entregables Completados", entregables_año, round(entregables_año / meses_transcurridos, 1)],
        ["Participantes Nuevos", participantes_nuevos, round(participantes_nuevos / meses_transcurridos, 1)],
    ]
    
    for ind in indicadores:
        ws.cell(row=fila, column=1, value=ind[0])
        ws.cell(row=fila, column=2, value=ind[1])
        ws.cell(row=fila, column=3, value=ind[2])
        fila += 1
    
    fin_resumen_anual = fila - 1
    
    for row in ws.iter_rows(min_row=inicio_resumen_anual, max_row=fin_resumen_anual, min_col=1, max_col=3):
        for cell in row:
            cell.border = thin_border
    
    fila += 2
    ws.cell(row=fila, column=1, value="EVOLUCIÓN MENSUAL").font = Font(bold=True, size=14)
    fila += 1
    
    inicio_evolucion = fila
    ws.cell(row=fila, column=1, value="Mes").font = Font(bold=True)
    ws.cell(row=fila, column=2, value="Proyectos").font = Font(bold=True)
    ws.cell(row=fila, column=3, value="Entregables").font = Font(bold=True)
    ws.cell(row=fila, column=4, value="Progreso Promedio (%)").font = Font(bold=True)
    fila += 1
    
    inicio_datos_evolucion = fila

    for mes in range(1, meses_transcurridos + 1):
        mes_inicio = fecha_actual.replace(month=mes, day=1)
        mes_fin = mes_inicio + relativedelta(months=1)
        
        proyectos_mes = Proyecto.objects.filter(
            fecha_creacion__gte=mes_inicio,
            fecha_creacion__lt=mes_fin
        ).count()
        
        entregables_mes = Entregable.objects.filter(
            estado__in=['Completado', 'Entrega Tardía'],
            fecha_fin__gte=mes_inicio,
            fecha_fin__lt=mes_fin
        ).count()

        proyectos_activos = Proyecto.objects.filter(fecha_creacion__lt=mes_fin)
        progreso_promedio = proyectos_activos.aggregate(Avg('progreso'))['progreso__avg'] or 0
        
        ws.cell(row=fila, column=1, value=mes_inicio.strftime("%B"))
        ws.cell(row=fila, column=2, value=proyectos_mes)
        ws.cell(row=fila, column=3, value=entregables_mes)
        ws.cell(row=fila, column=4, value=round(progreso_promedio, 1))
        fila += 1
    
    fila_final_evolucion = fila - 1

    for row in ws.iter_rows(min_row=inicio_evolucion, max_row=fila_final_evolucion, min_col=1, max_col=4):
        for cell in row:
            cell.border = thin_border

    fila += 2
    ws.cell(row=fila, column=1, value="RANKING DE SEMILLEROS").font = Font(bold=True, size=14)
    fila += 1
    
    inicio_ranking = fila
    ws.cell(row=fila, column=1, value="Posición").font = Font(bold=True)
    ws.cell(row=fila, column=2, value="Semillero").font = Font(bold=True)
    ws.cell(row=fila, column=3, value="Proyectos Completados").font = Font(bold=True)
    ws.cell(row=fila, column=4, value="Progreso General (%)").font = Font(bold=True)
    fila += 1

    inicio_datos_ranking = fila

    semilleros_ranking = []
    for sem in Semillero.objects.all():
        proyectos_completados = Proyecto.objects.filter(
            semilleroproyecto__id_sem=sem,
            estado_pro='completado'
        ).count()
        
        semilleros_ranking.append({
            'nombre': sem.nombre,
            'completados': proyectos_completados,
            'progreso': sem.progreso_sem
        })

    semilleros_ranking.sort(key=lambda x: (x['completados'], x['progreso']), reverse=True)
    
    for i, sem in enumerate(semilleros_ranking, 1):
        ws.cell(row=fila, column=1, value=i)
        ws.cell(row=fila, column=2, value=sem['nombre'])
        ws.cell(row=fila, column=3, value=sem['completados'])
        ws.cell(row=fila, column=4, value=sem['progreso'])
        fila += 1
    
    fila_final_ranking = fila - 1

    for row in ws.iter_rows(min_row=inicio_ranking, max_row=fila_final_ranking, min_col=1, max_col=4):
        for cell in row:
            cell.border = thin_border

    chart_resumen = BarChart()
    chart_resumen.title = "Resumen Ejecutivo del Año"
    chart_resumen.y_axis.title = "Cantidad"
    chart_resumen.x_axis.title = "Indicadores"
    
    data_resumen = Reference(ws, min_col=2, min_row=inicio_resumen_anual, max_row=fin_resumen_anual)
    cats_resumen = Reference(ws, min_col=1, min_row=inicio_datos_resumen, max_row=fin_resumen_anual)
    
    chart_resumen.add_data(data_resumen, titles_from_data=True)
    chart_resumen.set_categories(cats_resumen)
    chart_resumen.height = 8
    chart_resumen.width = 12
    
    ws.add_chart(chart_resumen, "H2")

    chart1 = BarChart()
    chart1.title = "Evolución Anual"
    chart1.y_axis.title = "Cantidad"
    chart1.x_axis.title = "Mes"

    proyectos_data = Reference(
        ws,
        min_col=2,
        min_row=inicio_evolucion,  
        max_row=fila_final_evolucion
    )

    entregables_data = Reference(
        ws,
        min_col=3,
        min_row=inicio_evolucion,  
        max_row=fila_final_evolucion
    )

    chart1.add_data(proyectos_data, titles_from_data=True)
    chart1.add_data(entregables_data, titles_from_data=True)

    cats1 = Reference(
        ws,
        min_col=1,
        min_row=inicio_datos_evolucion,
        max_row=fila_final_evolucion
    )

    chart1.set_categories(cats1)

    chart1.height = 8
    chart1.width = 12

    ws.add_chart(chart1, "H20")
    
    chart2 = BarChart()
    chart2.title = "Top 5 Semilleros"
    chart2.y_axis.title = "Proyectos Completados"
    chart2.x_axis.title = "Semilleros"

    num_semilleros_grafico = min(5, len(semilleros_ranking))
    max_fila_ranking_grafico = inicio_datos_ranking + num_semilleros_grafico - 1
    
    data2 = Reference(ws, min_col=3, min_row=inicio_ranking, max_row=max_fila_ranking_grafico + 1)
    cats2 = Reference(ws, min_col=2, min_row=inicio_datos_ranking, max_row=max_fila_ranking_grafico)
    
    chart2.add_data(data2, titles_from_data=True)
    chart2.set_categories(cats2)
    chart2.height = 8
    chart2.width = 12
    
    ws.add_chart(chart2, "H38")

    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response["Content-Disposition"] = f'attachment; filename="balance_anual_{año_actual}.xlsx"'
    
    wb.save(response)
    return response

def comparativo_anual(request):
 
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Comparativo Anual"
    
    crear_encabezado_reporte(ws, request)

    fecha_actual = timezone.now()
    año_actual = fecha_actual.year
    año_anterior = año_actual - 1
    
    thin_border = Border(
        left=Side(style="thin", color="090979"),
        right=Side(style="thin", color="090979"),
        top=Side(style="thin", color="090979"),
        bottom=Side(style="thin", color="090979")
    )
 
    ws.merge_cells('A7:E7')
    titulo = ws['A7']
    titulo.value = f"COMPARATIVO {año_anterior} vs {año_actual}"
    titulo.font = Font(bold=True, size=16)
    titulo.alignment = openpyxl.styles.Alignment(horizontal='center')

    fila = 8
    ws.cell(row=fila, column=1, value="INDICADORES GENERALES").font = Font(bold=True, size=14)
    fila += 1

    inicio_indicadores = fila
    ws.cell(row=fila, column=1, value="Indicador").font = Font(bold=True)
    ws.cell(row=fila, column=2, value=f"{año_anterior}").font = Font(bold=True)
    ws.cell(row=fila, column=3, value=f"{año_actual}").font = Font(bold=True)
    ws.cell(row=fila, column=4, value="Variación (%)").font = Font(bold=True)
    ws.cell(row=fila, column=5, value="Tendencia").font = Font(bold=True)
    fila += 1

    def calcular_indicadores(año):
        proyectos = Proyecto.objects.filter(fecha_creacion__year=año).count()
        entregables = Entregable.objects.filter(
            estado__in=['Completado', 'Entrega Tardía'],
            fecha_fin__year=año
        ).count()
        participantes = Usuario.objects.filter(fecha_registro__year=año).count() + \
                       Aprendiz.objects.filter(fecha_registro__year=año).count()
        semilleros = Semillero.objects.filter(fecha_creacion__year=año).count()
        
        return {
            'proyectos': proyectos,
            'entregables': entregables,
            'participantes': participantes,
            'semilleros': semilleros
        }
    
    datos_anterior = calcular_indicadores(año_anterior)
    datos_actual = calcular_indicadores(año_actual)
    
    indicadores = [
        ["Proyectos Creados", datos_anterior['proyectos'], datos_actual['proyectos']],
        ["Entregables Completados", datos_anterior['entregables'], datos_actual['entregables']],
        ["Nuevos Participantes", datos_anterior['participantes'], datos_actual['participantes']],
        ["Semilleros Creados", datos_anterior['semilleros'], datos_actual['semilleros']],
    ]
    
    for ind in indicadores:
        anterior = ind[1]
        actual = ind[2]
        
        if anterior > 0:
            variacion = ((actual - anterior) / anterior * 100)
            tendencia = "↑" if variacion > 0 else "↓" if variacion < 0 else "="
        elif actual > 0:
            variacion = 100
            tendencia = "↑"
        else:
            variacion = 0
            tendencia = "="
        
        ws.cell(row=fila, column=1, value=ind[0])
        ws.cell(row=fila, column=2, value=anterior)
        ws.cell(row=fila, column=3, value=actual)
        ws.cell(row=fila, column=4, value=round(variacion, 1))
        ws.cell(row=fila, column=5, value=tendencia)
        fila += 1
    
    fin_indicadores = fila - 1
    
    for row in ws.iter_rows(min_row=inicio_indicadores, max_row=fin_indicadores, min_col=1, max_col=5):
        for cell in row:
            cell.border = thin_border
    
    fila += 2
    ws.cell(row=fila, column=1, value="COMPARATIVO POR SEMILLERO").font = Font(bold=True, size=14)
    fila += 1
    
    inicio_semilleros = fila
    ws.cell(row=fila, column=1, value="Semillero").font = Font(bold=True)
    ws.cell(row=fila, column=2, value=f"Proyectos {año_anterior}").font = Font(bold=True)
    ws.cell(row=fila, column=3, value=f"Proyectos {año_actual}").font = Font(bold=True)
    ws.cell(row=fila, column=4, value="Crecimiento (%)").font = Font(bold=True)
    fila += 1
    
    semilleros = Semillero.objects.all()
    for sem in semilleros:
        proyectos_anterior = Proyecto.objects.filter(
            semilleroproyecto__id_sem=sem,
            fecha_creacion__year=año_anterior
        ).count()
        
        proyectos_actual = Proyecto.objects.filter(
            semilleroproyecto__id_sem=sem,
            fecha_creacion__year=año_actual
        ).count()
        
        if proyectos_anterior > 0:
            crecimiento = ((proyectos_actual - proyectos_anterior) / proyectos_anterior * 100)
        elif proyectos_actual > 0:
            crecimiento = 100
        else:
            crecimiento = 0
        
        ws.cell(row=fila, column=1, value=sem.nombre)
        ws.cell(row=fila, column=2, value=proyectos_anterior)
        ws.cell(row=fila, column=3, value=proyectos_actual)
        ws.cell(row=fila, column=4, value=round(crecimiento, 1))
        fila += 1
    
    fin_semilleros = fila - 1
    
    for row in ws.iter_rows(min_row=inicio_semilleros, max_row=fin_semilleros, min_col=1, max_col=4):
        for cell in row:
            cell.border = thin_border

    fila += 2
    ws.cell(row=fila, column=1, value="EVOLUCIÓN MENSUAL COMPARADA").font = Font(bold=True, size=14)
    fila += 1
    
    inicio_mensual = fila
    ws.cell(row=fila, column=1, value="Mes").font = Font(bold=True)
    ws.cell(row=fila, column=2, value=f"Proyectos {año_anterior}").font = Font(bold=True)
    ws.cell(row=fila, column=3, value=f"Proyectos {año_actual}").font = Font(bold=True)
    fila += 1
    
    meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 
             'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
    
    for mes_num in range(1, 13):
        proyectos_anterior = Proyecto.objects.filter(
            fecha_creacion__year=año_anterior,
            fecha_creacion__month=mes_num
        ).count()
        
        proyectos_actual = Proyecto.objects.filter(
            fecha_creacion__year=año_actual,
            fecha_creacion__month=mes_num
        ).count()
        
        ws.cell(row=fila, column=1, value=meses[mes_num-1])
        ws.cell(row=fila, column=2, value=proyectos_anterior)
        ws.cell(row=fila, column=3, value=proyectos_actual)
        fila += 1
    
    fin_mensual = fila - 1

    for row in ws.iter_rows(min_row=inicio_mensual, max_row=fin_mensual, min_col=1, max_col=3):
        for cell in row:
            cell.border = thin_border

    chart1 = BarChart()
    chart1.title = "Comparativo General"
    chart1.y_axis.title = "Cantidad"
    chart1.x_axis.title = "Indicadores"
    
    values_anterior = Reference(ws, min_col=2, min_row=inicio_indicadores+1, max_row=fin_indicadores)
    values_actual = Reference(ws, min_col=3, min_row=inicio_indicadores+1, max_row=fin_indicadores)
    cats1 = Reference(ws, min_col=1, min_row=inicio_indicadores+1, max_row=fin_indicadores)
    
    serie1 = Series(values_anterior, title=f"{año_anterior}")
    chart1.series.append(serie1)
    
    serie2 = Series(values_actual, title=f"{año_actual}")
    chart1.series.append(serie2)
    
    chart1.set_categories(cats1)
    ws.add_chart(chart1, "G3")
    
    chart2 = LineChart()
    chart2.title = "Evolución Mensual"
    chart2.y_axis.title = "Proyectos"
    chart2.x_axis.title = "Mes"
    
    values_mensual_anterior = Reference(ws, min_col=2, min_row=inicio_mensual+1, max_row=fin_mensual)
    values_mensual_actual = Reference(ws, min_col=3, min_row=inicio_mensual+1, max_row=fin_mensual)
    cats2 = Reference(ws, min_col=1, min_row=inicio_mensual+1, max_row=fin_mensual)
    
    serie_mensual1 = Series(values_mensual_anterior, title=f"Proyectos {año_anterior}")
    chart2.series.append(serie_mensual1)
    
    serie_mensual2 = Series(values_mensual_actual, title=f"Proyectos {año_actual}")
    chart2.series.append(serie_mensual2)
    
    chart2.set_categories(cats2)
    ws.add_chart(chart2, "G20")
    

    chart3 = BarChart()
    chart3.title = "Crecimiento por Semillero"
    chart3.y_axis.title = "Porcentaje (%)"
    chart3.x_axis.title = "Semilleros"

    data3 = Reference(ws, min_col=4, min_row=inicio_semilleros+1, max_row=fin_semilleros)
    cats3 = Reference(ws, min_col=1, min_row=inicio_semilleros+1, max_row=fin_semilleros)
    
    chart3.add_data(data3, titles_from_data=False)
    chart3.set_categories(cats3)
    ws.add_chart(chart3, "G37")
    

    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response["Content-Disposition"] = f'attachment; filename="comparativo_anual_{año_anterior}_{año_actual}.xlsx"'
    
    wb.save(response)
    return response

def reporte_programa(request):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Proyectos por Programa"

    crear_encabezado_reporte(ws, request)
    
    thin_border = Border(
        left=Side(style="thin", color="090979"),
        right=Side(style="thin", color="090979"),
        top=Side(style="thin", color="090979"),
        bottom=Side(style="thin", color="090979")
    )

    ws.merge_cells('A7:F7')
    titulo = ws['A7']
    titulo.value = "PROYECTOS FORMATIVOS POR PROGRAMA"
    titulo.font = Font(bold=True, size=16)
    titulo.alignment = openpyxl.styles.Alignment(horizontal='center')

    fila_encabezado = 8
    ws.append([      
        "Programa de Formación",
        "Cantidad de Proyectos",
        "Proyectos Activos",
        "Proyectos Completados",
        "Total Aprendices",
        "Progreso Promedio (%)"
    ])
    
    for cell in ws[fila_encabezado]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill(start_color="3498DB", end_color="3498DB", fill_type="solid")
        cell.border = thin_border

    proyectos_formativos = Proyecto.objects.filter(tipo__iexact="formativo")

    if proyectos_formativos.filter(programa_formacion__isnull=False).exclude(programa_formacion="").exists():
        programas = proyectos_formativos.filter(
            programa_formacion__isnull=False
        ).exclude(programa_formacion="").values('programa_formacion').distinct()
        usar_programa_proyecto = True
    else:
        programas = Aprendiz.objects.filter(
            proyectoaprendiz__cod_pro__tipo__iexact="formativo"
        ).values('programa').distinct()
        usar_programa_proyecto = False
    
    fila_inicio_datos = fila_encabezado + 1
    hay_datos = False

    for programa_dict in programas:
        if usar_programa_proyecto:
            programa = programa_dict['programa_formacion']
            proyectos = Proyecto.objects.filter(
                tipo__iexact="formativo",
                programa_formacion=programa
            )
        else:
            programa = programa_dict['programa']
            aprendices_programa = Aprendiz.objects.filter(programa=programa)
            proyectos = Proyecto.objects.filter(
                tipo__iexact="formativo",
                proyectoaprendiz__cedula_apre__in=aprendices_programa.values_list('cedula_apre', flat=True)
            ).distinct()
        
        total_proyectos = proyectos.count()
        if total_proyectos == 0:
            continue
        
        hay_datos = True

        proyectos_activos = proyectos.filter(
            estado_pro__in=['planeacion', 'ejecucion', 'activo', 'en curso']
        ).count()
        
        proyectos_completados = proyectos.filter(
            estado_pro__in=['completado', 'finalizado', 'terminado']
        ).count()
        
        total_aprendices = ProyectoAprendiz.objects.filter(
            cod_pro__in=proyectos.values_list('cod_pro', flat=True)
        ).values('cedula_apre').distinct().count()
        
        progreso_promedio = proyectos.aggregate(Avg('progreso'))['progreso__avg'] or 0

        ws.append([
            programa or "Sin Programa",
            total_proyectos,
            proyectos_activos,
            proyectos_completados,
            total_aprendices,
            round(progreso_promedio, 1)
        ])
    
    # Si no hay datos
    if not hay_datos:
        ws.append([
            "No hay proyectos formativos registrados",
            0, 0, 0, 0, 0
        ])
    
    fila_fin_datos = ws.max_row

    for row in ws.iter_rows(min_row=fila_encabezado, max_row=fila_fin_datos, min_col=1, max_col=6):
        for cell in row:
            cell.border = thin_border

    ws.column_dimensions['A'].width = 35
    ws.column_dimensions['B'].width = 18
    ws.column_dimensions['C'].width = 18
    ws.column_dimensions['D'].width = 20
    ws.column_dimensions['E'].width = 18
    ws.column_dimensions['F'].width = 22

    if hay_datos and fila_fin_datos >= fila_inicio_datos:

        chart1 = BarChart()
        chart1.title = "Cantidad de Proyectos por Programa"
        chart1.y_axis.title = "Número de Proyectos"
        chart1.x_axis.title = "Programa de Formación"
        chart1.style = 10
        
        data1 = Reference(ws, min_col=2, min_row=fila_encabezado, max_row=fila_fin_datos)
        cats1 = Reference(ws, min_col=1, min_row=fila_inicio_datos, max_row=fila_fin_datos)
        
        chart1.add_data(data1, titles_from_data=True)
        chart1.set_categories(cats1)
        chart1.height = 8
        chart1.width = 12
        
        ws.add_chart(chart1, "H9")

        chart2 = LineChart()
        chart2.title = "Progreso Promedio por Programa"
        chart2.y_axis.title = "Progreso (%)"
        chart2.x_axis.title = "Programa de Formación"
        chart2.style = 12
        
        data2 = Reference(ws, min_col=6, min_row=fila_encabezado, max_row=fila_fin_datos)
        cats2 = Reference(ws, min_col=1, min_row=fila_inicio_datos, max_row=fila_fin_datos)
        
        chart2.add_data(data2, titles_from_data=True)
        chart2.set_categories(cats2)
        chart2.height = 8
        chart2.width = 12
        
        ws.add_chart(chart2, "H27")

        chart3 = PieChart()
        chart3.title = "Distribución de Estados de Proyectos"
        chart3.style = 10

        fila_titulo_estado = fila_fin_datos + 3

        ws.merge_cells(
            start_row=fila_titulo_estado,
            start_column=1,
            end_row=fila_titulo_estado,
            end_column=2
        )

        titulo_estado = ws.cell(row=fila_titulo_estado, column=1)
        titulo_estado.value = "RESUMEN DE ESTADO DE PROYECTOS"
        titulo_estado.font = Font(bold=True, size=13)
        titulo_estado.alignment = Alignment(horizontal="center", vertical="center")

        fila_totales = fila_titulo_estado + 1

        ws.cell(row=fila_totales, column=1, value="Estado").font = Font(bold=True)
        ws.cell(row=fila_totales, column=2, value="Cantidad").font = Font(bold=True)

        total_activos = 0
        total_completados = 0

        for i in range(fila_inicio_datos, fila_fin_datos + 1):
            val_activos = ws.cell(row=i, column=3).value
            val_completados = ws.cell(row=i, column=4).value

            if isinstance(val_activos, (int, float)):
                total_activos += int(val_activos)

            if isinstance(val_completados, (int, float)):
                total_completados += int(val_completados)

        ws.cell(row=fila_totales + 1, column=1, value="Activos")
        ws.cell(row=fila_totales + 1, column=2, value=total_activos)

        ws.cell(row=fila_totales + 2, column=1, value="Completados")
        ws.cell(row=fila_totales + 2, column=2, value=total_completados)

        for row in ws.iter_rows(
            min_row=fila_totales,
            max_row=fila_totales + 2,
            min_col=1,
            max_col=2
        ):
            for cell in row:
                cell.border = thin_border

        data3 = Reference(ws, min_col=2, min_row=fila_totales, max_row=fila_totales + 2)
        labels3 = Reference(ws, min_col=1, min_row=fila_totales + 1, max_row=fila_totales + 2)

        chart3.add_data(data3, titles_from_data=True)
        chart3.set_categories(labels3)
        chart3.height = 8
        chart3.width = 12

        ws.add_chart(chart3, "H45")

    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response["Content-Disposition"] = 'attachment; filename="proyectos_formativos_programa.xlsx"'
    
    wb.save(response)
    return response

def reporte_fichas(request):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Vinculación Fichas"
    
    crear_encabezado_reporte(ws, request)

    thin_border = Border(
        left=Side(style="thin", color="090979"),
        right=Side(style="thin", color="090979"),
        top=Side(style="thin", color="090979"),
        bottom=Side(style="thin", color="090979")
    )
    
    ws.merge_cells('A7:G7')
    titulo = ws['A7']
    titulo.value = "VINCULACIÓN DE FICHAS A PROYECTOS"
    titulo.font = Font(bold=True, size=16)
    titulo.alignment = openpyxl.styles.Alignment(horizontal='center')
    
    fila_encabezado = 8
    ws.append([    
        "Ficha",
        "Programa",
        "Total Aprendices",
        "Aprendices en Proyectos",
        "Proyectos Asociados",
        "Semilleros Vinculados",
        "Tasa de Participación (%)"
    ])
    
    for cell in ws[fila_encabezado]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill(start_color="3498DB", end_color="3498DB", fill_type="solid")
        cell.border = thin_border
    
    fichas = Aprendiz.objects.values('ficha', 'programa').distinct().order_by('ficha')
    
    fila_inicio_datos = 8
    
    for ficha_dict in fichas:
        ficha = ficha_dict['ficha']
        programa = ficha_dict['programa']
        
        aprendices_ficha = Aprendiz.objects.filter(ficha=ficha)
        total_aprendices = aprendices_ficha.count()
        
        aprendices_en_proyectos = ProyectoAprendiz.objects.filter(
            cedula_apre__in=aprendices_ficha.values_list('cedula_apre', flat=True)
        ).values('cedula_apre').distinct().count()
        
        proyectos_asociados = Proyecto.objects.filter(
            proyectoaprendiz__cedula_apre__in=aprendices_ficha.values_list('cedula_apre', flat=True)
        ).distinct().count()
        
        semilleros_vinculados = Semillero.objects.filter(
            id_sem__in=aprendices_ficha.values_list('id_sem', flat=True)
        ).distinct().count()
        
        tasa_participacion = (aprendices_en_proyectos / total_aprendices * 100) if total_aprendices > 0 else 0
        
        ws.append([
            ficha or "Sin Ficha",
            programa or "Sin Programa",
            total_aprendices,
            aprendices_en_proyectos,
            proyectos_asociados,
            semilleros_vinculados,
            round(tasa_participacion, 1)
        ])
    
    fila_fin_tabla = ws.max_row
    
    for row in ws.iter_rows(min_row=fila_encabezado, max_row=fila_fin_tabla, min_col=1, max_col=7):
        for cell in row:
            cell.border = thin_border
    
    ws.column_dimensions['A'].width = 20
    ws.column_dimensions['B'].width = 35
    ws.column_dimensions['C'].width = 18
    ws.column_dimensions['D'].width = 22
    ws.column_dimensions['E'].width = 20
    ws.column_dimensions['F'].width = 20
    ws.column_dimensions['G'].width = 25
    
    chart1 = BarChart()
    chart1.title = "Aprendices por Ficha"
    chart1.y_axis.title = "Cantidad de Aprendices"
    chart1.x_axis.title = "Ficha"
    chart1.style = 10
    
    data1 = Reference(ws, min_col=3, min_row=fila_encabezado, max_row=fila_fin_tabla)
    cats1 = Reference(ws, min_col=1, min_row=fila_inicio_datos, max_row=fila_fin_tabla)
    
    chart1.add_data(data1, titles_from_data=True)
    chart1.set_categories(cats1)
    chart1.height = 8
    chart1.width = 12
    
    ws.add_chart(chart1, "I9")
    
    chart2 = LineChart()
    chart2.title = "Tasa de Participación por Ficha"
    chart2.y_axis.title = "Porcentaje (%)"
    chart2.x_axis.title = "Ficha"
    chart2.style = 12
    
    data2 = Reference(ws, min_col=7, min_row=fila_encabezado, max_row=fila_fin_tabla)
    cats2 = Reference(ws, min_col=1, min_row=fila_inicio_datos, max_row=fila_fin_tabla)
    
    chart2.add_data(data2, titles_from_data=True)
    chart2.set_categories(cats2)
    chart2.height = 8
    chart2.width = 12
    
    ws.add_chart(chart2, "I27")
    
    fila_titulo_detalle = fila_fin_tabla + 3
    ws.merge_cells(f'A{fila_titulo_detalle}:E{fila_titulo_detalle}')
    titulo_detalle = ws[f'A{fila_titulo_detalle}']
    titulo_detalle.value = "DETALLE DE PROYECTOS POR FICHA"
    titulo_detalle.font = Font(bold=True, size=14)
    titulo_detalle.alignment = openpyxl.styles.Alignment(horizontal='center')
    
    fila_encabezado_detalle = fila_titulo_detalle + 1
    
    ws.cell(row=fila_encabezado_detalle, column=1, value="Ficha").font = Font(bold=True)
    ws.cell(row=fila_encabezado_detalle, column=2, value="Proyecto").font = Font(bold=True)
    ws.cell(row=fila_encabezado_detalle, column=3, value="Tipo").font = Font(bold=True)
    ws.cell(row=fila_encabezado_detalle, column=4, value="Estado").font = Font(bold=True)
    ws.cell(row=fila_encabezado_detalle, column=5, value="Aprendices Participantes").font = Font(bold=True)
    
    for col in range(1, 6):
        cell = ws.cell(row=fila_encabezado_detalle, column=col)
        cell.fill = PatternFill(start_color="3498DB", end_color="3498DB", fill_type="solid")
        cell.font = Font(bold=True, color="FFFFFF")
        cell.border = thin_border
    
    fila_detalle = fila_encabezado_detalle + 1
    inicio_datos_detalle = fila_detalle
    
    for ficha_dict in fichas:
        ficha = ficha_dict['ficha']
        
        aprendices_ids = Aprendiz.objects.filter(ficha=ficha).values_list('cedula_apre', flat=True)
        
        proyectos = Proyecto.objects.filter(
            proyectoaprendiz__cedula_apre__in=aprendices_ids
        ).distinct()
        
        for proyecto in proyectos:
            aprendices_proyecto = ProyectoAprendiz.objects.filter(
                cod_pro=proyecto,
                cedula_apre__in=aprendices_ids
            ).count()
            
            ws.append([
                ficha or "Sin Ficha",
                proyecto.nom_pro,
                proyecto.tipo or "N/A",
                proyecto.estado_pro or "N/A",
                aprendices_proyecto
            ])
            fila_detalle += 1
    
    fila_fin_detalle = fila_detalle - 1
    
    for row in ws.iter_rows(min_row=fila_encabezado_detalle, max_row=fila_fin_detalle, min_col=1, max_col=5):
        for cell in row:
            cell.border = thin_border
    
    ws.column_dimensions['B'].width = 40
    ws.column_dimensions['C'].width = 15
    ws.column_dimensions['D'].width = 15
    ws.column_dimensions['E'].width = 25
    
    fila_titulo_tipo = fila_fin_detalle + 3

    ws.merge_cells(start_row=fila_titulo_tipo, start_column=1,
    end_row=fila_titulo_tipo, end_column=2)

    titulo_tipo = ws.cell(row=fila_titulo_tipo, column=1)
    titulo_tipo.value = "RESUMEN DE PROYECTOS POR TIPO"
    titulo_tipo.font = Font(bold=True, size=13)
    titulo_tipo.alignment = Alignment(horizontal="center", vertical="center")

    fila_totales_tipo = fila_titulo_tipo + 1

    ws.cell(row=fila_totales_tipo, column=1, value="Tipo de Proyecto").font = Font(bold=True)
    ws.cell(row=fila_totales_tipo, column=2, value="Cantidad").font = Font(bold=True)

    tipos_count = {}
    for i in range(inicio_datos_detalle, fila_fin_detalle + 1):
        tipo = ws.cell(row=i, column=3).value
        if tipo and tipo != "N/A":
            tipos_count[tipo] = tipos_count.get(tipo, 0) + 1

    fila_actual = fila_totales_tipo + 1
    for tipo, cantidad in tipos_count.items():
        ws.cell(row=fila_actual, column=1, value=tipo)
        ws.cell(row=fila_actual, column=2, value=cantidad)
        fila_actual += 1

    if tipos_count:
        for row in ws.iter_rows(min_row=fila_totales_tipo,
            max_row=fila_actual - 1,
            min_col=1, max_col=2):
                for cell in row:
                    cell.border = thin_border

    chart3 = PieChart()
    chart3.title = "Distribución de Proyectos por Tipo"
    chart3.style = 10

    data3 = Reference(ws,
        min_col=2,
        min_row=fila_totales_tipo,
        max_row=fila_actual - 1)
    labels3 = Reference(ws,
        min_col=1,
        min_row=fila_totales_tipo + 1,
        max_row=fila_actual - 1)
    chart3.add_data(data3, titles_from_data=True)
    chart3.set_categories(labels3)

    chart3.height = 8
    chart3.width = 12

    ws.add_chart(chart3, "I45")
    
    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response["Content-Disposition"] = 'attachment; filename="vinculacion_fichas.xlsx"'
    
    wb.save(response)
    return response

# VISTAS BACKUP
@require_http_methods(["POST"])
def backup_personal(request):
    try:
        # Verificar sesión
        if not request.session.get('cedula'):
            return JsonResponse({
                'success': False,
                'error': 'No hay sesión activa'
            }, status=401)
        
        cedula = request.session.get('cedula')
        
        # Obtener el usuario
        try:
            usuario = Usuario.objects.get(cedula=cedula)
        except Usuario.DoesNotExist:
            return JsonResponse({
                'success': False,
                'error': 'Usuario no encontrado'
            }, status=404)
        
        # Fecha y hora del backup
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_name = f'backup_personal_{usuario.nom_usu}_{usuario.ape_usu}_{timestamp}'
                
        # Crear buffer de memoria para el archivo ZIP
        zip_buffer = BytesIO()
        
        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
            
            # Recopilar datos personales del usuario
            datos_usuario = {}
            total_registros = 0
            
            # 1. INFORMACIÓN DEL USUARIO
            usuario_data = serializers.serialize('json', [usuario], indent=2)
            zip_file.writestr(f'{backup_name}/usuario.json', usuario_data)
            datos_usuario['usuario'] = 1
            total_registros += 1
            
            # 3. SEMILLEROS DONDE PARTICIPA
            semilleros_usuario = SemilleroUsuario.objects.filter(cedula=usuario)
            if semilleros_usuario.exists():
                count = semilleros_usuario.count()
                data = serializers.serialize('json', semilleros_usuario, indent=2)
                zip_file.writestr(f'{backup_name}/semilleros_participacion.json', data)
                
                # Obtener los semilleros completos
                semilleros_ids = semilleros_usuario.values_list('id_sem', flat=True)
                semilleros = Semillero.objects.filter(id_sem__in=semilleros_ids)
                semilleros_data = serializers.serialize('json', semilleros, indent=2)
                zip_file.writestr(f'{backup_name}/semilleros.json', semilleros_data)
                
                datos_usuario['semilleros'] = semilleros.count()
                total_registros += count + semilleros.count()
            
            # 4. PROYECTOS DONDE PARTICIPA
            proyectos_usuario = UsuarioProyecto.objects.filter(cedula=usuario)
            if proyectos_usuario.exists():
                count = proyectos_usuario.count()
                data = serializers.serialize('json', proyectos_usuario, indent=2)
                zip_file.writestr(f'{backup_name}/proyectos_participacion.json', data)
                
                # Obtener los proyectos completos
                proyectos_ids = proyectos_usuario.values_list('cod_pro', flat=True)
                proyectos = Proyecto.objects.filter(cod_pro__in=proyectos_ids)
                proyectos_data = serializers.serialize('json', proyectos, indent=2)
                zip_file.writestr(f'{backup_name}/proyectos.json', proyectos_data)
                
                datos_usuario['proyectos'] = proyectos.count()
                total_registros += count + proyectos.count()
            
            # 6. ENTREGABLES DE SUS PROYECTOS
            if proyectos_usuario.exists():
                entregables = Entregable.objects.filter(cod_pro__in=proyectos_ids)
                if entregables.exists():
                    count = entregables.count()
                    data = serializers.serialize('json', entregables, indent=2)
                    zip_file.writestr(f'{backup_name}/entregables.json', data)
                    datos_usuario['entregables'] = count
                    total_registros += count
            
            # 7. DOCUMENTOS DE SEMILLEROS
            if semilleros_usuario.exists():
                documentos_sem = SemilleroDocumento.objects.filter(id_sem__in=semilleros_ids)
                if documentos_sem.exists():
                    count = documentos_sem.count()
                    data = serializers.serialize('json', documentos_sem, indent=2)
                    zip_file.writestr(f'{backup_name}/documentos_semilleros.json', data)
                    datos_usuario['documentos_semilleros'] = count
                    total_registros += count
            
            # 8. ARCHIVOS RELACIONADOS (vinculados a entregables de los proyectos)
            if proyectos_usuario.exists():
                # Obtener entregables de los proyectos del usuario
                entregables_ids = Entregable.objects.filter(
                    cod_pro__in=proyectos_ids
                ).values_list('cod_entre', flat=True)
                
                # Obtener archivos de esos entregables
                archivos = Archivo.objects.filter(entregable__in=entregables_ids)
                if archivos.exists():
                    count = archivos.count()
                    data = serializers.serialize('json', archivos, indent=2)
                    zip_file.writestr(f'{backup_name}/archivos.json', data)
                    datos_usuario['archivos'] = count
                    total_registros += count
            
            # METADATOS
            metadata = {
                'backup_info': {
                    'tipo': 'Personal',
                    'usuario': usuario.nom_usu,
                    'cedula': cedula,
                    'rol': usuario.rol,
                    'fecha_creacion': datetime.now().isoformat(),
                    'timestamp': timestamp,
                    'total_registros': total_registros,
                },
                'contenido': datos_usuario,
                'descripcion': 'Backup personal con toda la información relacionada al usuario'
            }
            
            zip_file.writestr(
                f'{backup_name}/METADATA.json',
                json.dumps(metadata, indent=2, ensure_ascii=False)
            )
            
            # README
            readme_content = f"""
╔═══════════════════════════════════════════════════════════════╗
║           BACKUP PERSONAL - {usuario.nom_usu}                  ║
╚═══════════════════════════════════════════════════════════════╝

📦 INFORMACIÓN DEL BACKUP
─────────────────────────────────────────────────────────────────
  Usuario: {usuario.nom_usu}
  Cédula: {cedula}
  Rol: {usuario.rol}
  Fecha: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
  Total de registros: {total_registros}

📄 CONTENIDO
─────────────────────────────────────────────────────────────────
"""
            for item, cantidad in datos_usuario.items():
                readme_content += f"  • {item}: {cantidad} registro(s)\n"
            
            readme_content += f"""
─────────────────────────────────────────────────────────────────

🔄 INFORMACIÓN IMPORTANTE
─────────────────────────────────────────────────────────────────
  Este backup contiene únicamente TU información personal:
  - Tus datos de usuario
  - Semilleros donde participas
  - Proyectos en los que estás involucrado
  - Entregables relacionados
  - Archivos y documentos
  
  Para restaurar información específica, contacta al administrador
  del sistema.

═══════════════════════════════════════════════════════════════════
"""
            zip_file.writestr(f'{backup_name}/README.txt', readme_content)
        
        # Preparar respuesta
        zip_buffer.seek(0)
        response = HttpResponse(zip_buffer.getvalue(), content_type='application/zip')
        response['Content-Disposition'] = f'attachment; filename="{backup_name}.zip"'
        
        return response
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        
        return JsonResponse({
            'success': False,
            'error': f'Error al generar el backup: {str(e)}'
        }, status=500)

@require_http_methods(["POST"])
def backup_completo(request):
    try:
        # Verificar sesión
        if not request.session.get('cedula'):
            return JsonResponse({
                'success': False,
                'error': 'No hay sesión activa'
            }, status=401)
        
        cedula = request.session.get('cedula')
        
        # Obtener el usuario y verificar permisos
        try:
            usuario = Usuario.objects.get(cedula=cedula)
            if usuario.rol not in ['Coordinador', 'Dinamizador', 'Administrador']:
                return JsonResponse({
                    'success': False,
                    'error': 'No tienes permisos para realizar backups completos'
                }, status=403)
        except Usuario.DoesNotExist:
            return JsonResponse({
                'success': False,
                'error': 'Usuario no encontrado'
            }, status=404)
        
        # Fecha y hora del backup
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_name = f'backup_completo_{timestamp}'
                
        # Apps a excluir
        apps_excluidas = ['contenttypes', 'auth', 'admin', 'sessions', 'messages', 'staticfiles']
        
        # Obtener todos los modelos
        modelos_app = []
        for model in apps.get_models():
            app_label = model._meta.app_label
            if app_label not in apps_excluidas:
                modelos_app.append(model)
        
        # Crear buffer de memoria para el archivo ZIP
        zip_buffer = BytesIO()
        
        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
                        
            # 1. BACKUP COMPLETO DE TODOS LOS DATOS
            data = serializers.serialize(
                'json',
                [obj for model in modelos_app for obj in model.objects.all()],
                indent=2,
                use_natural_foreign_keys=True
            )
            
            zip_file.writestr(f'{backup_name}/data_completa.json', data)
            
            # 2. BACKUP POR MODELO INDIVIDUAL
            total_registros = 0
            estadisticas = {}
            
            for model in modelos_app:
                model_name = f"{model._meta.app_label}_{model._meta.model_name}"
                queryset = model.objects.all()
                count = queryset.count()
                
                if count > 0:
                    model_data = serializers.serialize('json', queryset, indent=2, use_natural_foreign_keys=True)
                    zip_file.writestr(f'{backup_name}/modelos/{model_name}.json', model_data)
                    estadisticas[model_name] = count
                    total_registros += count
                    print(f"   ✓ {model_name}: {count} registros")
            
            # 3. METADATOS
            metadata = {
                'backup_info': {
                    'tipo': 'Completo',
                    'generado_por': usuario.nom_usu,
                    'rol': usuario.rol,
                    'fecha_creacion': datetime.now().isoformat(),
                    'timestamp': timestamp,
                    'total_modelos': len(modelos_app),
                    'total_registros': total_registros,
                },
                'estadisticas_por_modelo': estadisticas,
                'formato': 'JSON (Django dumpdata)',
                'tipo_backup': 'Lógico Completo',
                'reconstruible': True
            }
            
            zip_file.writestr(
                f'{backup_name}/METADATA.json',
                json.dumps(metadata, indent=2, ensure_ascii=False)
            )
            
            # 4. README
            readme_content = f"""
╔═══════════════════════════════════════════════════════════════╗
║              BACKUP COMPLETO DE BASE DE DATOS                 ║
╚═══════════════════════════════════════════════════════════════╝

📦 INFORMACIÓN DEL BACKUP
─────────────────────────────────────────────────────────────────
  Generado por: {usuario.nom_usu} ({usuario.rol})
  Fecha: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
  Total de modelos: {len(modelos_app)}
  Total de registros: {total_registros:,}

✅ TIPO DE BACKUP
─────────────────────────────────────────────────────────────────
  • Backup lógico completo
  • Formato: JSON (Django dumpdata)
  • Compresión: ZIP
  • Totalmente reconstruible

📄 CONTENIDO
─────────────────────────────────────────────────────────────────
  ✓ Estructura de datos (modelos)
  ✓ Registros de todas las tablas
  ✓ Relaciones (Primary Keys / Foreign Keys)

🔄 RESTAURACIÓN COMPLETA
─────────────────────────────────────────────────────────────────
  python manage.py loaddata {backup_name}/data_completa.json

📊 ESTADÍSTICAS POR MODELO
─────────────────────────────────────────────────────────────────
"""
            for modelo, cantidad in sorted(estadisticas.items()):
                readme_content += f"  {modelo}: {cantidad:,} registros\n"
            
            readme_content += """
═══════════════════════════════════════════════════════════════════
"""
            zip_file.writestr(f'{backup_name}/README.txt', readme_content)
        
        # Preparar respuesta
        zip_buffer.seek(0)
        response = HttpResponse(zip_buffer.getvalue(), content_type='application/zip')
        response['Content-Disposition'] = f'attachment; filename="{backup_name}.zip"'

        return response
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        
        return JsonResponse({
            'success': False,
            'error': f'Error al generar el backup: {str(e)}'
        }, status=500)

@require_http_methods(["GET"])
def backup_info(request):
    try:
        if not request.session.get('cedula'):
            return JsonResponse({
                'success': False,
                'error': 'No hay sesión activa'
            }, status=401)
        
        cedula = request.session.get('cedula')
        
        try:
            usuario = Usuario.objects.get(cedula=cedula)
        except Usuario.DoesNotExist:
            return JsonResponse({
                'success': False,
                'error': 'Usuario no encontrado'
            }, status=404)
        
        # Determinar tipo de backup disponible
        puede_backup_completo = usuario.rol in ['Coordinador', 'Dinamizador', 'Administrador']
        
        # Información básica
        info = {
            'usuario': usuario.nom_usu,
            'rol': usuario.rol,
            'puede_backup_completo': puede_backup_completo,
            'backup_personal_disponible': True
        }
        
        # Si puede hacer backup completo, calcular estadísticas
        if puede_backup_completo:
            apps_excluidas = ['contenttypes', 'auth', 'admin', 'sessions', 'messages', 'staticfiles']
            total_modelos = 0
            total_registros = 0
            
            for model in apps.get_models():
                if model._meta.app_label not in apps_excluidas:
                    total_modelos += 1
                    total_registros += model.objects.count()
            
            info['backup_completo'] = {
                'total_modelos': total_modelos,
                'total_registros': total_registros
            }
        
        # Estadísticas personales
        estadisticas_personales = {}
        
        # Contar datos personales
        try:
            aprendiz = Aprendiz.objects.filter(cedula_usu=usuario).first()
            estadisticas_personales['aprendiz'] = 1 if aprendiz else 0
        except:
            estadisticas_personales['aprendiz'] = 0
        
        estadisticas_personales['semilleros'] = SemilleroUsuario.objects.filter(cedula=usuario).count()
        estadisticas_personales['proyectos'] = UsuarioProyecto.objects.filter(cedula=usuario).count()
        
        # Archivos (contar desde entregables de proyectos)
        proyectos_usuario = UsuarioProyecto.objects.filter(cedula=usuario)
        if proyectos_usuario.exists():
            proyectos_ids = proyectos_usuario.values_list('cod_pro', flat=True)
            entregables_ids = Entregable.objects.filter(
                cod_pro__in=proyectos_ids
            ).values_list('cod_entre', flat=True)
            estadisticas_personales['archivos'] = Archivo.objects.filter(entregable__in=entregables_ids).count()
        else:
            estadisticas_personales['archivos'] = 0
        
        info['backup_personal'] = estadisticas_personales
        
        return JsonResponse({
            'success': True,
            'info': info
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)
    
# VISTA DE LOGOUT
def logout(request):
    request.session.flush()
    messages.success(request, "Has cerrado sesión correctamente")
    return redirect('iniciarsesion')

